// semantic_memory.cpp
// Implementation of SemanticMemory defined in semantic_memory.hpp.

#include "elastic/semantic_memory.hpp"
#include "elastic/tensor.hpp"
#include <algorithm>
#include <cstring>
#include <iostream>
#include <ctime>
#include <sqlite3.h>

namespace elastic {

namespace {
// Flatten a tensor to 1‑D float vector.  Returns error if null.
static StatusOr<std::vector<float>> FlattenTensor(const Tensor &t) {
  const float *data = reinterpret_cast<const float *>(t.data());
  if (!data) {
    return Status::Error("Null tensor data in FlattenTensor");
  }
  size_t total = 1;
  for (int d : t.shape()) total *= static_cast<size_t>(d);
  std::vector<float> out(total);
  std::memcpy(out.data(), data, total * sizeof(float));
  return StatusOr<std::vector<float>>(std::move(out));
}

// Deserialize embedding blob: [int dim][float values...]
static std::vector<float> DeserializeEmbedding(const void *data, int bytes) {
  if (!data || bytes < static_cast<int>(sizeof(int))) return {};
  int dim;
  std::memcpy(&dim, data, sizeof(int));
  if (bytes < static_cast<int>(sizeof(int) + dim * sizeof(float))) return {};
  const float *vals = reinterpret_cast<const float *>(static_cast<const char *>(data) + sizeof(int));
  return std::vector<float>(vals, vals + dim);
}

// Compute squared L2 distance between two vectors.
static float SquaredL2(const std::vector<float> &a, const std::vector<float> &b) {
  size_t n = a.size();
  if (b.size() != n) return std::numeric_limits<float>::max();
  float sum = 0.0f;
  for (size_t i = 0; i < n; ++i) {
    float diff = a[i] - b[i];
    sum += diff * diff;
  }
  return sum;
}
} // anonymous

SemanticMemory::SemanticMemory(MemoryService &mem) : mem_(mem) {
  // As a friend of MemoryService we can access the private db_ member
  // directly.  This reuses the existing database connection for the
  // insights table.
  db_ = mem_.db_;
  if (!db_) {
    std::cerr << "SemanticMemory: failed to obtain SQLite handle" << std::endl;
  }
  EnsureSchema();
}

// Creates the insights table if it does not exist.
void SemanticMemory::EnsureSchema() {
  if (!db_) return;
  const char *sql =
      "CREATE TABLE IF NOT EXISTS insights ("           \
      "id INTEGER PRIMARY KEY AUTOINCREMENT,"          \
      "dim INTEGER NOT NULL,"                          \
      "embedding BLOB NOT NULL,"                       \
      "summary TEXT NOT NULL,"                          \
      "ts INTEGER DEFAULT 0"                           \
      ");";
  char *err = nullptr;
  if (sqlite3_exec(db_, sql, nullptr, nullptr, &err) != SQLITE_OK) {
    std::cerr << "SemanticMemory: failed to create insights table: " << err << std::endl;
    sqlite3_free(err);
  }
  // Attempt to add ts column if it does not exist
  char *err2 = nullptr;
  sqlite3_exec(db_, "ALTER TABLE insights ADD COLUMN ts INTEGER DEFAULT 0;", nullptr, nullptr, &err2);
  if (err2) sqlite3_free(err2);
}

Status SemanticMemory::PutInsight(const std::vector<float> &emb, const std::string &summary) {
  if (!db_) return Status::Error("DB not initialised");
  int dim = static_cast<int>(emb.size());
  // Serialize embedding
  std::vector<uint8_t> blob(sizeof(int) + dim * sizeof(float));
  std::memcpy(blob.data(), &dim, sizeof(int));
  std::memcpy(blob.data() + sizeof(int), emb.data(), dim * sizeof(float));
  const char *sql = "INSERT INTO insights (dim, embedding, summary, ts) VALUES (?1, ?2, ?3, ?4);";
  sqlite3_stmt *stmt;
  if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
    return Status::Error("SemanticMemory: prepare insert failed");
  }
  sqlite3_bind_int(stmt, 1, dim);
  sqlite3_bind_blob(stmt, 2, blob.data(), (int)blob.size(), SQLITE_STATIC);
  sqlite3_bind_text(stmt, 3, summary.c_str(), -1, SQLITE_STATIC);
  // timestamp; use current time
  uint64_t ts = static_cast<uint64_t>(time(nullptr));
  sqlite3_bind_int64(stmt, 4, static_cast<sqlite3_int64>(ts));
  if (sqlite3_step(stmt) != SQLITE_DONE) {
    sqlite3_finalize(stmt);
    return Status::Error("SemanticMemory: insert failed");
  }
  sqlite3_finalize(stmt);
  return Status::OK();
}

Status SemanticMemory::CompressAll() {
  if (!db_) return Status::Error("DB not initialised");
  // Retrieve all episodic embeddings and texts from memory table.
  const char *sql = "SELECT embedding, text FROM memory;";
  sqlite3_stmt *stmt;
  if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
    return Status::Error("SemanticMemory: prepare select failed");
  }
  std::vector<float> agg_emb;
  std::vector<std::string> texts;
  int count = 0;
  while (sqlite3_step(stmt) == SQLITE_ROW) {
    const void *blob = sqlite3_column_blob(stmt, 0);
    int bytes = sqlite3_column_bytes(stmt, 0);
    // Deserialize embedding
    if (bytes < (int)sizeof(int)) continue;
    int dim;
    std::memcpy(&dim, blob, sizeof(int));
    const float *vals = reinterpret_cast<const float *>(static_cast<const char *>(blob) + sizeof(int));
    std::vector<float> vec(vals, vals + dim);
    if (agg_emb.empty()) {
      agg_emb.assign(dim, 0.0f);
    }
    if ((int)agg_emb.size() != dim) {
      // Skip mismatched dims
      continue;
    }
    for (int i = 0; i < dim; ++i) {
      agg_emb[i] += vec[i];
    }
    const unsigned char *t = sqlite3_column_text(stmt, 1);
    std::string s = t ? reinterpret_cast<const char *>(t) : "";
    texts.push_back(s);
    ++count;
  }
  sqlite3_finalize(stmt);
  if (count == 0) {
    return Status::Error("SemanticMemory: no episodic memories to compress");
  }
  // Compute mean embedding
  for (float &v : agg_emb) v /= static_cast<float>(count);
  // Build summary: join up to 5 texts truncated to 50 chars
  std::string summary;
  int max_items = std::min(5, (int)texts.size());
  for (int i = 0; i < max_items; ++i) {
    std::string t = texts[i];
    if ((int)t.size() > 50) t = t.substr(0, 50) + "...";
    summary += t;
    if (i + 1 < max_items) summary += "\n";
  }
  return PutInsight(agg_emb, summary);
}

StatusOr<std::vector<MemoryService::SearchResult>>
SemanticMemory::SearchInsights(const Tensor &query, int k) const {
  if (!db_) return StatusOr<std::vector<MemoryService::SearchResult>>(Status::Error("DB not initialised"));
  if (k <= 0) return StatusOr<std::vector<MemoryService::SearchResult>>(Status::Error("k must be positive"));
  // Flatten query tensor
  auto flat_or = FlattenTensor(query);
  if (!flat_or.status.ok) {
    return StatusOr<std::vector<MemoryService::SearchResult>>(flat_or.status);
  }
  std::vector<float> qvec = std::move(flat_or.value);
  // Retrieve all insights
  const char *sql = "SELECT embedding, summary FROM insights;";
  sqlite3_stmt *stmt;
  if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
    return StatusOr<std::vector<MemoryService::SearchResult>>(Status::Error("SemanticMemory: prepare select failed"));
  }
  std::vector<MemoryService::SearchResult> results;
  while (sqlite3_step(stmt) == SQLITE_ROW) {
    const void *blob = sqlite3_column_blob(stmt, 0);
    int bytes = sqlite3_column_bytes(stmt, 0);
    std::vector<float> emb = DeserializeEmbedding(blob, bytes);
    if (emb.empty()) continue;
    const unsigned char *t = sqlite3_column_text(stmt, 1);
    std::string s = t ? reinterpret_cast<const char *>(t) : "";
    float dist = SquaredL2(qvec, emb);
    results.emplace_back(dist, s);
  }
  sqlite3_finalize(stmt);
  std::sort(results.begin(), results.end(), [](auto &a, auto &b) { return a.first < b.first; });
  if ((int)results.size() > k) results.resize(k);
  return StatusOr<std::vector<MemoryService::SearchResult>>(std::move(results));
}

// Return rich hits for insights including embeddings and timestamps.
StatusOr<std::vector<InsightHit>>
SemanticMemory::SearchInsightsEmbeddings(const Tensor &query, int k) const {
  if (!db_) return StatusOr<std::vector<InsightHit>>(Status::Error("DB not initialised"));
  if (k <= 0) return StatusOr<std::vector<InsightHit>>(Status::Error("k must be positive"));
  // Flatten query
  auto flat_or = FlattenTensor(query);
  if (!flat_or.status.ok) {
    return StatusOr<std::vector<InsightHit>>(flat_or.status);
  }
  std::vector<float> qvec = std::move(flat_or.value);
  // Select id, dim, embedding, summary, ts
  const char *sql = "SELECT id, dim, embedding, summary, ts FROM insights;";
  sqlite3_stmt *stmt;
  if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
    return StatusOr<std::vector<InsightHit>>(Status::Error("SemanticMemory: prepare select failed"));
  }
  std::vector<InsightHit> hits;
  while (sqlite3_step(stmt) == SQLITE_ROW) {
    sqlite3_int64 rid = sqlite3_column_int64(stmt, 0);
    int dim = sqlite3_column_int(stmt, 1);
    const void *blob = sqlite3_column_blob(stmt, 2);
    int bytes = sqlite3_column_bytes(stmt, 2);
    const unsigned char *summary = sqlite3_column_text(stmt, 3);
    sqlite3_int64 ts = sqlite3_column_int64(stmt, 4);
    // Deserialize embedding
    std::vector<float> emb;
    if (bytes >= static_cast<int>(sizeof(int) + dim * sizeof(float))) {
      const float *vals = reinterpret_cast<const float *>(static_cast<const char *>(blob) + sizeof(int));
      emb.assign(vals, vals + dim);
    }
    // Compute distance
    float dist;
    int n = std::min(dim, (int)qvec.size());
    float sum = 0.0f;
    for (int i = 0; i < n; ++i) {
      float diff = qvec[i] - emb[i];
      sum += diff * diff;
    }
    dist = sum;
    InsightHit hit;
    hit.id = rid;
    hit.score = dist;
    hit.emb = std::move(emb);
    hit.summary = summary ? reinterpret_cast<const char *>(summary) : "";
    hit.ts_unix = static_cast<uint64_t>(ts);
    hits.push_back(std::move(hit));
  }
  sqlite3_finalize(stmt);
  // Sort by distance
  std::sort(hits.begin(), hits.end(), [](const InsightHit &a, const InsightHit &b) {
    return a.score < b.score;
  });
  if ((int)hits.size() > k) hits.resize(k);
  return StatusOr<std::vector<InsightHit>>(std::move(hits));
}

} // namespace elastic
