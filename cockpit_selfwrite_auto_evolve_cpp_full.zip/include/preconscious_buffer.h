// preconscious_buffer.h
//
// Stub for a pre‑conscious buffer.  The buffer holds a rolling
// window of sensory inputs or encoded tokens before they are
// committed to working memory.  It allows the system to avoid
// repeatedly re‑encoding identical inputs and can implement
// importance‑gated consolidation.  Replace the stub methods with
// concrete data structures and algorithms when implementing the
// buffer.

#ifndef PRECONSCIOUS_BUFFER_H
#define PRECONSCIOUS_BUFFER_H

#include <deque>
#include <string>

namespace preconscious_buffer {

class PreConsciousBuffer {
public:
    // Add a new entry to the buffer.  The entry may represent a raw
    // sensor reading or an encoded token.  In a real system we would
    // track timestamps and compute saliency to decide when to flush
    // entries into long‑term memory.
    void push(const std::string &entry) {
        // TODO: implement rolling window with fixed duration.
        buffer_.push_back(entry);
        // Truncate to maintain a small buffer, e.g. last 2 seconds of
        // events.  Here we arbitrarily cap at 100 items.
        if (buffer_.size() > 100) {
            buffer_.pop_front();
        }
    }

    // Retrieve the current contents of the buffer.  Consumers may
    // combine this with episodic memory retrieval to build a context
    // vector.  Real implementations would return a vector of
    // embeddings rather than strings.
    std::deque<std::string> contents() const { return buffer_; }

    // Clear the buffer, for example when committing its contents to
    // working memory or when the context shifts.
    void clear() { buffer_.clear(); }

private:
    std::deque<std::string> buffer_;
};

} // namespace preconscious_buffer

#endif // PRECONSCIOUS_BUFFER_H