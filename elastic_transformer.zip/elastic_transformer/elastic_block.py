
import torch, torch.nn as nn, torch.nn.functional as F
from .dynamic_linear import DynamicLinear
from .elastic_attention import ElasticAttention
class ElasticBlock(nn.Module):
    def __init__(self, d_model_max: int, d_min: int):
        super().__init__()
        self.d_model_max = d_model_max
        self.attn = ElasticAttention(d_model_max, d_min)
        self.ffn1 = DynamicLinear(d_model_max*4, d_model_max)
        self.ffn2 = DynamicLinear(d_model_max, d_model_max)
        self.ln1 = nn.LayerNorm(d_model_max)
        self.ln2 = nn.LayerNorm(d_model_max)
    def forward(self, x, d, mask=None):
        x_in = x[...,:d]
        y = self.attn(self.ln1(x)[...,:d], d, mask)
        x = x_in + y
        y = self.ffn2(torch.nn.functional.gelu(self.ffn1(self.ln2(x), d)), d)
        return x + y
