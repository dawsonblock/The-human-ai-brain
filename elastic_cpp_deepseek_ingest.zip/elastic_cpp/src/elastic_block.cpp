// Implementation of the Transformer block consisting of attention and feed‑forward network.

#include "elastic/elastic_block.hpp"
#include "elastic/ops.hpp"

#include <cstdint>

namespace elastic {

Status ElasticBlock::init(int d_max_, int d_min_, uint64_t seed) noexcept {
  d_max = d_max_;
  d_min = d_min_;
  // Seed each submodule with an offset
  Status s = attn.init(d_max_, d_min_, seed + 10);
  if (!s.ok) return s;
  // For feed‑forward we use two linear layers with equal in/out dimension d_max
  s = ffn1.init(d_max_, d_max_, true, seed + 20);
  if (!s.ok) return s;
  s = ffn2.init(d_max_, d_max_, true, seed + 21);
  return s;
}

StatusOr<Tensor> ElasticBlock::forward(const Tensor& x, int d, const Tensor* mask) const noexcept {
  // Attention sublayer
  StatusOr<Tensor> maybe_attn = attn.forward(x, d, mask);
  if (!maybe_attn.status.ok) return maybe_attn;
  Tensor attn_out = std::move(maybe_attn.value);
  // Residual connection: add to input (slice input to d dims)
  StatusOr<Tensor> x_slice = Tensor::slice_last_dim(x, d);
  if (!x_slice.status.ok) return x_slice;
  StatusOr<Tensor> maybe_residual = add(attn_out, x_slice.value);
  if (!maybe_residual.status.ok) return maybe_residual;
  Tensor residual = std::move(maybe_residual.value);
  // Feed forward: first linear + activation + second linear
  StatusOr<Tensor> maybe_ff1 = ffn1.forward(residual, d);
  if (!maybe_ff1.status.ok) return maybe_ff1;
  Tensor ff1 = std::move(maybe_ff1.value);
  StatusOr<Tensor> maybe_gelu = gelu(ff1);
  if (!maybe_gelu.status.ok) return maybe_gelu;
  Tensor ff1_act = std::move(maybe_gelu.value);
  StatusOr<Tensor> maybe_ff2 = ffn2.forward(ff1_act, d);
  if (!maybe_ff2.status.ok) return maybe_ff2;
  Tensor ff2 = std::move(maybe_ff2.value);
  // Add residual from attention layer
  StatusOr<Tensor> out = add(ff2, residual);
  return out;
}

} // namespace elastic
