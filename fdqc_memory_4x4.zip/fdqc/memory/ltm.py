
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict
import time, hashlib
from .chunking import Chunk

def _hash_chunk(ch: Chunk) -> str:
    s = "|".join(str(u.value) for u in ch.items)
    return hashlib.sha256(s.encode()).hexdigest()

@dataclass
class LTM:
    counts: Dict[str, int] = field(default_factory=dict)
    schemas: Dict[str, dict] = field(default_factory=dict)
    promote_threshold: int = 3

    def observe(self, ch: Chunk) -> None:
        h = _hash_chunk(ch)
        self.counts[h] = self.counts.get(h, 0) + 1
        if self.counts[h] >= self.promote_threshold and h not in self.schemas:
            self.schemas[h] = {
                "created": time.time(),
                "size": len(ch.items),
                "repr": [str(u.value) for u in ch.items]
            }

    def is_promoted(self, ch: Chunk) -> bool:
        return _hash_chunk(ch) in self.schemas
