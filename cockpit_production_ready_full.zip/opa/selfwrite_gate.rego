package selfwrite

###############################
# Self‑write gate policy
#
# The input document is expected to have the following shape:
# {
#   "diff": string,       # unified diff containing proposed changes
#   "files": [string]    # list of file paths modified by the diff
# }
#
# This policy allows patches only when:
#   * all changed files reside under the cockpit_mod/ directory
#   * no forbidden patterns are present in the diff

# Default deny: only allow when conditions below are met
default allow = false

## Rule: allow if no forbidden patterns and all files are within cockpit_mod
allow {
    not forbidden
    all_allowed_paths
}

## Forbidden if diff contains any disallowed strings
forbidden {
    re_match("(?i)os\\.system", input.diff)
}

## All file paths are under cockpit_mod/
all_allowed_paths {
    count(input.files) > 0
    not some_disallowed_path
}

some_disallowed_path {
    filepath := input.files[_]
    not startswith(filepath, "cockpit_mod/")
}
