// semantic_memory.hpp
// Provides a simple mechanism for semantic memory compression and
// insight distillation.  This module sits on top of the episodic
// MemoryService.  It compresses a collection of episodic memories into
// a single semantic embedding and text summary (an "insight") and
// stores these insights in a separate table.  Retrieval from the
// semantic store uses the same squared L2 search as the episodic
// memory.

#pragma once

#include "elastic/memory_service.hpp"

namespace elastic {

// SemanticMemory wraps a MemoryService and provides methods to
// aggregate episodic memories into distilled insights.  Each insight
// summarises many episodes and is represented by an aggregated
// embedding and a textual summary.  This class uses the same
// underlying SQLite connection as the MemoryService.
struct InsightHit {
  int64_t id;
  float score;
  std::vector<float> emb;
  std::string summary;
  uint64_t ts_unix;
};

class SemanticMemory {
public:
  // Construct with an existing MemoryService.  The SemanticMemory
  // creates its own table ("insights") within the same database.
  explicit SemanticMemory(MemoryService &mem);

  // Aggregate all episodic memories into a single insight and store
  // it.  The aggregated embedding is the mean of all episode
  // embeddings; the summary is a concatenation of truncated
  // episode texts separated by newlines.  Returns OK on success
  // or an error status if the operation failed.
  Status CompressAll();

  // Search for semantic insights similar to the query embedding.  See
  // MemoryService::Search for semantics.  Returns a vector of
  // (distance, summary) pairs.
  StatusOr<std::vector<MemoryService::SearchResult>>
  SearchInsights(const Tensor &query, int k) const;

  // Return rich hit records for semantic insights, including the
  // embedding and timestamp.  If fewer than k insights exist in the
  // database all will be returned.
  StatusOr<std::vector<InsightHit>> SearchInsightsEmbeddings(const Tensor &query,
                                                            int k) const;

private:
  MemoryService &mem_;
  sqlite3 *db_ = nullptr;
  // Ensure the insights table exists.
  void EnsureSchema();
  // Helper to insert an insight into the table.
  Status PutInsight(const std::vector<float> &emb, const std::string &summary);
};

} // namespace elastic
