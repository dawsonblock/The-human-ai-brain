// epistemic_drive.h
//
// Stub for an epistemic drive controller.  The controller monitors
// prediction errors and triggers bursts of exploration when
// unexpected observations occur.  When a high sigma event is
// detected the controller may temporarily increase working memory
// dimensionality and allocate additional compute to resolve the
// anomaly.  This skeleton provides a minimal interface to detect
// anomalies and adjust a dimension.

#ifndef EPISTEMIC_DRIVE_H
#define EPISTEMIC_DRIVE_H

#include <cmath>

namespace epistemic_drive {

class EpistemicDrive {
public:
    EpistemicDrive(double sigma_threshold = 5.0) : sigma_threshold_(sigma_threshold) {}

    // Update with the latest prediction error (standard deviation
    // units).  Returns true if the error exceeds the threshold and a
    // burst of exploration should be triggered.
    bool update(double error_sigma) {
        return std::abs(error_sigma) >= sigma_threshold_;
    }
    // Adjust the sigma threshold dynamically.  Higher thresholds
    // reduce the frequency of exploratory bursts.
    void set_threshold(double sigma) { sigma_threshold_ = sigma; }
    double threshold() const { return sigma_threshold_; }
private:
    double sigma_threshold_;
};

} // namespace epistemic_drive

#endif // EPISTEMIC_DRIVE_H