# FDQC Memory Module (4x4=16)
Run: python -m fdqc.run_memory_demo
