// recall.cpp
// Implements the recall packer and WM integration functions.

#include "elastic/recall.hpp"
#include <cmath>
#include <iostream>

namespace elastic {

StatusOr<RecallPack> recall_pack(const Tensor &gw_1d,
                                MemoryService &mem,
                                SemanticMemory &sem,
                                const RecallConfig &cfg) noexcept {
  // Validate query shape
  if ((int)gw_1d.shape().size() != 1 || gw_1d.shape()[0] != cfg.d) {
    return StatusOr<RecallPack>(Status::Error("recall_pack: gw_1d must be 1D of length d"));
  }
  // Retrieve episodic hits
  auto epi_or = mem.SearchHits(gw_1d, cfg.k_episode, /*with_embeddings=*/true);
  if (!epi_or.status.ok) {
    return StatusOr<RecallPack>(epi_or.status);
  }
  std::vector<MemoryService::EpisodicHit> episodic = std::move(epi_or.value);
  // Retrieve semantic hits
  auto sem_or = sem.SearchInsightsEmbeddings(gw_1d, cfg.k_semantic);
  if (!sem_or.status.ok) {
    return StatusOr<RecallPack>(sem_or.status);
  }
  std::vector<SemanticMemory::InsightHit> semantic = std::move(sem_or.value);
  int k = (int)episodic.size() + (int)semantic.size();
  // Create output tensor [K,D]
  auto out_or = Tensor::make({k, cfg.d});
  if (!out_or.status.ok) {
    return StatusOr<RecallPack>(out_or.status);
  }
  Tensor vecs = out_or.value;
  // Fill zeros by default
  vecs.fill(0);
  // Copy episodic embeddings
  float *dst = vecs.as_span().data();
  int D = cfg.d;
  int row = 0;
  for (const auto &hit : episodic) {
    // If embedding shorter than D, copy available; if longer, truncate
    int n = std::min((int)hit.emb.size(), D);
    for (int j = 0; j < n; ++j) {
      dst[row * D + j] = hit.emb[j];
    }
    ++row;
  }
  // Copy semantic embeddings
  for (const auto &hit : semantic) {
    int n = std::min((int)hit.emb.size(), D);
    for (int j = 0; j < n; ++j) {
      dst[row * D + j] = hit.emb[j];
    }
    ++row;
  }
  // Normalise rows if requested
  if (cfg.normalize) {
    for (int i = 0; i < k; ++i) {
      float norm = 0.0f;
      for (int j = 0; j < D; ++j) {
        float v = dst[i * D + j];
        norm += v * v;
      }
      norm = std::sqrt(norm) + 1e-12f;
      for (int j = 0; j < D; ++j) {
        dst[i * D + j] /= norm;
      }
    }
  }
  RecallPack pack;
  pack.vecs = std::move(vecs);
  pack.episodic_meta = std::move(episodic);
  pack.semantic_meta = std::move(semantic);
  return StatusOr<RecallPack>(std::move(pack));
}

Status wm_integrate(Tensor &wm_slots, const Tensor &recall, int slot_offset) noexcept {
  // Validate dimensions
  if (wm_slots.shape().size() != 2 || recall.shape().size() != 2) {
    return Status::Error("wm_integrate: input tensors must be 2D");
  }
  int S = wm_slots.shape()[0];
  int D = wm_slots.shape()[1];
  int K = recall.shape()[0];
  int RD = recall.shape()[1];
  if (RD != D) {
    return Status::Error("wm_integrate: dimension mismatch between WM and recall");
  }
  // Determine how many rows we can copy
  int max_rows = S - slot_offset;
  int rows_to_copy = std::min(max_rows, K);
  if (rows_to_copy <= 0) return Status::OK();
  const float *src = recall.as_span().data();
  float *dst = wm_slots.as_span().data();
  for (int i = 0; i < rows_to_copy; ++i) {
    int dst_row = slot_offset + i;
    for (int j = 0; j < D; ++j) {
      dst[dst_row * D + j] = src[i * D + j];
    }
  }
  return Status::OK();
}

} // namespace elastic