#include "elastic/ops.hpp"
#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>

using namespace elastic;

int main() {
  // Test matmul
  {
    // A [2,3], B [3,4]
    StatusOr<Tensor> a = Tensor::make({2, 3});
    StatusOr<Tensor> b = Tensor::make({3, 4});
    assert(a.status.ok && b.status.ok);
    // Fill A = [ [0,1,2], [3,4,5] ]
    for (int i = 0; i < 2; ++i) {
      for (int j = 0; j < 3; ++j) {
        a.value.data()[i * 3 + j] = static_cast<float>(i * 3 + j);
      }
    }
    // Fill B = identity 3x4 truncated: row i has 1 at col i
    for (int i = 0; i < 3; ++i) {
      b.value.data()[i * 4 + i] = 1.0f;
    }
    auto c = matmul(a.value, b.value);
    assert(c.status.ok);
    // c should be shape [2,4], where c[i,j] = a[i,j] for j<3, 0 for j==3
    std::vector<int> expected_shape = {2,4};
    assert(c.value.shape() == expected_shape);
    float* cp = c.value.data();
    for (int i = 0; i < 2; ++i) {
      for (int j = 0; j < 3; ++j) {
        assert(std::abs(cp[i * 4 + j] - a.value.data()[i * 3 + j]) < 1e-6);
      }
      assert(std::abs(cp[i * 4 + 3]) < 1e-6);
    }
  }
  // Test add
  {
    StatusOr<Tensor> a = Tensor::make({2, 2});
    StatusOr<Tensor> b = Tensor::make({2, 2});
    assert(a.status.ok && b.status.ok);
    for (int i = 0; i < 4; ++i) {
      a.value.data()[i] = i;
      b.value.data()[i] = i * 0.5f;
    }
    auto c = add(a.value, b.value);
    assert(c.status.ok);
    for (int i = 0; i < 4; ++i) {
      assert(std::abs(c.value.data()[i] - (i + i * 0.5f)) < 1e-6);
    }
  }
  // Test gelu monotonicity and approximate identity around 0
  {
    StatusOr<Tensor> x = Tensor::make({1, 5});
    assert(x.status.ok);
    float vals[] = {-2.0f, -1.0f, 0.0f, 1.0f, 2.0f};
    for (int i = 0; i < 5; ++i) x.value.data()[i] = vals[i];
    auto y = gelu(x.value);
    assert(y.status.ok);
    // gelu should be increasing
    float* yp = y.value.data();
    for (int i = 0; i < 4; ++i) {
      assert(yp[i] < yp[i+1]);
    }
    // gelu(0) ~ 0
    assert(std::abs(yp[2]) < 1e-3);
  }
  // Test layernorm
  {
    StatusOr<Tensor> x = Tensor::make({2, 3});
    assert(x.status.ok);
    // Fill with constant rows to check zero mean and unit variance
    for (int i = 0; i < 6; ++i) x.value.data()[i] = static_cast<float>(i);
    auto y = layernorm(x.value);
    assert(y.status.ok);
    for (int b = 0; b < 2; ++b) {
      float mean = 0.0f;
      float var = 0.0f;
      for (int j = 0; j < 3; ++j) {
        float v = y.value.data()[b * 3 + j];
        mean += v;
        var += v * v;
      }
      mean /= 3.0f;
      var /= 3.0f;
      assert(std::abs(mean) < 1e-5);
      assert(std::abs(var - 1.0f) < 1e-5);
    }
  }
  // Test softmax sums to one
  {
    StatusOr<Tensor> x = Tensor::make({2, 4});
    assert(x.status.ok);
    for (int i = 0; i < 8; ++i) x.value.data()[i] = static_cast<float>(i);
    auto y = softmax_lastdim(x.value);
    assert(y.status.ok);
    for (int i = 0; i < 2; ++i) {
      float sum = 0.0f;
      for (int j = 0; j < 4; ++j) {
        sum += y.value.data()[i * 4 + j];
      }
      assert(std::abs(sum - 1.0f) < 1e-5);
    }
  }
  std::cout << "test_ops_cpu passed\n";
  return 0;
}