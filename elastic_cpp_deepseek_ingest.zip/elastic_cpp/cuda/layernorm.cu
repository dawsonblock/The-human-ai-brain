// Stub layernorm kernel.  Falls back to CPU implementation.
#include "elastic/ops.hpp"