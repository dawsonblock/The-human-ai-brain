// api_change.cpp
//
// HTTP API wiring for the change management endpoints.  This file
// builds a small REST API using Crow (a C++ micro web framework).
// Make sure to install or otherwise provide crow_all.h and
// nlohmann/json.hpp when compiling this file.  See README.md for
// compilation instructions.

#include "self_writer.h"

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <cstdlib>

#include "nlohmann/json.hpp"

// Include Crow.  Crow is a header‑only framework inspired by Flask.
// You must obtain crow_all.h separately (e.g. from
// https://github.com/CrowCpp/Crow) and place it on your include path.
#include "crow_all.h"

// Retrieve the change log directory from the environment or fall
// back to a default.  This helper is used by the API handlers.
static std::string get_change_dir() {
    const char *dir_env = std::getenv("CHANGE_LOG_DIR");
    return dir_env ? std::string(dir_env) : std::string("logs/changes");
}

int main(int argc, char **argv) {
    crow::SimpleApp app;

    // POST /change/apply
    CROW_ROUTE(app, "/change/apply").methods(crow::HTTPMethod::Post)([](const crow::request &req) {
        // mTLS/RBAC stub.  We require the caller to present a role
        // identifying header.  Internal callers should be authenticated via
        // mutual TLS; external calls may still use API key.  The
        // required role for write operations is "admin".  If the role is
        // missing or insufficient we return 403.
        std::string role = req.get_header_value("X-Role");
        if (role.empty()) {
            return crow::response(403, "forbidden: missing role");
        }
        // Accept comma‑separated roles; look for admin
        bool admin = false;
        {
            std::istringstream iss(role);
            std::string item;
            while (std::getline(iss, item, ',')) {
                std::string trimmed;
                std::remove_copy_if(item.begin(), item.end(), std::back_inserter(trimmed), ::isspace);
                if (trimmed == "admin" || trimmed == "writer") {
                    admin = true;
                    break;
                }
            }
        }
        if (!admin) {
            return crow::response(403, "forbidden: insufficient role");
        }
        // API key fallback (HMAC header).  If API_KEY is set the client
        // must provide a matching X-API-Key header.  This is retained
        // for backward compatibility.
        const char *env_key = std::getenv("API_KEY");
        if (env_key && *env_key) {
            auto hdr = req.get_header_value("X-API-Key");
            if (hdr.empty() || hdr != std::string(env_key)) {
                return crow::response(401, "unauthorized");
            }
        }
        // Replay protection: if X-Request-Timestamp is present check
        // that it is within 5 minutes of current time.  Accept ISO
        // 8601 or seconds since epoch.  Skip check if header absent.
        auto ts_hdr = req.get_header_value("X-Request-Timestamp");
        if (!ts_hdr.empty()) {
            try {
                // parse as integer seconds
                long long ts = std::stoll(ts_hdr);
                long long now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
                if (std::llabs(now - ts) > 300) {
                    return crow::response(401, "unauthorized: stale timestamp");
                }
            } catch (...) {
                // ignore malformed timestamp
            }
        }
        nlohmann::json body;
        try {
            body = nlohmann::json::parse(req.body);
        } catch (...) {
            return crow::response(400, "Invalid JSON body");
        }
        // JSON Schema validation: ensure required fields exist and are
        // of the expected type
        if (!body.contains("path") || !body["path"].is_string() ||
            !body.contains("new_content") || !body["new_content"].is_string() ||
            !body.contains("intent") || !body["intent"].is_string()) {
            return crow::response(400, "Missing or invalid required fields: path, new_content, intent");
        }
        std::string path = body["path"].get<std::string>();
        std::string new_content = body["new_content"].get<std::string>();
        // Reject overly large writes (>1 MiB) to protect server memory
        if (new_content.size() > (1 << 20)) {
            return crow::response(400, "new_content too large");
        }
        std::string author = body.contains("author") && body["author"].is_string() ? body["author"].get<std::string>() : std::string("auto-evolve");
        std::string intent = body["intent"].get<std::string>();
        nlohmann::json expl;
        const nlohmann::json *expl_ptr = nullptr;
        if (body.contains("explanation")) {
            expl = body["explanation"];
            expl_ptr = &expl;
        }
        try {
            auto res = self_writer::apply_change(path, new_content, author, intent, expl_ptr);
            nlohmann::json out;
            out["ok"] = true;
            out["report_id"] = res.report_id;
            out["snapshot"] = res.snapshot;
            out["new_sha256"] = res.new_sha256;
            return crow::response(out.dump());
        } catch (const std::exception &ex) {
            nlohmann::json out;
            out["ok"] = false;
            out["error"] = ex.what();
            return crow::response(500, out.dump());
        }
    });

    // GET /change/latest
    CROW_ROUTE(app, "/change/latest").methods(crow::HTTPMethod::Get)([](const crow::request &req) {
        // Require audit or admin role
        std::string role = req.get_header_value("X-Role");
        bool allowed = false;
        {
            std::istringstream iss(role);
            std::string item;
            while (std::getline(iss, item, ',')) {
                std::string trimmed;
                std::remove_copy_if(item.begin(), item.end(), std::back_inserter(trimmed), ::isspace);
                if (trimmed == "audit" || trimmed == "admin") {
                    allowed = true;
                    break;
                }
            }
        }
        if (!allowed) {
            return crow::response(403, "forbidden: insufficient role");
        }
        // Parse optional query parameter n
        std::size_t n = 10;
        if (req.url_params.get("n")) {
            try {
                n = std::stoul(req.url_params.get("n"));
            } catch (...) {
                return crow::response(400, "Invalid n parameter");
            }
        }
        std::string dir = get_change_dir();
        std::vector<std::filesystem::path> files;
        for (const auto &entry : std::filesystem::directory_iterator(dir)) {
            if (entry.path().extension() == ".json") {
                files.push_back(entry.path());
            }
        }
        // Sort descending by modification time (most recent first)
        std::sort(files.begin(), files.end(), [](const auto &a, const auto &b) {
            return std::filesystem::last_write_time(a) > std::filesystem::last_write_time(b);
        });
        nlohmann::json result = nlohmann::json::array();
        std::size_t count = std::min(n, files.size());
        for (std::size_t i = 0; i < count; ++i) {
            std::ifstream ifs(files[i]);
            if (!ifs) continue;
            try {
                nlohmann::json j = nlohmann::json::parse(ifs);
                result.push_back(j);
            } catch (...) {
                // ignore parse errors
            }
        }
        return crow::response(result.dump());
    });

    // GET /change/id/<rid>
    CROW_ROUTE(app, "/change/id/<string>").methods(crow::HTTPMethod::Get)([](const crow::request &req, const std::string &rid) {
        // Require audit or admin role
        std::string role = req.get_header_value("X-Role");
        bool allowed = false;
        {
            std::istringstream iss(role);
            std::string item;
            while (std::getline(iss, item, ',')) {
                std::string trimmed;
                std::remove_copy_if(item.begin(), item.end(), std::back_inserter(trimmed), ::isspace);
                if (trimmed == "audit" || trimmed == "admin") {
                    allowed = true;
                    break;
                }
            }
        }
        if (!allowed) {
            return crow::response(403, "forbidden: insufficient role");
        }
        std::string dir = get_change_dir();
        std::filesystem::path path = std::filesystem::path(dir) / (rid + ".json");
        if (!std::filesystem::exists(path)) {
            return crow::response(404, "not found");
        }
        std::ifstream ifs(path);
        if (!ifs) {
            return crow::response(500, "failed to read report");
        }
        try {
            nlohmann::json j = nlohmann::json::parse(ifs);
            return crow::response(j.dump());
        } catch (...) {
            return crow::response(500, "failed to parse report");
        }
    });

    // Start the HTTP server.  The port can be specified via the
    // command line (argv[1]) or defaults to 18080.  Use multiple
    // threads to handle concurrent requests.
    int port = 18080;
    if (argc > 1) {
        try {
            port = std::stoi(argv[1]);
        } catch (...) {
            // ignore invalid port argument
        }
    }
    app.port(static_cast<uint16_t>(port)).multithreaded().run();
}