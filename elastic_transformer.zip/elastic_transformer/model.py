
import torch, torch.nn as nn
from .elastic_block import ElasticBlock
class ElasticTransformer(nn.Module):
    def __init__(self, vocab:int, d_max:int=1024, d_min:int=256, layers:int=4):
        super().__init__()
        self.d_max = d_max; self.d_min = d_min; self.layers = layers
        self.embed = nn.Embedding(vocab, d_max)
        self.blocks = nn.ModuleList([ElasticBlock(d_max, d_min) for _ in range(layers)])
        self.ln_f = nn.LayerNorm(d_max)
        self.lm_head = nn.Linear(d_max, vocab, bias=False)
    def forward(self, idx: torch.Tensor, d:int, mask=None):
        x = self.embed(idx)
        for blk in self.blocks:
            x = blk(x, d, mask)
        x = self.ln_f(x)[...,:d]
        pad = torch.zeros_like(x.new_zeros(x.shape[:-1] + (self.d_max - d,)))
        x_full = torch.cat([x, pad], dim=-1)
        return self.lm_head(x_full)
