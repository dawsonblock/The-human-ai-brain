
import torch
from .model import ElasticTransformer
from .controller import WidthController

def test_forward_all_widths():
    vocab=64; B,T=1,8
    m = ElasticTransformer(vocab=vocab, d_max=1024, d_min=256, layers=1)
    ctrl = WidthController()
    for d in [256,512,768,1024]:
        x = torch.randint(0, vocab, (B,T))
        y = m(x, d)
        assert y.shape == (B,T,vocab)

if __name__ == "__main__":
    test_forward_all_widths()
    print("OK")
