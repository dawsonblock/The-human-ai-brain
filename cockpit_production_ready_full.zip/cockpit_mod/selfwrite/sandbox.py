"""
Sandbox runner for self‑writing patches.

Applies a proposed patch to a temporary working copy of the
repository and executes linting and test suites.  This stub
implementation pretends the patch always passes checks.
"""

from __future__ import annotations

from typing import Dict, Any
import tempfile
import subprocess
import shutil
import os


def try_apply_and_test(diff: str, repo_root: str) -> Dict[str, Any]:
    """Apply a diff and run syntax checks in isolation.

    This sandbox clones the repository to a temporary directory,
    attempts to apply the provided unified diff (if the `patch`
    utility is available) and then checks that all Python files
    compile without syntax errors.  It does not execute arbitrary
    code, reducing risk when running untrusted patches.

    Parameters
    ----------
    diff: str
        Unified diff to apply.  An empty diff results in no changes.
    repo_root: str
        The path to the repository root.

    Returns
    -------
    dict
        Dictionary with keys 'lint', 'format', 'tests', and 'logs'.
        Booleans indicate success.  The `tests` key reflects whether
        the syntax check succeeded.
    """
    # Create a temporary working copy
    workdir = tempfile.mkdtemp(prefix="cockpit_sandbox_")
    try:
        # Copy repository contents
        shutil.copytree(repo_root, workdir, dirs_exist_ok=True)
        # Try to apply the diff if the patch command exists
        patch_binary = shutil.which("patch")
        logs = ""
        if diff.strip():
            if patch_binary:
                try:
                    proc = subprocess.run(
                        [patch_binary, "-p1"],
                        input=diff.encode(),
                        cwd=workdir,
                        capture_output=True,
                        check=False,
                    )
                    if proc.returncode != 0:
                        return {
                            "lint": False,
                            "format": False,
                            "tests": False,
                            "logs": proc.stderr.decode() or proc.stdout.decode(),
                        }
                except Exception as e:
                    return {
                        "lint": False,
                        "format": False,
                        "tests": False,
                        "logs": str(e),
                    }
            else:
                # If we cannot apply the patch, log a warning and continue
                logs += "Warning: 'patch' utility not found, diff not applied; checking current code only.\n"
        # Recursively compile all Python files
        compile_errors = []
        for root, _, files in os.walk(workdir):
            for name in files:
                if name.endswith(".py"):
                    file_path = os.path.join(root, name)
                    proc = subprocess.run(
                        ["python", "-m", "py_compile", file_path],
                        capture_output=True,
                        text=True,
                    )
                    if proc.returncode != 0:
                        compile_errors.append((file_path, proc.stderr))
        success = len(compile_errors) == 0
        if compile_errors:
            for file_path, err in compile_errors:
                logs += f"{file_path}: {err}\n"
        else:
            logs += "Syntax checks passed"
        return {
            "lint": success,
            "format": success,
            "tests": success,
            "logs": logs.strip(),
        }
    finally:
        # Clean up the temporary directory
        shutil.rmtree(workdir, ignore_errors=True)