// reward.h
//
// Stub for an energy‑aware reinforcement learning reward function.
// The reward combines task performance (e.g. accuracy) with a
// penalty proportional to the energy consumed by the current
// working memory dimensionality.  The penalty discourages
// indiscriminate use of high dimensional states unless they yield
// significant gains.  This skeleton provides a simple linear trade
// off; real systems may learn a more sophisticated mapping.

#ifndef REWARD_H
#define REWARD_H

namespace reward {

// Compute the combined reward given task accuracy (or other positive
// term), the energy cost of the current dimension and a penalty
// coefficient lambda.  Returns accuracy minus lambda times the
// relative energy.  Users should adjust lambda to trade off between
// performance and energy consumption.
inline double energy_aware_reward(double accuracy, double energy_relative, double lambda) {
    return accuracy - lambda * energy_relative;
}

} // namespace reward

#endif // REWARD_H