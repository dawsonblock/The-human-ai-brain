// Placeholder header for DirectML kernels.  In a full implementation
// this would declare wrappers around DirectML operators.  The CPU
// reference implementation does not require any declarations.

#pragma once
