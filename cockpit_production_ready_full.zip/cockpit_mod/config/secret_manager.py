"""
Secret manager stub.

In production this module should fetch secrets from a secure
vault such as HashiCorp Vault or a cloud provider.  In this
stub implementation, secrets are read from environment variables.
"""

from __future__ import annotations

import os


def get_secret(name: str) -> str:
    """Retrieve a secret by name.

    If the secret is not found, raises a KeyError.
    """
    value = os.environ.get(name)
    if value is None:
        raise KeyError(f"Secret {name} not set in environment")
    return value
