// Implementation of the elastic Transformer top level.

#include "elastic/transformer.hpp"
#include "elastic/rng.hpp"
#include "elastic/ops.hpp"

#include <cassert>

namespace elastic {

Status Transformer::init(const TransformerConfig& config, uint64_t seed) noexcept {
  cfg = config;
  // Allocate embedding matrix [vocab, D_MAX]
  StatusOr<Tensor> maybe_embed = Tensor::make({cfg.vocab, cfg.d_max});
  if (!maybe_embed.status.ok) return maybe_embed.status;
  embed = std::move(maybe_embed.value);
  // Initialise embeddings uniformly
  Rng rng;
  rng.init(seed + 100);
  float* emb_ptr = embed.data();
  size_t n = static_cast<size_t>(cfg.vocab) * static_cast<size_t>(cfg.d_max);
  for (size_t i = 0; i < n; ++i) {
    emb_ptr[i] = (rng.uniform() * 2.0f - 1.0f) * 0.01f;
  }
  // Create blocks
  blocks.resize(cfg.layers);
  for (int i = 0; i < cfg.layers; ++i) {
    Status s = blocks[i].init(cfg.d_max, cfg.d_min, seed + 200 + i);
    if (!s.ok) return s;
  }
  // Initialise language modelling head
  Status s = lm_head.init(cfg.vocab, cfg.d_max, true, seed + 300);
  if (!s.ok) return s;
  return Status::OK();
}

StatusOr<Tensor> Transformer::forward(const Tensor& idx, int d, const Tensor* mask) const noexcept {
  // idx should be integer indices of shape [B,T]
  const auto& idims = idx.shape();
  if (idims.size() != 2) {
    return StatusOr<Tensor>(Status::Error("Input indices must be 2‑D [B,T]"));
  }
  int B = idims[0];
  int T = idims[1];
  if (d < cfg.d_min || d > cfg.d_max) {
    return StatusOr<Tensor>(Status::Error("Invalid width for transformer"));
  }
  // Create input embeddings tensor [B,T,d]
  StatusOr<Tensor> maybe_x = Tensor::make({B, T, d});
  if (!maybe_x.status.ok) return maybe_x;
  Tensor x = std::move(maybe_x.value);
  float* x_ptr = x.data();
  const float* emb_ptr = embed.data();
  const float* idx_ptr = idx.data();
  for (int b = 0; b < B; ++b) {
    for (int t_ = 0; t_ < T; ++t_) {
      int token = static_cast<int>(idx_ptr[b * static_cast<size_t>(T) + t_]);
      if (token < 0 || token >= cfg.vocab) {
        return StatusOr<Tensor>(Status::Error("Token out of range"));
      }
      const float* row = emb_ptr + static_cast<size_t>(token) * cfg.d_max;
      float* dst = x_ptr + ((b * T + t_) * d);
      for (int i = 0; i < d; ++i) {
        dst[i] = row[i];
      }
    }
  }
  // Pass through blocks
  for (const auto& blk : blocks) {
    StatusOr<Tensor> maybe_y = blk.forward(x, d, mask);
    if (!maybe_y.status.ok) return maybe_y;
    x = std::move(maybe_y.value);
  }
  // Language modelling head: maps d to vocab
  StatusOr<Tensor> maybe_logits = lm_head.forward(x, d);
  if (!maybe_logits.status.ok) return maybe_logits;
  Tensor logits = std::move(maybe_logits.value);
  return StatusOr<Tensor>(std::move(logits));
}

} // namespace elastic
