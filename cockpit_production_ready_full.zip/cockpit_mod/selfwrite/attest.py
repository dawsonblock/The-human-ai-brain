"""
Attestation utilities for self‑write.

This module generates simple attestations for diffs by computing a
hash of the proposed patch and writing it to disk.  A timestamped
record helps trace when and what was changed.
"""

from __future__ import annotations

import hashlib
import os
import time
from typing import Dict


def attest_patch(diff: str, output_dir: str = "attestations") -> Dict[str, str]:
    """Create an attestation record for a patch.

    Parameters
    ----------
    diff: str
        Unified diff string to attest.
    output_dir: str
        Directory to store attestation files.  Defaults to ``attestations``.

    Returns
    -------
    dict
        A dictionary containing the SHA256 hash and the path to the
        attestation file.
    """
    os.makedirs(output_dir, exist_ok=True)
    # Compute a sha256 hash of the diff
    hash_value = hashlib.sha256(diff.encode()).hexdigest()
    timestamp = int(time.time())
    filename = f"{timestamp}_{hash_value[:8]}.txt"
    path = os.path.join(output_dir, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(diff)
    return {"hash": hash_value, "file": path}
