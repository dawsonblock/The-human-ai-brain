// memory_service.hpp
// Provides a simple persistent memory service backed by SQLite and
// approximate search over embeddings. This service stores a sequence of
// key–value episodes where the key is a dense embedding (flattened
// vector of floats) and the value is an arbitrary text payload. It
// exposes put() to insert new memories and search() to retrieve the
// nearest neighbours to a query embedding.  The implementation uses
// SQLite for persistence and performs a brute‑force L2 search over all
// stored embeddings. Although a vector index such as FAISS would be
// preferable for large memories, a sequential scan is sufficient for
// moderate collection sizes and simplifies the build without
// external dependencies.  See memory_service.cpp for details.

#pragma once

#include <string>
#include <vector>
#include "elastic/status.hpp"
#include "elastic/tensor.hpp"

struct sqlite3;

namespace elastic {

// MemoryService is a lightweight long‑term memory store. Each record
// consists of a floating point embedding and an associated text. The
// embeddings may be of arbitrary dimensionality; they will be
// flattened into a 1D vector before storage. The service writes to
// SQLite to maintain persistence across program runs.
class MemoryService {
public:
  // Construct a memory service, opening (and creating if needed)
  // the database at the given path.  The database schema is
  // initialized on first construction.  The path may be relative or
  // absolute; use an absolute path when you need a known location.
  explicit MemoryService(const std::string &db_path);

  // Destructor closes the SQLite database.
  ~MemoryService();

  // Insert a new memory into the store.  The embedding tensor may
  // have any shape; it will be flattened row‑major and stored as a
  // binary blob along with its dimensionality.  The text payload
  // should be a UTF‑8 string.  Returns Status::OK on success or an
  // error status on failure.
  // Insert a new memory into the store.  The embedding tensor may
  // have any shape; it will be flattened row‑major and stored as a
  // binary blob along with its dimensionality.  The text payload
  // should be a UTF‑8 string.  Reward and timestamp allow the caller
  // to attach additional metadata to the episode.  Returns
  // Status::OK on success or an error status on failure.
  Status Put(const Tensor &embedding, const std::string &text,
             float reward = 0.0f, uint64_t ts_unix = 0);

  // Search for the k nearest neighbours to the given query
  // embedding.  Returns a StatusOr containing a vector of
  // (distance, text) pairs.  If fewer than k items exist in the
  // database, all items are returned.  Distances are squared L2
  // distances.  An error status indicates a database failure.
  using SearchResult = std::pair<float, std::string>;
  StatusOr<std::vector<SearchResult>> Search(const Tensor &query, int k) const;

  // Rich episodic hit record.  Contains the row id, distance (score),
  // optionally the full embedding, the stored text, reward and a
  // timestamp.  Distances are squared L2 distances between the query
  // and the stored embedding.  A smaller score indicates a closer
  // match.
  struct EpisodicHit {
    int64_t id;
    float score;
    std::vector<float> emb;
    std::string text;
    float reward;
    uint64_t ts_unix;
  };

  // Search for the k nearest neighbours to the given query embedding
  // and return rich hit records.  If with_embeddings is false, the
  // emb field in each result will be left empty to avoid the cost of
  // decoding and copying the stored embedding.  If fewer than k
  // items exist in the database, all items are returned.  An error
  // status indicates a database failure.
  StatusOr<std::vector<EpisodicHit>> SearchHits(const Tensor &query, int k,
                                               bool with_embeddings = true) const;

  // Clear all stored memories.  This is primarily useful for
  // testing.  Note that this operation permanently deletes data on
  // disk.
  Status Clear();

  // Grant SemanticMemory access to internal SQLite handle.  This
  // allows the semantic layer to reuse the database connection for
  // insight storage without exposing private details more broadly.
  friend class SemanticMemory;

private:
  sqlite3 *db_ = nullptr;
};

} // namespace elastic
