#include "elastic/transformer.hpp"
#include "elastic/rng.hpp"
#include <cassert>
#include <cmath>
#include <iostream>

using namespace elastic;

int main() {
  TransformerConfig cfg;
  cfg.vocab = 16;
  cfg.layers = 2;
  cfg.d_max = 8;
  cfg.d_min = 4;
  Transformer model;
  assert(model.init(cfg, 55).ok);
  // Create indices tensor [2,3]
  StatusOr<Tensor> maybe_idx = Tensor::make({2, 3});
  assert(maybe_idx.status.ok);
  Tensor idx = std::move(maybe_idx.value);
  // Fill with deterministic indices
  float* ip = idx.data();
  for (int i = 0; i < 6; ++i) {
    ip[i] = static_cast<float>(i % cfg.vocab);
  }
  for (int d : {4, 6, 8}) {
    auto out = model.forward(idx, d, nullptr);
    assert(out.status.ok);
    Tensor y = std::move(out.value);
    // shape [2,3,vocab]
    auto sh = y.shape();
    assert(sh.size() == 3);
    assert(sh[0] == 2 && sh[1] == 3 && sh[2] == cfg.vocab);
    // Check finite
    for (size_t i = 0; i < y.size(); ++i) {
      assert(std::isfinite(y.data()[i]));
    }
  }
  std::cout << "test_model_cpu passed\n";
  return 0;
}