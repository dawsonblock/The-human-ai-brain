// Implementation of primitive operations for the elastic Transformer.  This
// file defines the CPU reference implementations and dispatches
// globally visible functions through a backend abstraction.

#include "elastic/ops.hpp"
#include "elastic/backend.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <memory>
#include <mutex>
#ifdef _OPENMP
#include <omp.h>
#endif

namespace elastic {

// Forward declarations of CPU reference implementations
static StatusOr<Tensor> matmul_cpu(const Tensor& a, const Tensor& b) noexcept;
static StatusOr<Tensor> add_cpu(const Tensor& a, const Tensor& b) noexcept;
static StatusOr<Tensor> gelu_cpu(const Tensor& x) noexcept;
static StatusOr<Tensor> layernorm_cpu(const Tensor& x, float epsilon) noexcept;
static StatusOr<Tensor> softmax_lastdim_cpu(const Tensor& x) noexcept;

// Backend pointer and initialisation
static std::unique_ptr<Backend> g_backend;
static std::once_flag backend_init_flag;

Backend* get_backend() noexcept {
  std::call_once(backend_init_flag, []() { initialize_best_backend(); });
  return g_backend.get();
}

// CPU backend implementation
class CpuBackend : public Backend {
public:
  StatusOr<Tensor> matmul(const Tensor& a, const Tensor& b) noexcept override {
    return matmul_cpu(a, b);
  }
  StatusOr<Tensor> add(const Tensor& a, const Tensor& b) noexcept override {
    return add_cpu(a, b);
  }
  StatusOr<Tensor> gelu(const Tensor& x) noexcept override {
    return gelu_cpu(x);
  }
  StatusOr<Tensor> layernorm(const Tensor& x, float epsilon) noexcept override {
    return layernorm_cpu(x, epsilon);
  }
  StatusOr<Tensor> softmax_lastdim(const Tensor& x) noexcept override {
    return softmax_lastdim_cpu(x);
  }
};

// Initialise backend; currently selects CPU only
void initialize_best_backend() noexcept {
  // In future, detect CUDA/DirectML here
  g_backend = std::make_unique<CpuBackend>();
}

// Public API functions dispatch to backend
StatusOr<Tensor> matmul(const Tensor& a, const Tensor& b) noexcept {
  return get_backend()->matmul(a, b);
}
StatusOr<Tensor> add(const Tensor& a, const Tensor& b) noexcept {
  return get_backend()->add(a, b);
}
StatusOr<Tensor> gelu(const Tensor& x) noexcept {
  return get_backend()->gelu(x);
}
StatusOr<Tensor> layernorm(const Tensor& x, float epsilon) noexcept {
  return get_backend()->layernorm(x, epsilon);
}
StatusOr<Tensor> softmax_lastdim(const Tensor& x) noexcept {
  return get_backend()->softmax_lastdim(x);
}

// Helper to compute outer size (product of dims except last)
static inline size_t outer_size(const std::vector<int>& dims) {
  if (dims.empty()) return 0;
  size_t n = 1;
  for (size_t i = 0; i < dims.size() - 1; ++i) {
    n *= static_cast<size_t>(dims[i]);
  }
  return n;
}

// CPU implementations (reference) with optional OpenMP parallelisation

static StatusOr<Tensor> matmul_cpu(const Tensor& a, const Tensor& b) noexcept {
  const auto& ad = a.shape();
  const auto& bd = b.shape();
  if (ad.empty() || bd.size() < 2) {
    return StatusOr<Tensor>(Status::Error("Invalid shapes for matmul"));
  }
  size_t batch = 1;
  int M, K;
  if (ad.size() == 2) {
    M = ad[0];
    K = ad[1];
  } else if (ad.size() == 3) {
    batch = static_cast<size_t>(ad[0]);
    M = ad[1];
    K = ad[2];
  } else {
    return StatusOr<Tensor>(Status::Error("Unsupported rank for A"));
  }
  int K2, N;
  if (bd.size() == 2) {
    K2 = bd[0];
    N = bd[1];
  } else {
    return StatusOr<Tensor>(Status::Error("Unsupported rank for B"));
  }
  if (K != K2) {
    return StatusOr<Tensor>(Status::Error("Inner dimensions mismatch"));
  }
  // Create output shape [batch,M,N] or [M,N]
  std::vector<int> out_shape;
  if (batch > 1) {
    out_shape = {static_cast<int>(batch), M, N};
  } else {
    out_shape = {M, N};
  }
  StatusOr<Tensor> maybe_out = Tensor::make(out_shape);
  if (!maybe_out.status.ok) return maybe_out;
  Tensor out = std::move(maybe_out.value);
  float* out_ptr = out.data();
  const float* a_ptr = a.data();
  const float* b_ptr = b.data();
  // Parallelise over batch dimension if available
  #pragma omp parallel for if (batch > 1)
  for (size_t b_i = 0; b_i < batch; ++b_i) {
    for (int i = 0; i < M; ++i) {
      for (int j = 0; j < N; ++j) {
        float sum = 0.0f;
        for (int k = 0; k < K; ++k) {
          size_t a_index;
          if (ad.size() == 3) {
            a_index = b_i * static_cast<size_t>(M) * K + i * static_cast<size_t>(K) + k;
          } else {
            a_index = i * static_cast<size_t>(K) + k;
          }
          size_t b_index = k * static_cast<size_t>(N) + j;
          sum += a_ptr[a_index] * b_ptr[b_index];
        }
        size_t out_index;
        if (out_shape.size() == 3) {
          out_index = b_i * static_cast<size_t>(M) * N + i * static_cast<size_t>(N) + j;
        } else {
          out_index = i * static_cast<size_t>(N) + j;
        }
        out_ptr[out_index] = sum;
      }
    }
  }
  return StatusOr<Tensor>(std::move(out));
}

static StatusOr<Tensor> add_cpu(const Tensor& a, const Tensor& b) noexcept {
  if (a.shape() != b.shape()) {
    return StatusOr<Tensor>(Status::Error("Add shape mismatch"));
  }
  StatusOr<Tensor> maybe_out = Tensor::make(a.shape());
  if (!maybe_out.status.ok) return maybe_out;
  Tensor out = std::move(maybe_out.value);
  float* out_ptr = out.data();
  const float* a_ptr = a.data();
  const float* b_ptr = b.data();
  size_t n = out.size();
  // Parallelise the loop for large tensors
  #pragma omp parallel for if (n > 1024)
  for (size_t i = 0; i < n; ++i) {
    out_ptr[i] = a_ptr[i] + b_ptr[i];
  }
  return StatusOr<Tensor>(std::move(out));
}

static StatusOr<Tensor> gelu_cpu(const Tensor& x) noexcept {
  StatusOr<Tensor> maybe_out = Tensor::make(x.shape());
  if (!maybe_out.status.ok) return maybe_out;
  Tensor out = std::move(maybe_out.value);
  const float* in_ptr = x.data();
  float* out_ptr = out.data();
  size_t n = out.size();
  // Parallelise if enough work
  #pragma omp parallel for if (n > 1024)
  for (size_t i = 0; i < n; ++i) {
    float v = in_ptr[i];
    // Exact GELU using error function for higher precision
    out_ptr[i] = 0.5f * v * (1.0f + std::erf(v / std::sqrt(2.0f)));
  }
  return StatusOr<Tensor>(std::move(out));
}

static StatusOr<Tensor> layernorm_cpu(const Tensor& x, float epsilon) noexcept {
  const auto& dims = x.shape();
  if (dims.empty()) {
    return StatusOr<Tensor>(Status::Error("Cannot normalise 0‑D tensor"));
  }
  int d = dims.back();
  size_t outer = outer_size(dims);
  StatusOr<Tensor> maybe_out = Tensor::make(dims);
  if (!maybe_out.status.ok) return maybe_out;
  Tensor out = std::move(maybe_out.value);
  const float* in_ptr = x.data();
  float* out_ptr = out.data();
  // Parallelise across rows
  #pragma omp parallel for if (outer > 1)
  for (size_t i = 0; i < outer; ++i) {
    const float* row = in_ptr + i * d;
    float* dst = out_ptr + i * d;
    float mean = 0.0f;
    float var = 0.0f;
    for (int j = 0; j < d; ++j) {
      mean += row[j];
    }
    mean /= static_cast<float>(d);
    for (int j = 0; j < d; ++j) {
      float diff = row[j] - mean;
      var += diff * diff;
    }
    var /= static_cast<float>(d);
    float denom = 1.0f / std::sqrt(var + epsilon);
    for (int j = 0; j < d; ++j) {
      dst[j] = (row[j] - mean) * denom;
    }
  }
  return StatusOr<Tensor>(std::move(out));
}

static StatusOr<Tensor> softmax_lastdim_cpu(const Tensor& x) noexcept {
  const auto& dims = x.shape();
  if (dims.empty()) {
    return StatusOr<Tensor>(Status::Error("Cannot softmax 0‑D tensor"));
  }
  int d = dims.back();
  size_t outer = outer_size(dims);
  StatusOr<Tensor> maybe_out = Tensor::make(dims);
  if (!maybe_out.status.ok) return maybe_out;
  Tensor out = std::move(maybe_out.value);
  const float* in_ptr = x.data();
  float* out_ptr = out.data();
  // Parallelise across rows
  #pragma omp parallel for if (outer > 1)
  for (size_t i = 0; i < outer; ++i) {
    const float* row = in_ptr + i * d;
    float* dst = out_ptr + i * d;
    float max_val = row[0];
    for (int j = 1; j < d; ++j) max_val = std::max(max_val, row[j]);
    float sum = 0.0f;
    for (int j = 0; j < d; ++j) {
      dst[j] = std::exp(row[j] - max_val);
      sum += dst[j];
    }
    float inv_sum = 1.0f / sum;
    for (int j = 0; j < d; ++j) {
      dst[j] *= inv_sum;
    }
  }
  return StatusOr<Tensor>(std::move(out));
}

} // namespace elastic
