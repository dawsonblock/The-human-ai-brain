# C++ Port of Cockpit Self‑Write and Auto‑Evolve

This directory contains a C++ re‑implementation of the Python
`self_writer`, `change_audit`, `change_gate` and related modules.  The
goal of this port is to provide a production‑grade, statically typed
foundation for auto‑evolving systems.  The design mirrors the
behaviour of the Python version:

* A **kill switch** halts all operations when tripped.
* All file writes go through a single **self writer** entry point
  (`apply_change`), which builds a detailed **change report**, runs
  the **moral core**, generates or accepts an **explanation**, passes
  the explanation through a **change gate** and writes the file
  atomically.
* Change reports are persisted as JSON under `logs/changes/`, and a
  snapshot of the previous file state is saved under
  `logs/changes/snapshots/` for rollback.
* A lightweight HTTP API is provided via [Crow](https://github.com/CrowCpp/Crow) in
  `src/api_change.cpp`.  The API exposes the same endpoints as the
  Python FastAPI version: `POST /change/apply`, `GET /change/latest`
  and `GET /change/id/<rid>`.
* Numerous **intelligence stubs** live under `include/`.  These
  headers declare skeleton classes for a VCCA controller, pre‑conscious
  buffer, episodic memory store, chunker, collapse loop, affective
  core, theory of mind, imagination engine, meta monitor, epistemic
  drive and energy‑aware reward.  Each stub outlines its purpose and
  exposes minimal state or behaviour to facilitate incremental
  development.

## Building

This project uses only the C++ standard library and two external
header‑only dependencies:

1. **[nlohmann/json](https://github.com/nlohmann/json)** — used for parsing and
   emitting JSON.  Download `json.hpp` from the project and place it
   somewhere on your include path.  On many systems you can install
   the `nlohmann-json` package via your package manager.
2. **[Crow](https://github.com/CrowCpp/Crow)** — a micro web framework for C++.
   Download `crow_all.h` from the Crow repository and place it on
   your include path.  Crow depends on Boost.Asio for network I/O
   but uses the header‑only `asio` shipped with Crow when compiled
   with the `-DCROW_MAIN` flag.

You can build the HTTP server like so (assuming `json.hpp` and
`crow_all.h` are in `/usr/include`):

```sh
g++ -std=c++17 -O2 -I/usr/include -pthread \
    src/api_change.cpp src/self_writer.cpp src/kill.cpp src/moral_core.cpp \
    src/change_audit.cpp src/change_gate.cpp src/explainer.cpp \
    -o cockpit_server

# Run the server on port 18080 (default)
./cockpit_server

# Apply a change via curl (example)
curl -X POST http://localhost:18080/change/apply -H "Content-Type: application/json" -d '{
  "path":"example.txt",
  "new_content":"Hello, world!\n",
  "intent":"initial commit",
  "author":"developer",
  "explanation":{
    "why":"Create a greeting file for testing purposes. Added defs: n/a. Removed defs: n/a. Diff hash 0 for file example.txt. Update aligns with described behaviour.",
    "risk":"None", "backout":"Delete the file", "tests":"Manual inspection", "touched_symbols":[]
  }
}'

# List recent reports
curl http://localhost:18080/change/latest?n=5
```

If you prefer not to include Crow you can ignore `api_change.cpp` and
instead call `self_writer::apply_change` directly from your own
application.  The moral core, change gate and explainer are decoupled
from the HTTP layer.

## Notes and Limitations

* The `pseudo_sha256` function in `change_audit.cpp` is a placeholder.
  For real tamper evidence you should replace it with a true
  SHA‑256 implementation, such as [picosha2](https://github.com/okdshin/PicoSHA2)
  or `OpenSSL`'s `SHA256()`.
* The AST delta computation is heuristic and may miss complex C++
  constructs.  It currently detects top‑level functions and classes by
  regex; you can substitute a real parser such as libclang for
  improved accuracy.
* The moral core stub always allows changes.  Integrate your own
  policy engine by implementing `moral_core::choose`.
* The intelligence modules are empty scaffolds.  See
  `intelligence_enhancements.md` in the parent directory for a high‑level
  description of the intended functionality.

## Directory Structure

```
include/          // Public headers for kill, change_audit, change_gate, self_writer, etc.
src/              // Source files implementing the modules and API
src/tools/        // Command line utilities (e.g. reexplain_change)
logs/changes/     // Change reports are written here at runtime
logs/changes/snapshots/ // Snapshots of files before modification
README.md         // This file
```
