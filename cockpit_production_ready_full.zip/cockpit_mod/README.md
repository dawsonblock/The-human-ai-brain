# AI Cockpit

This repository contains a minimal implementation of a universal AI cockpit
with a working memory gate inspired by the Finite‑Dimensional Quantum
Consciousness (FDQC) theory.  It exposes a FastAPI service for chat
completions and provides a modular architecture for model selection,
memory retrieval, and response generation.

## Architecture Overview

The pipeline consists of several stages:

1. **Ingress**
   - HTTP requests to `/chat` are authenticated via an API key and passed
     to `handle_chat()` in the orchestrator.

2. **Model Selection**
   - A registry loads model adapters from `config/models.yaml`.  If
     multiple models are available, `router.choose_model()` can
     implement custom routing logic.

3. **Working Memory Gate**
   - A `WorkingMemory` instance maintains a 4‑dimensional state vector.
     Each user prompt is embedded via the selected model; the entropy of
     the current state is computed, and if it exceeds a configurable
     threshold (default ≈ 1.39 bits), the state collapses and resets to
     the new embedding.  Otherwise the state blends towards the new
     embedding.  This mechanism prevents hallucination drift and
     implements a form of attention gate.

4. **Context Recall**
   - If the working memory has not collapsed, episodic and semantic
     vectors are recalled from an `ElasticMemory` store.  The recalled
     vectors are injected as a `<wm>[...]</wm>` system message.

5. **Generation**
   - A model adapter generates a response given the user prompt and
     optional recall context.

6. **Persistence**
   - The response is embedded and stored in episodic memory.  A simple
     compression routine groups old memories into semantic clusters.

For a detailed description of the pipeline and its tuning options, see
`orchestrator/__init__.py` and `working_memory.py`.

## Running the Server

Install dependencies (for example in a virtual environment):

```bash
pip install -r requirements.txt
```

Then run the service:

```bash
python -m cockpit_mod.run_server
```

By default the service listens on `0.0.0.0:8000`.  You can override
`PORT` and `HOST` via environment variables.  An example `COCKPIT_API_KEYS`
environment variable must be set to a comma‑separated list of allowed
API keys for authentication.

```bash
export COCKPIT_API_KEYS=mysecretkey
python -m cockpit_mod.run_server
```

## Configuration

Models are configured via `config/models.yaml`.  Each entry defines a
model name, adapter type, and parameters.  See `adapters/llama_cpp.py`
for an example adapter.  To use a local Llama model, set the `path`
parameter to the GGUF/GGML file and adjust context and GPU layers as
needed.

Working memory parameters and file paths can be overridden via
environment variables:

- `COCKPIT_MODELS_CONFIG` – path to models YAML file
- `COCKPIT_ELASTIC_DLL` – path to elastic memory DLL (unused if absent)
- `COCKPIT_MEMORY_DB` – path to the episodic memory database file
- `COCKPIT_WM_THRESHOLD` – entropy threshold in bits
- `COCKPIT_WM_DECAY` – blending factor for working memory updates

## Additional Components

Several auxiliary modules support production deployment:

- **Settings**: `cockpit_mod/config/settings.py` defines a pydantic
  configuration model loaded from environment variables.
- **Telemetry**: `cockpit_mod/orchestrator/telemetry.py` configures
  OpenTelemetry tracing for FastAPI endpoints.
- **Router Rules**: `cockpit_mod/orchestrator/router_rules.py`
  implements heuristics for model selection based on input length.
- **Validators**: `cockpit_mod/orchestrator/validators.py` provides
  JSON schema validation and grounding checks to ensure outputs
  reference retrieved sources.
- **Qdrant Store**: `cockpit_mod/memory/qdrant_store.py` wraps a
  Qdrant vector database and supports namespaced vector storage.
- **Self‑write Pipeline**: modules under `cockpit_mod/selfwrite` implement
  gate, sandbox, tests runner, and attestation functions to enable safe
  self‑modifying code.  Policies restrict which files may be changed
  and block unsafe patterns.
- **Infrastructure**: the `infra/` directory contains Docker Compose and
  Kubernetes manifests to deploy the API along with Qdrant, vLLM, Redis,
  Prometheus, and Grafana.  See `RUNBOOK.md` for deployment details.
- **Continuous Integration**: a GitHub Actions workflow in
  `.github/workflows/ci.yml` compiles the code, runs security scans, and
  builds a Docker image on each push.
- **Documentation**: `SECURITY.md` details security practices and
  `RUNBOOK.md` provides operational guidance.

## Caveats

This implementation is a skeleton intended for extension:

- The `selfwrite` modules are stubs; they demonstrate the expected
  control flow but do not perform real code generation or patching.
- The `ElasticMemory` class falls back to an in‑memory store if the
  compiled C++ library is unavailable.  For production use you should
  replace this with a vector database or proper storage backend.
- The model adapters provided here are minimal examples; integrate
  production‑ready adapters such as vLLM, HuggingFace Transformers, or
  llama.cpp for better performance and features.