// Ragged key/value cache used for incremental decoding.

#pragma once

#include "elastic/status.hpp"
#include "elastic/tensor.hpp"

#include <unordered_map>

namespace elastic {

struct KVBucket {
  Tensor k;
  Tensor v;
};

struct RaggedKVCache {
  std::unordered_map<int, KVBucket> buckets;

  // Retrieve a bucket for a given width.  Creates an empty bucket on first use.
  KVBucket& get(int d) {
    return buckets[d];
  }

  // Clear all buckets.
  void clear() {
    buckets.clear();
  }

  // Placeholder for merging caches across widths.  Not implemented in v4.
  Status project_merge(int /*d_old*/, int /*d_new*/) {
    return Status::Error("UNIMPLEMENTED");
  }
};

} // namespace elastic
