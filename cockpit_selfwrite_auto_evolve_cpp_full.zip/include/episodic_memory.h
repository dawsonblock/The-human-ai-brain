// episodic_memory.h
//
// Stub for an episodic memory module.  Episodic memory stores key
// experiences or episodes and allows for retrieval via vector search
// or other similarity metrics.  This skeleton defines a simple
// interface; implementers should supply an underlying storage and
// retrieval engine.

#ifndef EPISODIC_MEMORY_H
#define EPISODIC_MEMORY_H

#include <string>
#include <vector>
#include <utility>

namespace episodic_memory {

class EpisodicMemory {
public:
    // Record an episode with an embedding and associated metadata.
    void record(const std::vector<float> &embedding, const std::string &metadata) {
        // TODO: store embeddings in a vector database and metadata in an
        // accompanying structure.  This stub simply appends to
        // in‑memory vectors.
        embeddings_.push_back(embedding);
        metadatas_.push_back(metadata);
    }

    // Retrieve the k most similar episodes to the provided embedding.
    // Real implementations would compute cosine or Euclidean distance
    // and return a list sorted by similarity.  Here we simply return
    // the most recently recorded items.
    std::vector<std::pair<std::vector<float>, std::string>> retrieve(const std::vector<float> &embedding, std::size_t k) const {
        (void)embedding;
        std::vector<std::pair<std::vector<float>, std::string>> results;
        for (std::size_t i = 0; i < embeddings_.size() && results.size() < k; ++i) {
            results.push_back({embeddings_[embeddings_.size() - 1 - i], metadatas_[metadatas_.size() - 1 - i]});
        }
        return results;
    }

private:
    std::vector<std::vector<float>> embeddings_;
    std::vector<std::string> metadatas_;
};

} // namespace episodic_memory

#endif // EPISODIC_MEMORY_H