"""
Test runner for self‑write patches.

This module provides a simple interface to execute tests and lint
checks in an isolated environment.  It wraps the sandbox layer and
can be extended to include unit, integration, or property tests.
"""

from __future__ import annotations

from typing import Dict, Any

from .sandbox import try_apply_and_test


def run_tests(diff: str, repo_root: str) -> Dict[str, Any]:
    """Run tests against a proposed patch.

    Parameters
    ----------
    diff: str
        Unified diff produced by the proposer.
    repo_root: str
        Path to the repository root to copy for isolated testing.

    Returns
    -------
    dict
        Same keys as returned by try_apply_and_test.
    """
    return try_apply_and_test(diff, repo_root)
