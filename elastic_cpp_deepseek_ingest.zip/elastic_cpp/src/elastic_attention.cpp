// Implementation of the elastic attention mechanism.

#include "elastic/elastic_attention.hpp"
#include "elastic/ops.hpp"

#include <algorithm>
#include <cmath>
#include <vector>

namespace elastic {

Status ElasticAttention::init(int d_max_, int d_min_, uint64_t seed) noexcept {
  d_max = d_max_;
  d_min = d_min_;
  // Initialise the four linear projections.  Use distinct seeds to
  // decorrelate their initial weights.
  Status s;
  s = q.init(d_max_, d_max_, true, seed + 1);
  if (!s.ok) return s;
  s = k.init(d_max_, d_max_, true, seed + 2);
  if (!s.ok) return s;
  s = v.init(d_max_, d_max_, true, seed + 3);
  if (!s.ok) return s;
  s = o.init(d_max_, d_max_, true, seed + 4);
  return s;
}

int ElasticAttention::num_heads(int d) noexcept {
  int h = std::max(2, d / 64);
  while (h > 1 && (d % h) != 0) {
    --h;
  }
  return h > 0 ? h : 1;
}

StatusOr<Tensor> ElasticAttention::forward(const Tensor& x, int d, const Tensor* attn_mask) const noexcept {
  // x shape [B,T,d_max]; only first d columns used
  const auto& dims = x.shape();
  if (dims.size() != 3) {
    return StatusOr<Tensor>(Status::Error("Attention expects rank‑3 input [B,T,d_max]"));
  }
  int B = dims[0];
  int T = dims[1];
  int Dmax = dims[2];
  if (d > Dmax || d < d_min || d > d_max) {
    return StatusOr<Tensor>(Status::Error("Invalid active width"));
  }
  // Compute linear projections and then slice to [B,T,d]
  StatusOr<Tensor> q_full = q.forward(x, d);
  if (!q_full.status.ok) return q_full;
  StatusOr<Tensor> k_full = k.forward(x, d);
  if (!k_full.status.ok) return k_full;
  StatusOr<Tensor> v_full = v.forward(x, d);
  if (!v_full.status.ok) return v_full;
  StatusOr<Tensor> qs = Tensor::slice_last_dim(q_full.value, d);
  if (!qs.status.ok) return qs;
  StatusOr<Tensor> ks = Tensor::slice_last_dim(k_full.value, d);
  if (!ks.status.ok) return ks;
  StatusOr<Tensor> vs = Tensor::slice_last_dim(v_full.value, d);
  if (!vs.status.ok) return vs;
  Tensor Q = std::move(qs.value);
  Tensor K = std::move(ks.value);
  Tensor V = std::move(vs.value);
  int h = num_heads(d);
  int dh = d / h;
  // Prepare output tensor for context after attention: shape [B,T,d]
  StatusOr<Tensor> maybe_ctx = Tensor::make({B, T, d});
  if (!maybe_ctx.status.ok) return maybe_ctx;
  Tensor ctx = std::move(maybe_ctx.value);
  float* ctx_ptr = ctx.data();
  const float* Qp = Q.data();
  const float* Kp = K.data();
  const float* Vp = V.data();
  // For each batch and head compute attention scores and apply softmax
  for (int b = 0; b < B; ++b) {
    for (int head = 0; head < h; ++head) {
      // Compute scaled dot products: scores [T,T]
      std::vector<float> scores(T * T);
      float scale = 1.0f / std::sqrt(static_cast<float>(dh));
      for (int t_q = 0; t_q < T; ++t_q) {
        for (int t_k = 0; t_k < T; ++t_k) {
          float dot = 0.0f;
          const float* q_vec = Qp + ((b * T + t_q) * d + head * dh);
          const float* k_vec = Kp + ((b * T + t_k) * d + head * dh);
          for (int i = 0; i < dh; ++i) {
            dot += q_vec[i] * k_vec[i];
          }
          int idx = t_q * T + t_k;
          scores[idx] = dot * scale;
          // Apply mask if provided; assume mask dims [B,T] or [B,T,T]
          if (attn_mask) {
            const auto& md = attn_mask->shape();
            if (md.size() == 2) {
              // broadcast on keys
              const float* m = attn_mask->data();
              scores[idx] += m[b * T + t_k];
            } else if (md.size() == 3) {
              const float* m = attn_mask->data();
              scores[idx] += m[(b * T + t_q) * T + t_k];
            }
          }
        }
      }
      // Softmax along last dimension (keys)
      for (int t_q = 0; t_q < T; ++t_q) {
        float max_val = scores[t_q * T];
        for (int t_k = 1; t_k < T; ++t_k) {
          max_val = std::max(max_val, scores[t_q * T + t_k]);
        }
        float sum = 0.0f;
        for (int t_k = 0; t_k < T; ++t_k) {
          int idx = t_q * T + t_k;
          scores[idx] = std::exp(scores[idx] - max_val);
          sum += scores[idx];
        }
        float inv = 1.0f / sum;
        for (int t_k = 0; t_k < T; ++t_k) {
          scores[t_q * T + t_k] *= inv;
        }
      }
      // Multiply softmax scores with V to produce context
      for (int t_q = 0; t_q < T; ++t_q) {
        float* out_vec = ctx_ptr + ((b * T + t_q) * d + head * dh);
        // zero initialise
        for (int i = 0; i < dh; ++i) {
          out_vec[i] = 0.0f;
        }
        for (int t_k = 0; t_k < T; ++t_k) {
          float weight = scores[t_q * T + t_k];
          const float* v_vec = Vp + ((b * T + t_k) * d + head * dh);
          for (int i = 0; i < dh; ++i) {
            out_vec[i] += weight * v_vec[i];
          }
        }
      }
    }
  }
  // Project output back to d dimensions via o and slice
  StatusOr<Tensor> proj_full = o.forward(ctx, d);
  if (!proj_full.status.ok) return proj_full;
  StatusOr<Tensor> proj = Tensor::slice_last_dim(proj_full.value, d);
  if (!proj.status.ok) return proj;
  return StatusOr<Tensor>(std::move(proj.value));
}

} // namespace elastic
