"""
Registry for loading model adapters and managing model metadata.

The registry reads a YAML configuration file describing available
models and instantiates adapters accordingly.  It exposes methods to
retrieve a model by name, select a default model, and obtain an
embedder adapter (for generating embeddings).
"""

from __future__ import annotations

import os
import importlib
import logging
from dataclasses import dataclass
from typing import Dict, List, Optional

try:
    import yaml  # type: ignore
except ImportError:
    yaml = None


@dataclass
class ModelConfig:
    name: str
    type: str
    params: dict
    capabilities: List[str]


class Registry:
    """Load and manage model adapters based on config.

    Parameters
    ----------
    config_path: str
        Path to the YAML configuration describing available models.
    """

    def __init__(self, config_path: str) -> None:
        self.config_path = config_path
        self._configs: Dict[str, ModelConfig] = {}
        self._models: Dict[str, object] = {}
        self._default: Optional[str] = None
        self._load_config()

    def _load_config(self) -> None:
        """Load the YAML config and instantiate adapters."""
        if not os.path.exists(self.config_path):
            raise FileNotFoundError(f"Config file not found: {self.config_path}")
        with open(self.config_path, "r", encoding="utf-8") as f:
            data_text = f.read()
        # Try YAML first
        data = None
        if yaml is not None:
            try:
                data = yaml.safe_load(data_text)
            except Exception:
                data = None
        # Fallback: naive parsing expecting JSON-like dict
        if data is None:
            import json
            data = json.loads(data_text)
        models = data.get("models", [])
        if not models:
            raise ValueError("No models configured in config")
        for m in models:
            name = m.get("name")
            mtype = m.get("type")
            params = m.get("params", {})
            capabilities = m.get("capabilities", [])
            if not name or not mtype:
                continue
            self._configs[name] = ModelConfig(name=name, type=mtype, params=params, capabilities=capabilities)
            # Instantiate adapter
            module_name = f"cockpit.adapters.{mtype}"
            class_name = ''.join(part.capitalize() for part in mtype.split('_')) + "Adapter"
            try:
                module = importlib.import_module(module_name)
                adapter_class = getattr(module, class_name)
                adapter = adapter_class()
                adapter.load(**params)
                self._models[name] = adapter
                if self._default is None:
                    self._default = name
            except Exception as exc:
                logging.warning(f"Failed to load adapter {mtype} for model {name}: {exc}")
                continue

    def get(self, name: str) -> object:
        """Return the adapter instance for a model by name."""
        return self._models[name]

    def get_default(self) -> object:
        """Return the default model adapter."""
        if self._default is None:
            raise RuntimeError("No default model defined")
        return self._models[self._default]

    def get_embedder(self, model_name: Optional[str]) -> object:
        """Return an adapter capable of embedding.

        If `model_name` is provided and that model has an embed capability,
        its adapter is returned.  Otherwise the first adapter with
        'embed' capability is returned.  If none exists, return the
        default adapter.
        """
        if model_name and model_name in self._models:
            adapter = self._models[model_name]
            if hasattr(adapter, "embed"):
                return adapter
        # find first embedder
        for name, adapter in self._models.items():
            try:
                caps = adapter.capabilities
            except Exception:
                continue
            if "embed" in caps:
                return adapter
        return self.get_default()

    def get_default_embedder(self) -> object:
        return self.get_embedder(None)