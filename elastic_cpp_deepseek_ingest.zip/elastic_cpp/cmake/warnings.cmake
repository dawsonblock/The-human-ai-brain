# Helper module to set compiler warnings across compilers.

include(CheckCXXCompilerFlag)

function(enable_elastic_warnings target)
  if(MSVC)
    # Use a strict warning level and ANSI compliance on MSVC
    target_compile_options(${target} PRIVATE
      /W4       # high warning level
      /permissive- # enforce standard compliance
      /Zc:preprocessor # conforming preprocessor
      /Zc:inline # remove unreferenced inline functions
    )
    # Avoid warnings about unsafe functions
    target_compile_definitions(${target} PRIVATE _CRT_SECURE_NO_WARNINGS)
  else()
    # GCC/Clang warnings
    target_compile_options(${target} PRIVATE
      -Wall -Wextra -Wpedantic
    )
  endif()
endfunction()

enable_elastic_warnings(elastic_core)