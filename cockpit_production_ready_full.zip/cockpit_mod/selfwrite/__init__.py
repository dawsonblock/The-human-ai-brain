"""
Self‑writing module for the AI cockpit.

This package provides the scaffolding for self‑modifying code.  It
includes a planner to break high‑level goals into tasks, a patcher
that proposes code changes via a model adapter, a sandbox runner
that applies and tests patches in isolation, a gate that enforces
policies, and a GitOps wrapper to merge approved changes.  A simple
pipeline orchestrates these components.  These implementations are
stubs and should be extended for real use.
"""

from .pipeline import run_selfwrite  # noqa: F401