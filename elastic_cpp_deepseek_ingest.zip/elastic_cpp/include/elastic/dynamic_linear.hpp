// Dynamic linear layer supporting elastic width selection.

#pragma once

#include "elastic/status.hpp"
#include "elastic/tensor.hpp"

#include <cstdint>

namespace elastic {

// A simple pseudo‑random number generator used for weight initialisation.
struct Rng;

struct DynamicLinear {
  Tensor W;  // [d_out, D_MAX]
  Tensor b;  // [d_out]
  int d_out = 0;
  int D_MAX = 0;
  bool has_bias = true;

  // Initialise the layer.  Allocates weight and bias tensors and fills
  // them with pseudo‑random values drawn from a uniform distribution
  // centred on zero.  The optional seed controls reproducibility.
  Status init(int d_out_, int d_max = 1024, bool bias = true, uint64_t seed = 42) noexcept;

  // Forward pass for an input tensor x of shape [..., d].  Only the
  // first d_active columns of W are used.  The output has the same
  // rank as x but with the last dimension equal to d_out.
  StatusOr<Tensor> forward(const Tensor& x, int d_active) const noexcept;
};

} // namespace elastic
