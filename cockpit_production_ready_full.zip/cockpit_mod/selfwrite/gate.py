"""
Policy gate for self‑writing patches.

Checks whether a proposed patch satisfies configured policies such as
maximum changed files, forbidden patterns, or secrets.  This stub
always approves patches.
"""

from __future__ import annotations

from typing import Tuple, Dict, Any


class Policy:
    """Simple policy container.

    Production rules limit the scope of changes permitted by
    self‑writing.  Additional parameters can be added as needed.
    """

    def __init__(
        self,
        max_files_changed: int = 10,
        allowed_dirs: tuple[str, ...] = ("cockpit_mod",),
        forbidden_patterns: tuple[str, ...] = (
            r"\bos\.system\b",
            r"\bsubprocess\b",
            r"\bshutil\.rmtree\b",
        ),
    ) -> None:
        self.max_files_changed = max_files_changed
        self.allowed_dirs = allowed_dirs
        self.forbidden_patterns = forbidden_patterns


def load_policy(config_path: str | None = None) -> Policy:
    """Load the policy configuration.

    In a full implementation this would parse a YAML or JSON file
    defining limits and patterns.  For now, it returns a sensible
    default.

    Parameters
    ----------
    config_path: str | None
        Path to the policy configuration.  Ignored currently.

    Returns
    -------
    Policy
        The loaded policy object.
    """
    return Policy()


import os
import re
from typing import List


def _changed_files_from_diff(diff: str) -> List[str]:
    """Extract the list of file paths changed in a unified diff.

    Only `+++ b/` lines are considered, which indicate the target of the patch.
    """
    files: List[str] = []
    for line in diff.splitlines():
        if line.startswith("+++ b/"):
            # Remove the '+++ b/' prefix
            files.append(line[6:])
    return files


def check_patch(diff: str, policy: Policy) -> Tuple[bool, str]:
    """Check whether a diff complies with the policy.

    This implementation enforces several simple rules:

    * Limits the number of files that can be changed.
    * Restricts modifications to whitelisted directories.
    * Rejects code containing forbidden patterns (e.g. os.system).

    A more sophisticated implementation could delegate to an OPA
    policy server, but this keeps dependency overhead low.

    Parameters
    ----------
    diff: str
        The unified diff proposed by the model.
    policy: Policy
        Loaded policy object.

    Returns
    -------
    tuple[bool, str]
        True and reason if allowed; False and reason if denied.
    """
    # Identify changed files
    changed_files = _changed_files_from_diff(diff)
    if len(changed_files) > policy.max_files_changed:
        return False, f"Too many files changed ({len(changed_files)} > {policy.max_files_changed})"
    # Check allowed directories
    for path in changed_files:
        # Normalise to forward slashes
        if not any(path.startswith(d) for d in policy.allowed_dirs):
            return (
                False,
                f"Modification to disallowed directory: {path}. Only {policy.allowed_dirs} are permitted.",
            )
    # Check forbidden patterns in the diff
    for pattern in policy.forbidden_patterns:
        if re.search(pattern, diff):
            return False, f"Forbidden pattern detected: /{pattern}/"
    return True, "ok"