// Simple xoroshiro128+ pseudo‑random generator for deterministic
// initialisation.  This generator produces 64‑bit random integers and
// floating point values uniformly distributed in [0,1).

#pragma once

#include <cstdint>

namespace elastic {

struct Rng {
  uint64_t s0 = 0;
  uint64_t s1 = 0;

  // Initialise with a non‑zero seed.  When seed is zero a fixed
  // default is used to avoid degeneracy.
  void init(uint64_t seed) noexcept {
    if (seed == 0) seed = 0xdeadbeefULL;
    // Split seed using splitmix64
    uint64_t z = (seed += 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    s0 = z ^ (z >> 31);
    z = (seed += 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    s1 = z ^ (z >> 31);
  }

  // Advance the generator and return a 64‑bit integer
  uint64_t next() noexcept {
    uint64_t result = s0 + s1;
    uint64_t t = s1 << 17;
    s1 ^= s0;
    s0 = (s0 << 49) | (s0 >> (64 - 49));
    s0 ^= t;
    s1 = (s1 << 21) | (s1 >> (64 - 21));
    return result;
  }

  // Return a float in [0,1)
  float uniform() noexcept {
    uint64_t v = next();
    // 24 bits for float mantissa
    return (v >> 40) * (1.0f / 16777216.0f);
  }
};

} // namespace elastic
