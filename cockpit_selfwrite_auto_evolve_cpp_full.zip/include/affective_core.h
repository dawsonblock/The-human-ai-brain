// affective_core.h
//
// Stub for an affective core that maintains internal state variables
// such as valence, arousal and novelty.  Neuromodulators emitted by
// the affective core can modulate learning rates, attention
// thresholds and other parameters.  This skeleton provides a simple
// interface to update and query the affective state.

#ifndef AFFECTIVE_CORE_H
#define AFFECTIVE_CORE_H

namespace affective_core {

class AffectiveCore {
public:
    AffectiveCore() : valence_(0.0), arousal_(0.0), novelty_(0.0) {}

    // Update the affective state based on an intrinsic reward signal,
    // unexpected observations or other inputs.  Real implementations
    // might implement decay and coupling between variables.
    void update(double reward, double surprise) {
        // Increase valence for positive reward, decrease for negative.
        valence_ += reward;
        // Increase arousal for surprising events.
        arousal_ += surprise;
        // Novelty could track running average of prediction error.
        novelty_ = 0.9 * novelty_ + 0.1 * surprise;
    }

    double valence() const { return valence_; }
    double arousal() const { return arousal_; }
    double novelty() const { return novelty_; }

    // Compute neuromodulator factors to adjust other subsystems.  In a
    // real system these would be non‑linear functions of the state.
    double dopamine() const { return valence_; }
    double norepinephrine() const { return arousal_; }
    double acetylcholine() const { return novelty_; }

private:
    double valence_;
    double arousal_;
    double novelty_;
};

} // namespace affective_core

#endif // AFFECTIVE_CORE_H