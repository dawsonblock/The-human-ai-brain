"""
Adapter for llama.cpp models.

This adapter loads a gguf or other llama.cpp model using the
`llama_cpp` Python bindings.  It supports chat completions and
embeddings.  If the llama_cpp package is unavailable or loading
fails, a simple stub is used instead.
"""

from __future__ import annotations

import logging
from typing import List, Dict, Any, Iterable, Optional, Sequence
import random
import time

try:
    from llama_cpp import Llama  # type: ignore
    _llama_available = True
except ImportError:
    _llama_available = False

from .base import ModelAdapter


class LlamaCppAdapter(ModelAdapter):
    name = "llama.cpp"
    capabilities = {"chat", "embed"}

    def __init__(self) -> None:
        self._llm: Optional[Llama] = None
        self._loaded: bool = False
        self._ctx_len: int = 4096
        self._random = random.Random(42)

    def load(self, **kwargs: Any) -> None:
        """Load a llama.cpp model from file.

        Parameters
        ----------
        kwargs: Any
            Should include 'path' (path to .gguf/.bin) and optional
            'n_ctx', 'n_gpu_layers', etc.  If llama_cpp is not
            available, this call logs a warning and uses a stub.
        """
        path = kwargs.get("path")
        self._ctx_len = kwargs.get("n_ctx", 4096)
        if _llama_available and path:
            try:
                # Many models require n_gpu_layers > 0 to run on GPU; here we
                # default to 0 (CPU) if unspecified.
                n_gpu_layers = kwargs.get("n_gpu_layers", 0)
                self._llm = Llama(model_path=path, n_ctx=self._ctx_len, n_gpu_layers=n_gpu_layers)
                self._loaded = True
                logging.info(f"Loaded llama.cpp model from {path}")
            except Exception as exc:
                logging.warning(f"Failed to load llama.cpp model: {exc}")
                self._llm = None
                self._loaded = False
        else:
            logging.warning("llama_cpp package not available or model path missing; using stub adapter")
            self._llm = None
            self._loaded = False

    def chat(self, messages: List[Dict[str, str]], **kwargs: Any) -> Dict[str, Any]:
        """Generate a chat response from the model or stub.

        The message format follows the OpenAI style.  If llama.cpp is
        available and a model is loaded, call `create_chat_completion`.
        Otherwise, generate a canned response.
        """
        if self._loaded and self._llm is not None:
            # Convert messages to llama_cpp format: each message should have 'role' and 'content'.
            try:
                result = self._llm.create_chat_completion(messages=messages)
                return {"text": result["choices"][0]["message"]["content"]}
            except Exception as exc:
                logging.error(f"llama.cpp chat error: {exc}")
                return {"text": f"[llama.cpp error] {exc}"}
        # Fallback stub: echo or simple template
        user_content = messages[-1]["content"] if messages else ""
        stub_resp = f"[stub] You said: {user_content[:100]}"
        # Simulate some processing delay
        time.sleep(0.1)
        return {"text": stub_resp}

    def embed(self, texts: Iterable[str], **kwargs: Any) -> List[List[float]]:
        """Generate embeddings using llama.cpp or fallback stub.

        llama.cpp exposes `create_embedding` for a single text and returns
        a structure with the embedding under 'embedding'.  We call it
        once per text.  When the model is not loaded, return a simple
        deterministic vector based on hash of the text.
        """
        embeddings: List[List[float]] = []
        if self._loaded and self._llm is not None:
            for txt in texts:
                try:
                    res = self._llm.create_embedding(txt)
                    vec = res["data"][0]["embedding"]
                    embeddings.append(vec)
                except Exception as exc:
                    logging.error(f"llama.cpp embedding error: {exc}")
                    # return a zero vector if embedding fails
                    embeddings.append([0.0] * 512)
        else:
            for txt in texts:
                # Simple deterministic embedding: use hash to generate floats
                h = hash(txt)
                # Use 32 dims for stub to save compute
                vec = [(float((h >> (i * 8)) & 0xFF) / 255.0) for i in range(32)]
                embeddings.append(vec)
        return embeddings

    def stop(self) -> None:
        """Tear down the model and free resources."""
        # llama_cpp objects do not provide an explicit close API; rely on GC.
        self._llm = None
        self._loaded = False
