
import torch, torch.nn as nn, torch.nn.functional as F
from .dynamic_linear import DynamicLinear
class ElasticAttention(nn.Module):
    def __init__(self, d_model_max: int, d_min: int):
        super().__init__()
        self.d_model_max = d_model_max
        self.d_min = d_min
        self.q = DynamicLinear(d_model_max, d_model_max)
        self.k = DynamicLinear(d_model_max, d_model_max)
        self.v = DynamicLinear(d_model_max, d_model_max)
        self.o = DynamicLinear(d_model_max, d_model_max)
    def _num_heads(self, d):
        return max(2, d // 64)
    def forward(self, x, d, mask=None):
        B,T,_ = x.shape
        h = self._num_heads(d)
        dh = d // h
        q = self.q(x, d).view(B,T,h,dh).transpose(1,2)
        k = self.k(x, d).view(B,T,h,dh).transpose(1,2)
        v = self.v(x, d).view(B,T,h,dh).transpose(1,2)
        att = (q @ k.transpose(-2,-1)) / (dh ** 0.5)
        if mask is not None:
            att = att.masked_fill(mask[:,None,:,:]==0, float('-inf'))
        att = att.softmax(dim=-1)
        o = (att @ v).transpose(1,2).contiguous().view(B,T,d)
        return self.o(o, d)
