// Primitive operations for the elastic‑width Transformer.
// This header declares a set of floating point operations implemented
// in ops.cpp.  CPU implementations are always available.  When
// compiled with ELASTIC_USE_CUDA or ELASTIC_USE_DIRECTML a device
// implementation may be supplied, falling back to the CPU reference
// when unavailable at runtime.

#pragma once

#include "elastic/status.hpp"
#include "elastic/tensor.hpp"

namespace elastic {

// Matrix multiplication.  Computes the product of a left tensor
// shaped [B, M, K] and a right tensor shaped [K, N] yielding a
// tensor of shape [B, M, N].  When B is omitted on either input
// the batch dimension is broadcast to 1.
StatusOr<Tensor> matmul(const Tensor& a, const Tensor& b) noexcept;

// Elementwise addition of two tensors with identical shapes.
StatusOr<Tensor> add(const Tensor& a, const Tensor& b) noexcept;

// Apply the Gaussian error linear unit activation pointwise.
StatusOr<Tensor> gelu(const Tensor& x) noexcept;

// Apply layer normalisation across the last dimension.  Epsilon
// prevents division by zero.
StatusOr<Tensor> layernorm(const Tensor& x, float epsilon = 1e-5f) noexcept;

// Apply a softmax along the last dimension.  The output sums to
// one along that dimension.
StatusOr<Tensor> softmax_lastdim(const Tensor& x) noexcept;

} // namespace elastic
