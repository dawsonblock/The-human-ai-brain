#include <iostream>
int main() {
#ifdef ELASTIC_USE_CUDA
  std::cout << "GPU parity test is not implemented; compiled with CUDA.\n";
#elif defined(ELASTIC_USE_DIRECTML)
  std::cout << "GPU parity test is not implemented; compiled with DirectML.\n";
#else
  std::cout << "GPU parity test skipped (no backend enabled).\n";
#endif
  return 0;
}