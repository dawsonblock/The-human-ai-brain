// Implementation of width controller heuristics.

#include "elastic/controller.hpp"

namespace elastic {

int WidthController::pick(float load, float entropy, float latency_ms) const noexcept {
  // Simple heuristic: prefer larger widths when load and latency are low.
  // Penalise by latency and high load; incorporate entropy as a tie breaker.
  int width = choices[0];
  if (load < 0.5f && latency_ms < 10.0f) {
    width = choices[3];
  } else if (load < 0.7f && latency_ms < 20.0f) {
    width = choices[2];
  } else if (entropy < 0.3f) {
    width = choices[1];
  } else {
    width = choices[0];
  }
  return width;
}

} // namespace elastic
