"""
Request and response validators.

This module provides helper functions to enforce structured IO
contracts for prompt tool invocation and to validate grounding.
"""
from __future__ import annotations

import json
from jsonschema import Draft7Validator, ValidationError  # type: ignore


def validate_json_schema(data: str, schema: dict) -> bool:
    """Return True if `data` is valid JSON matching `schema`."""
    try:
        obj = json.loads(data)
    except Exception:
        return False
    validator = Draft7Validator(schema)
    try:
        validator.validate(obj)
        return True
    except ValidationError:
        return False


def check_grounding(answer: str) -> bool:
    """Check that a response is grounded by requiring it to include citations.

    A simplistic grounding check ensures that the assistant output includes
    at least one bracketed citation.  In production this should be
    replaced with a more robust citation validator.
    """
    return "【" in answer and "†" in answer