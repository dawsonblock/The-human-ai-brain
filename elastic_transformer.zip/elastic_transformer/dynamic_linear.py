
import torch, torch.nn as nn, torch.nn.functional as F
class DynamicLinear(nn.Module):
    def __init__(self, d_out, d_in_max, bias=True):
        super().__init__()
        self.W = nn.Parameter(torch.empty(d_out, d_in_max))
        self.b = nn.Parameter(torch.empty(d_out)) if bias else None
        nn.init.xavier_uniform_(self.W); 
        if bias: nn.init.zeros_(self.b)
    def forward(self, x, d_active):
        W = self.W[:, :d_active]
        b = self.b
        return F.linear(x[..., :d_active], W, b)
