
from fdqc.memory import Unit, WorkingMemory, LTM
import random

units = [Unit(value=f"item_{i}", importance=0.5 + 0.5*random.random()) for i in range(20)]
wm = WorkingMemory(capacity=4, chunk_size=4, decay_seconds=15.0)
wm.add_units(units)

print("Effective capacity (should be 16):", wm.effective_capacity())
print("Context summary:", wm.context_summary())

ltm = LTM(promote_threshold=2)
for ch in wm.slots:
    ltm.observe(ch); ltm.observe(ch)

print("Promoted schemas:", len(ltm.schemas))
