// demo_memory.cpp
// Demonstrates usage of the elastic::MemoryService.  This example
// constructs a memory database, inserts a handful of random
// embeddings along with associated strings, and then performs a
// nearest neighbour query.  It is not connected to the Transformer
// model but serves to illustrate the API.

#include "elastic/memory_service.hpp"
#include "elastic/tensor.hpp"
#include <iostream>
#include <random>

int main() {
  // Create or open a database in the current working directory.  In a
  // real application you may place this in a user data folder.
  elastic::MemoryService mem("memory.db");

  // Generate some random embeddings of dimension 8 and insert them.
  std::mt19937 rng(42);
  std::uniform_real_distribution<float> dist(0.0f, 1.0f);
  for (int i = 0; i < 5; ++i) {
    std::vector<int> shape{8};
    auto embedding_or = elastic::Tensor::make(shape);
    elastic::Tensor embedding = embedding_or.value;
    float *data = embedding.as_span().data();
    for (int j = 0; j < 8; ++j) data[j] = dist(rng);
    std::string text = "vector_" + std::to_string(i);
    auto st = mem.Put(embedding, text);
    if (!st.ok) {
      std::cerr << "Put failed: " << st.msg << std::endl;
    }
  }

  // Build a query close to the first inserted vector.
  std::vector<int> qshape{8};
  auto query_or = elastic::Tensor::make(qshape);
  elastic::Tensor query = query_or.value;
  float *qdata = query.as_span().data();
  for (int i = 0; i < 8; ++i) qdata[i] = 0.5f; // a generic midpoint
  auto result_or = mem.Search(query, 3);
  if (!result_or.status.ok) {
    std::cerr << "Search failed: " << result_or.status.msg << std::endl;
    return 1;
  }
  auto results = result_or.value;
  std::cout << "Top results:\n";
  for (const auto &r : results) {
    std::cout << "dist=" << r.first << " text=" << r.second << "\n";
  }
  return 0;
}