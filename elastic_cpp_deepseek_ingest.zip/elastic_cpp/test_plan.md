# Test Plan for MemoryService and FDQC Integration

This document describes how to validate the new `MemoryService` and
its integration into the FDQC working‑memory architecture.  The goal
is twofold:

1. **Reproduce the `n≈4` efficiency peak** observed in the FDQC
   experiments.  This involves verifying that a working memory with
   four slots and a chunk size of four units (i.e. capacity 16
   individual units) achieves maximal efficiency given an energy
   budget.  The efficiency curve is expected to peak around four
   slots as shown in the provided FDQC plots.
2. **Verify recall and reflection metrics** for the long‑term memory
   (LTM) system.  Recall measures how often previously stored
   information is retrieved when relevant; reflection measures how
   often the system triggers consolidation (writing from working
   memory into long‑term memory) based on uncertainty signals.

The tests below can be run on any machine with Python 3, the
`fdqc_memory_4x4` package extracted from this repository, and the
compiled `elastic_cpp` library.  They assume that the working
memory/long‑term memory implementation from `fdqc/memory` is used
alongside the C++ `MemoryService` when evaluating recall and
reflection.

## 1. Setup

1. Build the C++ components:

   ```sh
   mkdir build && cd build
   cmake -G Ninja -DCMAKE_BUILD_TYPE=Release ..
   ninja demo_memory test_memory_service
   ./test_memory_service    # ensures the memory service works
   ```

2. Extract the `fdqc_memory_4x4.zip` archive and install the Python
   dependencies:

   ```sh
   unzip fdqc_memory_4x4.zip
   cd fdqc_memory_4x4
   pip install -r requirements.txt  # if a requirements file exists
   ````

3. Ensure the `faiss` Python package is available if you wish to
   replace the brute‑force search in `MemoryService` with a proper
   vector index.  The provided C++ implementation will still work
   without it.

## 2. Reproducing the `n≈4` Efficiency Peak

The FDQC library’s working memory module exposes two key classes:

- `WorkingMemory`: a fixed‑capacity buffer of `Chunk` objects, each
  containing multiple `Unit`s.  It supports adding new units,
  evicting less useful chunks, and computing a summary of its
  contents.
- `Unit`: an atomic item of information with a `value` and an
  `importance` score.

To reproduce the efficiency peak:

1. Create a script similar to `fdqc/run_memory_demo.py` that
   iteratively varies the number of slots (e.g. 1 to 8) while fixing
   the chunk size at four units.  For each configuration:

   - Generate a stream of random units (e.g. 100) with random
     importance scores.
   - Insert them into a `WorkingMemory` instance with the current
     capacity.
   - Compute the **effective capacity** via
     `wm.effective_capacity()` and record it.
   - Optionally compute an **efficiency metric**, defined as the
     ratio of *useful information retained* to *energy cost*.  If the
     energy cost is assumed to scale linearly with the number of
     slots and chunk size, the efficiency should peak around four
     slots.
   - Plot capacity or efficiency versus number of slots.  You
     should observe a plateau/peak at four slots (i.e. `n≈4`).

2. Compare the resulting curve with the original FDQC paper’s plots
   (see the `README_MEMORY.md` for context).  A matching peak at
   four slots validates the memory configuration used in our
   implementation.

## 3. Recall Evaluation

To verify that the memory system successfully recalls information:

1. Create a set of labelled embeddings representing distinct
   memories.  For example, generate 50 random 8‑dimensional vectors
   and assign a unique string label to each.

2. Use the C++ `MemoryService` to insert these (embedding, label)
   pairs into a persistent store (or the in‑memory database for
   testing).  Verify via the `demo_memory` example that inserts do
   not error.

3. For a subset of the inserted embeddings (e.g. 10), perform a
   nearest‑neighbour search using slightly perturbed versions of the
   original vectors.  A perturbed vector can be created by adding
   Gaussian noise with a small standard deviation.

4. Measure **recall@1** and **recall@k**: the fraction of queries
   where the correct label is returned in the top‑1 and top‑k results
   respectively.  For random vectors in moderate dimensions the
   service should achieve near‑perfect recall, since the inserted
   vectors are distinct and far apart.  If recall is poor, inspect
   the flattening logic and database persistence.

5. (Optional) Compare recall when using the brute‑force search in
   `MemoryService` versus a FAISS index.  The latter should
   significantly improve search latency on large collections but
   maintain similar recall.

## 4. Reflection Metrics

Reflection refers to the decision to consolidate working memory
contents into long‑term memory.  In the FDQC model this decision is
triggered by high entropy in the working memory distribution or a
large error signal.  To evaluate reflection:

1. Instrument the `WorkingMemoryProjection` (or equivalent
   projection head in your control loop) to report the **entropy** of
   the softmax distribution over memory slots.  A high entropy (e.g.
   > 1.5 bits) indicates that the model is uncertain about where to
   attend.

2. Modify your control loop such that when the entropy exceeds a
   threshold or when a task error occurs, the contents of the
   working memory are passed to the `MemoryService` via
   `Put()`.  This constitutes a **reflection event**.

3. Simulate a sequence of tasks where some are easy (low entropy)
   and some are hard (high entropy).  For each task record:

   - The entropy of the memory distribution.
   - Whether a reflection event occurred.
   - The number of items written to long‑term memory.

4. Plot the correlation between entropy and reflection rate.  A
   positive correlation indicates that the system reflects more often
   when it is uncertain, as intended.  You can also compute the
   **average reward** (task success) before and after reflection to
   assess whether reflection improves performance.

5. Finally, verify that the `MemoryService::Search` can retrieve
   reflected memories when faced with similar tasks later.  This
   demonstrates end‑to‑end integration: high entropy triggers
   reflection, long‑term memory stores the episode, and subsequent
   queries recall it.

## 5. Summary

This test plan ensures that the new `MemoryService` integrates
properly with the FDQC working memory architecture.  By reproducing
the established `n≈4` capacity peak and quantifying recall and
reflection behaviour, you can gain confidence that the agent’s
memory mechanisms align with both theoretical predictions and
practical requirements.  The tests are designed to be reproducible
without specialised hardware and can be extended to incorporate more
advanced indexing backends (e.g. FAISS) if available.

## 6. Semantic Memory Compression and Insight Distillation

To evaluate the semantic memory functionality introduced in this
update:

1. **Compress episodic memories into a semantic insight.**  Use the
   `SemanticMemory::CompressAll()` method after populating the
   episodic store with a set of related episodes.  Verify that a
   new row is created in the `insights` table and that the stored
   embedding is the mean of the episode embeddings (you can compute
   this manually for small synthetic vectors).  Inspect the
   generated summary to confirm it concatenates the truncated texts.

2. **Retrieve insights.**  Use `SemanticMemory::SearchInsights()` to
   query the semantic memory with a vector similar to the mean of
   your episodes.  Confirm that the returned summary corresponds to
   the aggregated episodes and that the distance reported is
   reasonable.  Query with unrelated embeddings and check that the
   insight is still returned but with a larger distance.

3. **Multiple semantic compressions.**  Insert episodes from two
   different themes (e.g. robot calibration vs. system failures),
   call `CompressAll()` to produce one insight per theme (by
   clearing episodic memory between themes), and then query each
   insight separately.  Ensure that the correct summary is returned
   when the query is close to each theme.

4. **Integration with working memory:**  In your control loop,
   trigger `CompressAll()` at suitable intervals (e.g. when the
   episode count exceeds a threshold or after long tasks).  Then
   modify the retrieval logic to search both episodic and semantic
   memory, preferring episodic recall for recent events and semantic
   insights for longer‑term patterns.  Measure whether the inclusion
   of semantic insights improves task performance over long horizons.

5. **Evaluation metrics:**  Use recall@k for semantic insights
   (correctly retrieving summaries when queries relate to a theme)
   and measure the effect of insights on planning accuracy (e.g.
   fewer repeated mistakes after summarised corrections).  This
   provides a quantitative measure of the benefit of semantic
   compression.

## 7. Episodic + Semantic Recall Integration (GW→WM)

The final part of the integration connects long‑term memory to the working
memory (WM) by retrieving a fixed number of episodic and semantic items and
packing them into a `[K,D]` tensor.  This is orchestrated by the
`elastic::recall_pack` and `elastic::wm_integrate` functions.  To verify the
correctness and practical benefit of this integration:

1. **Unit testing.**  The repository includes a new test,
   `tests/test_recall_pack.cpp`, which constructs three orthogonal episodic
   vectors in 8 dimensions and then compresses them into two identical
   semantic insights.  It calls `recall_pack` with `k_episode=2` and
   `k_semantic=2`, checks that the output tensor has shape `[4,8]`, that
   each row is properly L2 normalised, and that the first two rows match
   the nearest episodic vectors while the last two rows correspond to the
   insight mean.  Run this test via `ctest` to ensure the packer behaves
   deterministically.

2. **Demo verification.**  Build and run `demo_semantic` to see a real
   example of the recall integration.  The demo prints the number of
   episodic and semantic hits, their distances and associated texts, and
   shows how the recall vectors are inserted into a WM tensor.  Examine
   the printed values to confirm that the top episodic memories are
   returned first, followed by one or more semantic insights.

3. **Functional integration in control loop.**  Modify your FDQC control
   loop (either in C++ or Python) to call `elastic::recall_pack` on the
   current global workspace (GW) vector before decoding.  Pack the recall
   vectors into the WM slots using `elastic::wm_integrate`.  Observe
   whether the model’s performance on long‑horizon tasks improves when it
   can leverage both recent episodes and distilled semantic insights.

4. **A/B testing.**  Compare three configurations:
   - *No memory:* the baseline model without any external recall.
   - *Episodic only:* recall only from episodic memory (`k_semantic=0`).
   - *Episodic + semantic:* recall from both sources.
   Measure metrics such as task success rate, average reward, and
   reflection frequency.  Hypothesis: the combined recall should
   outperform the other two configurations on tasks requiring long
   temporal credit assignment or cross‑episode reasoning.

5. **Stress test.**  Populate the memory with a large number (e.g. 10k)
   of episodic entries and dozens of semantic insights to assess the
   scalability of the brute‑force search.  Measure recall latency and
   confirm that `SearchHits` and `SearchInsightsEmbeddings` continue to
   return the nearest neighbours correctly.  If performance becomes
   prohibitive, consider enabling a vector index such as FAISS for the
   episodic search, as suggested earlier.