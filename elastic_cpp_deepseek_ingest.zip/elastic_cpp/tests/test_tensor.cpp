#include "elastic/tensor.hpp"
#include <cassert>
#include <iostream>

using namespace elastic;

int main() {
  // Create a 2x5 tensor
  StatusOr<Tensor> maybe_t = Tensor::make({2, 5});
  assert(maybe_t.status.ok);
  Tensor t = std::move(maybe_t.value);
  // Fill with increasing values
  float* d = t.data();
  for (size_t i = 0; i < t.size(); ++i) {
    d[i] = static_cast<float>(i);
  }
  // Slice last dim down to 3
  auto sliced = Tensor::slice_last_dim(t, 3);
  assert(sliced.status.ok);
  Tensor v = std::move(sliced.value);
  assert(v.shape()[1] == 3);
  // Aliasing: update view and check original
  v.data()[1] = 100.0f;
  assert(t.data()[1] == 100.0f);
  // Pad last dim up to 6
  auto padded = Tensor::pad_last_dim(t, 6);
  assert(padded.status.ok);
  Tensor p = std::move(padded.value);
  assert(p.shape()[1] == 6);
  // Check copy correctness: first 5 entries match
  for (int i = 0; i < 2; ++i) {
    for (int j = 0; j < 5; ++j) {
      assert(p.data()[i * 6 + j] == t.data()[i * 5 + j]);
    }
    assert(p.data()[i * 6 + 5] == 0.0f);
  }
  std::cout << "test_tensor passed\n";
  return 0;
}