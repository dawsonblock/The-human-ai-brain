"""
Adapters package for the universal AI cockpit.

This package provides a base adapter interface and concrete adapters
for various backends such as llama.cpp and DeepSeek‑OCR.  Each
adapter implements a common API so the orchestrator can interact
with different models uniformly.
"""

from .base import ModelAdapter  # noqa: F401
from .llama_cpp import LlamaCppAdapter  # noqa: F401
from .deepseek_ocr import DeepseekOcrAdapter  # noqa: F401