// test_semantic_memory.cpp
#include "elastic/memory_service.hpp"
#include "elastic/semantic_memory.hpp"
#include "elastic/tensor.hpp"
#include <cassert>
#include <iostream>

int main() {
  // Use in-memory DB
  elastic::MemoryService mem(":memory:");
  elastic::SemanticMemory sem(mem);
  // Insert two episodic memories with distinct embeddings
  {
    auto t1_or = elastic::Tensor::make({4});
    auto t2_or = elastic::Tensor::make({4});
    auto t1 = t1_or.value;
    auto t2 = t2_or.value;
    float *d1 = t1.as_span().data();
    float *d2 = t2.as_span().data();
    for (int i = 0; i < 4; ++i) {
      d1[i] = static_cast<float>(i);
      d2[i] = static_cast<float>(4 - i);
    }
    assert(mem.Put(t1, "episodic one").ok);
    assert(mem.Put(t2, "episodic two").ok);
  }
  // Compress into one insight
  assert(sem.CompressAll().ok);
  // Build a query and search
  auto q_or = elastic::Tensor::make({4});
  auto q = q_or.value;
  float *qd = q.as_span().data();
  for (int i = 0; i < 4; ++i) qd[i] = static_cast<float>(i) + 0.05f;
  auto res_or = sem.SearchInsights(q, 1);
  assert(res_or.status.ok);
  // Should return exactly one insight
  assert(res_or.value.size() == 1);
  // Summary should include truncated text
  std::string summary = res_or.value[0].second;
  assert(summary.find("episodic one") != std::string::npos || summary.find("episodic two") != std::string::npos);
  // Test SearchInsightsEmbeddings: embedding size and id
  auto emb_or = sem.SearchInsightsEmbeddings(q, 1);
  assert(emb_or.status.ok);
  assert(emb_or.value.size() == 1);
  auto hit = emb_or.value[0];
  // The embedding vector should have length 4
  assert(hit.emb.size() == 4);
  assert(hit.id >= 1);
  std::cout << "SemanticMemory tests passed\n";
  return 0;
}