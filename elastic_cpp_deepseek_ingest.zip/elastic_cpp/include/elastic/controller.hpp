// Elastic width controller chooses an appropriate width based on heuristics.

#pragma once

namespace elastic {

struct WidthController {
  int choices[4] = {256, 512, 768, 1024};
  float logits[4] = {0, 0, 0, 0};
  // Pick a width given load (0..1), entropy (0..1) and latency in ms.
  int pick(float load, float entropy, float latency_ms) const noexcept;
};

} // namespace elastic
