"""
FastAPI server for the universal AI cockpit orchestrator.

This module exposes HTTP endpoints that allow clients to send chat
requests and query available models.  It wraps the high‑level
`handle_chat` function from the orchestrator package.
"""

from __future__ import annotations

from fastapi import FastAPI, HTTPException, Depends, Header
from pydantic import BaseModel

from . import handle_chat, registry
from .telemetry import setup_telemetry
from ..selfwrite.pipeline import run_selfwrite

app = FastAPI(title="AI Cockpit", version="0.1")

# Configure OpenTelemetry instrumentation for the FastAPI app.  If
# OpenTelemetry is not installed, this will log a warning and no
# tracing will be enabled.
setup_telemetry(app)

# ---------------------------------------------------------------------------
# API key security
#
# Endpoints are secured with a simple API key.  Keys are read from the
# `COCKPIT_API_KEYS` environment variable as a comma‑separated list.  If the
# variable is unset, a default key of "changeme" is used.  Clients must
# supply the key in the `X-API-Key` header.
import os

_api_keys_env = os.environ.get("COCKPIT_API_KEYS")
if _api_keys_env:
    _api_keys = {key.strip() for key in _api_keys_env.split(",") if key.strip()}
else:
    # Default key for development; should be overridden in production
    _api_keys = {"changeme"}


def api_key_auth(x_api_key: str = Header(..., alias="X-API-Key")) -> None:
    """FastAPI dependency enforcing API key authentication.

    Raises HTTP 401 if the provided key is not in the allowed set.
    """
    if x_api_key not in _api_keys:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")



class ChatRequest(BaseModel):
    text: str
    model: str | None = None


class ChatResponse(BaseModel):
    model: str
    text: str


@app.post("/chat", response_model=ChatResponse)
def chat_endpoint(req: ChatRequest, api_key: None = Depends(api_key_auth)) -> ChatResponse:
    """Generate a chat completion from the requested model.

    Raises HTTP 400 if the model is unknown or the prompt is empty.
    """
    if not req.text:
        raise HTTPException(status_code=400, detail="Prompt cannot be empty")
    # Validate model if specified
    if req.model and req.model not in registry._models:
        raise HTTPException(status_code=400, detail=f"Unknown model: {req.model}")
    reply = handle_chat(req.text, model_name=req.model)
    model_used = req.model or registry._default
    return ChatResponse(model=model_used, text=reply)


@app.get("/models")
def list_models(api_key: None = Depends(api_key_auth)) -> dict:
    """Return a list of loaded models and their capabilities."""
    models = []
    for name, adapter in registry._models.items():
        try:
            caps = list(adapter.capabilities)
        except Exception:
            caps = []
        models.append({"name": name, "capabilities": caps})
    return {"models": models}

# ---------------------------------------------------------------------------
# Health endpoints

@app.get("/live")
def liveness_probe() -> dict:
    """Liveness probe for Kubernetes and monitoring."""
    return {"status": "alive"}


@app.get("/ready")
def readiness_probe() -> dict:
    """Readiness probe indicating the service is ready to receive traffic."""
    # TODO: check model pool and memory connectivity
    return {"status": "ready"}


# ---------------------------------------------------------------------------
# Self‑write endpoint

class SelfWriteReq(BaseModel):
    goal: str
    model: str | None = None
    dry_run: bool = True


@app.post("/selfwrite")
def selfwrite_endpoint(req: SelfWriteReq, api_key: None = Depends(api_key_auth)) -> dict:
    """Run the self‑writing pipeline on a goal.

    Returns a dictionary summarizing the result of the pipeline.  Use
    `dry_run` to preview changes without modifying the repository.
    """
    if not req.goal:
        raise HTTPException(status_code=400, detail="Goal cannot be empty")
    result = run_selfwrite(goal=req.goal, model=req.model, dry_run=req.dry_run)
    return result