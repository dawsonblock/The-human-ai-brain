
import torch, torch.nn as nn
class WidthController(nn.Module):
    def __init__(self, choices=(256,512,768,1024)):
        super().__init__()
        self.register_buffer("choices", torch.tensor(choices))
        self.logits = nn.Parameter(torch.zeros(len(choices)))
    @torch.no_grad()
    def pick(self, load: float, entropy: float, latency_budget_ms: float):
        idx = 0
        if entropy > 1.0: idx += 1
        if entropy > 1.4: idx += 1
        if latency_budget_ms > 20: idx += 1
        idx = min(idx, len(self.choices)-1)
        return int(self.choices[idx].item())
