// Tensor abstraction for row‑major float32 data.
// This header defines a simple Tensor class used throughout the
// Transformer implementation.  Tensors own or view contiguous memory
// and provide helpers for shape introspection, slicing, padding and
// copying.  Constructors do not throw; allocation failures are
// reported via StatusOr<Tensor>.

#pragma once

#include "elastic/status.hpp"

#include <cmath>
#include <cstddef>
#include <memory>
#include <numeric>
#include <span>
#include <utility>
#include <vector>
#include <algorithm>

#include "elastic/platform_win.hpp"

namespace elastic {

class Tensor {
public:
  Tensor() : dims_(), data_(nullptr, [](float*) {}), offset_(0) {}

  // Create a new tensor with the given shape.  Memory is zero‑initialised.
  static StatusOr<Tensor> make(const std::vector<int>& shape) noexcept {
    Tensor t;
    Status s = t.init(shape);
    if (!s.ok) return StatusOr<Tensor>(s);
    return StatusOr<Tensor>(std::move(t));
  }

  // Initialises this tensor with a fresh allocation for the given shape.
  Status init(const std::vector<int>& shape) noexcept {
    dims_ = shape;
    // Compute total size; return error if overflow or empty
    size_t total = 1;
    for (int d : dims_) {
      if (d <= 0) {
        return Status::Error("Invalid dimension");
      }
      size_t old = total;
      total *= static_cast<size_t>(d);
      if (total / static_cast<size_t>(d) != old) {
        return Status::Error("Tensor size overflow");
      }
    }
    offset_ = 0;
    // Allocate aligned memory for SIMD efficiency.  Use 64‑byte
    // alignment which satisfies AVX‑512 requirements.  The memory is
    // zero‑initialised after allocation.
    size_t bytes = total * sizeof(float);
    float* raw = static_cast<float*>(aligned_malloc(bytes, 64));
    if (!raw) {
      return Status::Error("Allocation failed");
    }
    // Zero initialise
    std::fill_n(raw, total, 0.0f);
    // Wrap in shared_ptr with custom deleter
    data_ = std::shared_ptr<float>(raw, [](float* p) { aligned_free(p); });
    return Status::OK();
  }

  // Shape accessor
  const std::vector<int>& shape() const noexcept { return dims_; }

  // Number of elements (size of contiguous buffer) for this view
  size_t size() const noexcept {
    size_t total = 1;
    for (int d : dims_) total *= static_cast<size_t>(d);
    return total;
  }

  // Pointer to the first element of this view
  float* data() noexcept { return data_.get() + offset_; }
  const float* data() const noexcept { return data_.get() + offset_; }

  // Span representation for the underlying contiguous storage
  std::span<float> as_span() noexcept { return {data(), size()}; }
  std::span<const float> as_span() const noexcept { return {data(), size()}; }

  // Fill the tensor with a scalar value
  void fill(float value) noexcept {
    float* ptr = data();
    size_t n = size();
    for (size_t i = 0; i < n; ++i) {
      ptr[i] = value;
    }
  }

  // Copy data from another tensor with the same shape.  Returns error
  // if shapes mismatch.
  Status copy_from(const Tensor& other) noexcept {
    if (dims_ != other.dims_) {
      return Status::Error("Shape mismatch");
    }
    size_t n = size();
    float* dst = data();
    const float* src = other.data();
    for (size_t i = 0; i < n; ++i) {
      dst[i] = src[i];
    }
    return Status::OK();
  }

  // Slice the last dimension to retain only the first d values.  If d
  // equals the current last dimension this returns a view of the
  // original.  Otherwise the new tensor shares underlying storage.
  static StatusOr<Tensor> slice_last_dim(const Tensor& t, int d) noexcept {
    if (t.dims_.empty()) {
      return StatusOr<Tensor>(Status::Error("Cannot slice 0‑D tensor"));
    }
    int last = t.dims_.back();
    if (d > last || d <= 0) {
      return StatusOr<Tensor>(Status::Error("Slice dimension out of range"));
    }
    Tensor out;
    out.dims_ = t.dims_;
    out.dims_.back() = d;
    out.data_ = t.data_;
    out.offset_ = t.offset_;
    return StatusOr<Tensor>(std::move(out));
  }

  // Pad the last dimension up to Dmax.  If the tensor already has
  // exactly Dmax elements in the last dimension this returns a copy
  // sharing storage.  Otherwise it allocates a new tensor of shape
  // where the last dimension is Dmax and copies the existing content
  // into the leading portion, leaving the remainder zero‑initialised.
  static StatusOr<Tensor> pad_last_dim(const Tensor& t, int Dmax) noexcept {
    if (t.dims_.empty()) {
      return StatusOr<Tensor>(Status::Error("Cannot pad 0‑D tensor"));
    }
    int last = t.dims_.back();
    if (last > Dmax) {
      return StatusOr<Tensor>(Status::Error("Pad dimension too small"));
    }
    if (last == Dmax) {
      // Share storage
      Tensor out;
      out.dims_ = t.dims_;
      out.data_ = t.data_;
      out.offset_ = t.offset_;
      return StatusOr<Tensor>(std::move(out));
    }
    // Allocate a new tensor and copy
    std::vector<int> new_shape = t.dims_;
    new_shape.back() = Dmax;
    StatusOr<Tensor> maybe_out = Tensor::make(new_shape);
    if (!maybe_out.status.ok) return maybe_out;
    Tensor out = std::move(maybe_out.value);
    // Copy existing rows
    // Determine number of outer elements (elements ignoring last dim)
    size_t outer = 1;
    for (size_t i = 0; i < new_shape.size() - 1; ++i) {
      outer *= static_cast<size_t>(new_shape[i]);
    }
    float* out_ptr = out.data();
    const float* src_ptr = t.data();
    for (size_t i = 0; i < outer; ++i) {
      // Copy last elements
      for (int j = 0; j < last; ++j) {
        out_ptr[i * Dmax + j] = src_ptr[i * last + j];
      }
      for (int j = last; j < Dmax; ++j) {
        out_ptr[i * Dmax + j] = 0.0f;
      }
    }
    return StatusOr<Tensor>(std::move(out));
  }

private:
  std::vector<int> dims_;
  std::shared_ptr<float> data_;
  size_t offset_;
};

} // namespace elastic
