// Multi‑head elastic attention block.

#pragma once

#include "elastic/dynamic_linear.hpp"
#include "elastic/status.hpp"
#include "elastic/tensor.hpp"

namespace elastic {

struct ElasticAttention {
  DynamicLinear q;
  DynamicLinear k;
  DynamicLinear v;
  DynamicLinear o;
  int d_max = 0;
  int d_min = 0;

  // Initialise all sub‑modules.  Seeds control deterministic
  // initialisation.  The dimension bounds specify the allowable
  // elastic widths.
  Status init(int d_max_ = 1024, int d_min_ = 256, uint64_t seed = 42) noexcept;

  // Compute number of heads for a given width d.  The result is at
  // least two and divides d by decrementing when necessary.
  static int num_heads(int d) noexcept;

  // Forward pass for the attention.  Takes an input tensor x of shape
  // [B,T,d_max] (only the first d elements are used) and optional
  // attention mask of shape [B,T] or [B,T,T].  Returns a tensor of
  // shape [B,T,d] representing the attended output.
  StatusOr<Tensor> forward(const Tensor& x, int d, const Tensor* attn_mask) const noexcept;
};

} // namespace elastic
