"""
Adapter stub for DeepSeek‑OCR models.

DeepSeek‑OCR is primarily a vision model for OCR.  It does not
directly provide chat or embedding capabilities.  This adapter
serves as a stub to allow the orchestrator to load the OCR tool as
an auxiliary capability.  Real OCR ingestion should be performed
outside of the chat loop and fed into the memory system via the
deepseek_ingest script.
"""

from __future__ import annotations

import logging
from typing import List, Dict, Any, Iterable

from .base import ModelAdapter


class DeepseekOcrAdapter(ModelAdapter):
    name = "deepseek-ocr"
    capabilities = {"vision"}

    def __init__(self) -> None:
        self._loaded = False

    def load(self, **kwargs: Any) -> None:
        """Initialize the OCR adapter.

        In a real implementation this would set up API credentials or
        model weights.  Here we only log and mark as loaded.
        """
        logging.info("DeepSeek‑OCR adapter initialized (stub)")
        self._loaded = True

    def chat(self, messages: List[Dict[str, str]], **kwargs: Any) -> Dict[str, Any]:
        """Return a placeholder response.

        This adapter cannot generate chat completions.  It returns a
        simple message indicating that OCR must be used separately.
        """
        return {"text": "[DeepSeek‑OCR adapter] OCR cannot chat. Use deepseek_ingest.py to ingest images."}

    def embed(self, texts: Iterable[str], **kwargs: Any) -> List[List[float]]:
        """This adapter does not support embeddings.

        OCR adapters are not used for text embeddings in this design.
        Returns an empty list for each input text.
        """
        # Return empty embeddings to satisfy signature
        return [[] for _ in texts]

    def stop(self) -> None:
        self._loaded = False
