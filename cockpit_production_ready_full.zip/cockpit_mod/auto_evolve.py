#!/usr/bin/env python
"""
Autonomous evolve launcher.

Runs the self‑writing pipeline without approval (dry_run=False) using a
generic goal.  This will attempt to apply any proposed changes to the
repository.  Results are printed to stdout.
"""
import os
import sys

# Ensure the cockpit_selfwrite package is discoverable
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from cockpit_selfwrite.selfwrite.pipeline import run_selfwrite


def main() -> None:
    print("Starting autonomous evolution (full send)...")
    # Generic goal; adjust as needed
    goal = "autonomous improvement"
    result = run_selfwrite(goal, model=None, dry_run=False)
    print("Evolution result:")
    print(result)


if __name__ == "__main__":
    main()