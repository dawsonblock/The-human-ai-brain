"""
Top‑level package for the AI cockpit.

This file marks the `cockpit` directory as a Python package so that
relative imports work correctly.  It does not export any symbols.
"""

__all__: list[str] = []