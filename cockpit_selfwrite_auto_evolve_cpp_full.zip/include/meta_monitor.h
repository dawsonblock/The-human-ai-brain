// meta_monitor.h
//
// Stub for a meta‑conscious monitor.  The monitor records internal
// process metrics such as entropy, collapse frequency, agency
// measures and the dimensional scale of working memory.  These
// metrics can be logged or surfaced for auditing.  This skeleton
// defines a simple interface for updating metrics and retrieving
// summaries.

#ifndef META_MONITOR_H
#define META_MONITOR_H

#include <vector>

namespace meta_monitor {

class MetaMonitor {
public:
    // Record a metric value.  Real implementations might track
    // moving averages and compute derivatives.
    void record_entropy(double value) {
        entropies_.push_back(value);
    }
    void record_collapse(double frequency) {
        collapse_frequencies_.push_back(frequency);
    }
    void record_dimension(int n) {
        dimensions_.push_back(n);
    }
    // Retrieve the last recorded values for auditing.  In a full
    // system this might stream data into an external logger.
    double last_entropy() const {
        return entropies_.empty() ? 0.0 : entropies_.back();
    }
    double last_collapse() const {
        return collapse_frequencies_.empty() ? 0.0 : collapse_frequencies_.back();
    }
    int last_dimension() const {
        return dimensions_.empty() ? 0 : dimensions_.back();
    }
private:
    std::vector<double> entropies_;
    std::vector<double> collapse_frequencies_;
    std::vector<int> dimensions_;
};

} // namespace meta_monitor

#endif // META_MONITOR_H