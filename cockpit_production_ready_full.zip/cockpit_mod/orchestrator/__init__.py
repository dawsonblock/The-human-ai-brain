"""
Orchestrator package for the universal AI cockpit.

This package exposes a simple entry point `handle_chat` which wraps
memory recall, model selection, adapter invocation, and memory
persistence.  It is used by both the FastAPI server and the CLI.
"""

import logging
from .registry import Registry
from ..memory import ElasticMemory
from ..working_memory import WorkingMemory
from .router import choose_model
from ..adapters.base import ModelAdapter

# Initialize the global registry and memory bridge on module import.
# Compute the config path relative to this file so that running as a
# module resolves correctly regardless of working directory.  Allow
# overriding via environment variables for production deployment.
import os

# Determine base directory (root of the package)
_base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def _get_env_path(key: str, default: str) -> str:
    """Resolve a path from an environment variable or return the default."""
    path = os.environ.get(key)
    return path if path else default

# Paths can be overridden with environment variables
_config_path = _get_env_path("COCKPIT_MODELS_CONFIG", os.path.join(_base_dir, "config", "models.yaml"))
_dll_path = _get_env_path("COCKPIT_ELASTIC_DLL", os.path.join(_base_dir, "..", "elastic_core.dll"))
_db_path = _get_env_path("COCKPIT_MEMORY_DB", os.path.join(_base_dir, "..", "memory.db"))

# Set up a module-level logger.  In production you can override the
# logging level or handlers via standard logging configuration.
logger = logging.getLogger("cockpit.orchestrator")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    # Default to INFO; adjust via logging.basicConfig if needed
    logger.setLevel(logging.INFO)

# Instantiate registry and memory.  If loading fails, any errors are
# logged and the caller may receive fallback behaviour.
registry = Registry(config_path=_config_path)
memory = ElasticMemory(lib_path=_dll_path, db_path=_db_path)

# Instantiate working memory.  The threshold and decay values can be
# tuned via environment variables COCKPIT_WM_THRESHOLD and
# COCKPIT_WM_DECAY; defaults are ~log2(4) and 0.1.  These values
# control how aggressively the FDQC gate resets and how quickly it
# blends toward new embeddings.
threshold = float(os.environ.get("COCKPIT_WM_THRESHOLD", "1.39"))
decay = float(os.environ.get("COCKPIT_WM_DECAY", "0.1"))
wm = WorkingMemory(n_dim=4, threshold=threshold, decay=decay)


def handle_chat(text: str, model_name: str | None = None) -> str:
    """Process a chat request through the orchestrator.

    Parameters
    ----------
    text: str
        The user prompt to send to the model.
    model_name: Optional[str]
        If provided, override routing and force a specific model.

    Returns
    -------
    str
        The assistant's response.
    """
    # 1) Obtain an embedder and embed the user prompt into a vector.  This
    # vector serves as the candidate for updating working memory and as
    # the query for episodic/semantic recall.  If embedding fails we
    # proceed without recalled context.
    recall_vecs = None
    try:
        embedder = registry.get_embedder(model_name) if model_name else registry.get_default_embedder()
        candidate_vec = embedder.embed([text])[0]
        # Update working memory; decide whether to collapse based on entropy
        collapse = wm.update(candidate_vec)
        if collapse:
            logger.debug("Working memory collapse triggered due to high entropy")
        else:
            logger.debug("Working memory updated without collapse; performing recall")
            # Only perform recall when the state hasn't collapsed.
            recall_vecs = memory.recall(candidate_vec, k_episode=4, k_semantic=4)
    except Exception as exc:
        # If embedding or recall fails, fall back to no context and log the error
        logger.error(f"Failed to embed or recall context: {exc}")
        recall_vecs = None

    # 2) Choose model
    model: ModelAdapter
    if model_name:
        model = registry.get(model_name)
    else:
        model = choose_model(text, registry)

    # 3) Build messages with recalled context
    messages = []
    if recall_vecs is not None:
        # Inject recall vectors as a system message in a simple JSON form
        messages.append({
            "role": "system",
            "content": f"<wm>{recall_vecs.tolist()}</wm>"
        })
    messages.append({"role": "user", "content": text})

    # 4) Call the model
    try:
        response = model.chat(messages)
        assistant_text = response.get("text") or response.get("choices", [{}])[0].get("text", "")
    except Exception as exc:
        assistant_text = f"Model {model.name} failed: {exc}"

    # 5) Persist conversation into episodic memory
    try:
        # Use embedder again for storing the response.  If the
        # embedder is not defined due to an earlier failure, fall back
        # to the default embedder.
        if 'embedder' not in locals():
            embedder = registry.get_default_embedder()
        resp_vec = embedder.embed([assistant_text])[0]
        memory.put_memory(resp_vec, f"Q: {text}\nA: {assistant_text}")
        # Compress periodically (could be based on count/time)
        memory.compress()
    except Exception as exc:
        logger.error(f"Failed to store memory: {exc}")

    return assistant_text