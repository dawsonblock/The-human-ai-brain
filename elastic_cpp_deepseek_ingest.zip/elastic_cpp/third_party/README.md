# Third party dependencies

This project does not depend on any external libraries at runtime.  The
entire elastic‑width Transformer is implemented using the C++ standard
library.  Optional acceleration backends (CUDA, DirectML) can be
enabled via CMake options but require the respective SDKs installed on
the host system.
