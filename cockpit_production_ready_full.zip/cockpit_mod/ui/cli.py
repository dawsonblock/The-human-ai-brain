"""
Command‑line interface for the AI cockpit.

This CLI allows a user to interact with the orchestrator by typing
prompts.  It loads the model registry and memory bridge on startup
and provides a REPL for chatting.  A `--model` option can force
selection of a specific model from the registry.
"""

from __future__ import annotations

import argparse
import sys

# Relative import from parent package.  When running as a script via
# `python -m cockpit.ui.cli`, the package structure is preserved.
from ..orchestrator import handle_chat, registry


def run_cli(default_model: str | None = None) -> None:
    """Run an interactive REPL for chatting with the cockpit."""
    print("AI Cockpit CLI – type 'exit' or 'quit' to stop.")
    model_name = default_model
    # Validate model
    if model_name and model_name not in registry._models:
        print(f"Warning: unknown model '{model_name}', falling back to default.")
        model_name = None
    while True:
        try:
            user_input = input("You> ").strip()
        except EOFError:
            break
        if not user_input:
            continue
        if user_input.lower() in {"exit", "quit"}:
            break
        response = handle_chat(user_input, model_name=model_name)
        print(f"AI> {response}\n")


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="AI Cockpit CLI")
    parser.add_argument("--model", dest="model", help="Name of model to use (optional)")
    args = parser.parse_args(argv)
    run_cli(default_model=args.model)


if __name__ == "__main__":
    main(sys.argv[1:])
