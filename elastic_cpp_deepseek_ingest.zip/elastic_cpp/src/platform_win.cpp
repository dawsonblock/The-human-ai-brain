// Platform specific implementations.  Currently everything is defined
// inline in the header; this file exists for completeness.

#include "elastic/platform_win.hpp"

// Nothing to implement here.  All functions are header‑only.
