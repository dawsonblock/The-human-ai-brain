// recall.hpp
// Provides functionality to merge episodic and semantic recall into a
// fixed‑shape tensor suitable for feeding into working memory (WM).

#pragma once

#include <vector>
#include "elastic/status.hpp"
#include "elastic/tensor.hpp"
#include "elastic/memory_service.hpp"
#include "elastic/semantic_memory.hpp"

namespace elastic {

// Configuration for the recall packer.  k_episode and k_semantic
// determine how many items to retrieve from each memory source.  d
// indicates the dimensionality of the vectors (the active width), and
// normalize controls whether each row of the output tensor is L2
// normalised.
struct RecallConfig {
  int k_episode = 4;
  int k_semantic = 4;
  int d = 1024;
  bool normalize = true;
};

// A recall pack containing the concatenated recall vectors and
// metadata.  The vecs tensor has shape [K, D] where K = k_episode +
// k_semantic.  The episodic_meta and semantic_meta vectors contain
// additional information about each recalled item such as the id,
// original distance and text/summary.
struct RecallPack {
  Tensor vecs;
  std::vector<MemoryService::EpisodicHit> episodic_meta;
  std::vector<SemanticMemory::InsightHit> semantic_meta;
};

// Perform recall from episodic and semantic memories and pack the
// results into a single tensor.  The order of rows in the returned
// vecs tensor will be episodic hits first, followed by semantic
// hits.  The metadata vectors preserve this order.  The query
// tensor gw_1d must be a 1‑D tensor of length cfg.d.
StatusOr<RecallPack> recall_pack(const Tensor &gw_1d,
                                MemoryService &mem,
                                SemanticMemory &sem,
                                const RecallConfig &cfg) noexcept;

// Integrate recall vectors into working memory slots.  The wm_slots
// tensor has shape [S, D] and will be updated by copying the first
// min(K, S - slot_offset) rows of recall into the slots starting at
// slot_offset.  No gradient tracking is needed.  The recall tensor
// must have shape [K, D].
Status wm_integrate(Tensor &wm_slots, const Tensor &recall, int slot_offset = 1) noexcept;

} // namespace elastic
