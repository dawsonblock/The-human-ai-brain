// Stub DirectML backend.  A real implementation would build a
// DirectML graph for attention and feed forward operations.  In this
// reference implementation the CPU path is used instead.

#include "elastic/ops.hpp"

// No exported functions are defined for the DirectML stub.