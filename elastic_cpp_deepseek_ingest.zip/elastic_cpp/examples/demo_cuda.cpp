#include "elastic/transformer.hpp"
#include "elastic/controller.hpp"

#include <iostream>

using namespace elastic;

int main() {
#ifndef ELASTIC_USE_CUDA
  std::cout << "CUDA demo skipped: compiled without CUDA support\n";
  return 0;
#else
  // The CUDA backend is not implemented in this version.  Fall back to CPU behaviour.
  std::cout << "CUDA demo is not fully implemented; falling back to CPU operations.\n";
  TransformerConfig cfg;
  cfg.vocab = 32;
  cfg.layers = 2;
  cfg.d_max = 16;
  cfg.d_min = 8;
  Transformer model;
  if (!model.init(cfg, 12345).ok) {
    std::cerr << "Model init failed.\n";
    return 1;
  }
  StatusOr<Tensor> idx = Tensor::make({1, 4});
  if (!idx.status.ok) {
    std::cerr << "Allocation failed.\n";
    return 1;
  }
  for (int i = 0; i < 4; ++i) idx.value.data()[i] = static_cast<float>(i);
  WidthController ctrl;
  int d = ctrl.pick(0.3f, 0.5f, 2.0f);
  auto out = model.forward(idx.value, d, nullptr);
  if (!out.status.ok) {
    std::cerr << "Forward failed.\n";
    return 1;
  }
  std::cout << "CUDA demo completed; output shape: [" << out.value.shape()[0] << "," << out.value.shape()[1] << "," << out.value.shape()[2] << "]\n";
  return 0;
#endif
}