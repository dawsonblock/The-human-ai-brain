"""
Patch proposer for self‑writing.

Uses a model adapter to propose unified diff patches for a given task.
This stub returns an empty diff.
"""

from __future__ import annotations

from typing import Dict, Any
from .planner import Task


def propose_patch(adapter: Any, task: Task) -> str:
    """Ask a model to propose a unified diff patch.

    Parameters
    ----------
    adapter: Any
        The model adapter implementing chat completions.
    task: Task
        The task for which to propose a patch.

    Returns
    -------
    str
        A unified diff string.  This stub returns an empty diff.
    """
    # In a real implementation, send a prompt to the model to generate
    # a diff.  The diff should modify only the files listed in
    # task.targets and satisfy the acceptance checks.
    return ""