"""
Base classes and utilities for model adapters.

Each adapter must inherit from `ModelAdapter` and implement the
required methods.  The orchestrator relies on these methods to
perform chat completions, generate embeddings, and shut down the
model cleanly.
"""

from __future__ import annotations

from typing import List, Dict, Any, Protocol, Optional, Iterable


class ModelAdapter(Protocol):  # pragma: no cover
    """Adapter interface for models.

    Adapters wrap different backends (e.g. llama.cpp, vLLM, OCR) and
    expose a uniform API.  The orchestrator calls these methods
    without needing to know the details of the underlying model.

    Attributes
    ----------
    name: str
        A human‑readable name for the adapter.
    capabilities: set[str]
        A set of capability strings.  Must include at least
        'chat' for chat models or 'vision' for OCR models.  If the
        adapter can produce embeddings, include 'embed'.
    """

    name: str
    capabilities: set[str]

    def load(self, **kwargs: Any) -> None:
        """Load the model and prepare it for inference.

        Parameters
        ----------
        **kwargs: Any
            Adapter‑specific parameters such as model path, device,
            context length, etc.
        """
        raise NotImplementedError

    def chat(self, messages: List[Dict[str, str]], **kwargs: Any) -> Dict[str, Any]:
        """Generate a chat completion.

        Parameters
        ----------
        messages: List[Dict[str, str]]
            A list of message dicts, each with keys 'role' and 'content'.
        **kwargs: Any
            Backend‑specific generation parameters.

        Returns
        -------
        Dict[str, Any]
            A dictionary containing the generated text under key 'text' or
            'choices'.
        """
        raise NotImplementedError

    def embed(self, texts: Iterable[str], **kwargs: Any) -> List[List[float]]:
        """Generate embeddings for a batch of texts.

        Parameters
        ----------
        texts: Iterable[str]
            The texts to embed.
        **kwargs: Any
            Backend‑specific parameters.

        Returns
        -------
        List[List[float]]
            A list of embedding vectors (float lists) per input text.
        """
        raise NotImplementedError

    def stop(self) -> None:
        """Cleanly shut down the adapter and free resources."""
        raise NotImplementedError
