
from __future__ import annotations
from typing import List, Optional, Callable
from dataclasses import dataclass, field
import time

from .chunking import Chunk, Unit, Chunker

@dataclass
class WorkingMemory:
    capacity: int = 4
    chunk_size: int = 4
    decay_seconds: float = 20.0
    slots: List[Chunk] = field(default_factory=list)
    score_fn: Optional[Callable[[Chunk], float]] = None

    def __post_init__(self):
        if self.score_fn is None:
            self.score_fn = self.default_score

    def default_score(self, ch: Chunk) -> float:
        age = time.time() - ch.ts
        freshness = max(0.0, 1.0 - age / max(1.0, self.decay_seconds))
        return 0.7 * ch.relevance + 0.3 * freshness

    def add_chunk(self, ch: Chunk) -> None:
        if len(self.slots) >= self.capacity:
            self.evict_least_useful()
        self.slots.append(ch)

    def evict_least_useful(self) -> None:
        if not self.slots: return
        scores = [self.score_fn(c) for c in self.slots]
        idx = min(range(len(self.slots)), key=lambda i: scores[i])
        self.slots.pop(idx)

    def add_units(self, units: List[Unit]) -> None:
        ch = Chunker(max_items=self.chunk_size)
        for chunk in ch.make_chunks(units):
            self.add_chunk(chunk)

    def context_summary(self) -> dict:
        total_units = sum(len(c.items) for c in self.slots)
        return {
            "num_slots": len(self.slots),
            "total_units": total_units,
            "slots": [{
                "size": len(c.items),
                "relevance": round(c.relevance, 3),
                "age": round(time.time() - c.ts, 3),
            } for c in self.slots]
        }

    def effective_capacity(self) -> int:
        return self.capacity * self.chunk_size
