#include "elastic/dynamic_linear.hpp"
#include "elastic/rng.hpp"
#include <cassert>
#include <iostream>

using namespace elastic;

// Naive linear for verification
static void naive_linear(const Tensor& W, const Tensor& b, const float* x_row, int d_active, float* out_row, int d_out) {
  const float* w_ptr = W.data();
  const float* b_ptr = b.data();
  int D_MAX = W.shape()[1];
  for (int j = 0; j < d_out; ++j) {
    float acc = b_ptr ? b_ptr[j] : 0.0f;
    const float* w_row = w_ptr + static_cast<size_t>(j) * D_MAX;
    for (int i = 0; i < d_active; ++i) {
      acc += x_row[i] * w_row[i];
    }
    out_row[j] = acc;
  }
}

int main() {
  DynamicLinear lin;
  int d_out = 8;
  int D_MAX = 8;
  assert(lin.init(d_out, D_MAX, true, 123).ok);
  // Build a simple input tensor [2, d_active]
  for (int d_active : {2, 4, 6, 8}) {
    StatusOr<Tensor> maybe_x = Tensor::make({2, d_active});
    assert(maybe_x.status.ok);
    Tensor x = std::move(maybe_x.value);
    // Fill with deterministic values
    for (size_t i = 0; i < x.size(); ++i) {
      x.data()[i] = static_cast<float>(i) * 0.1f;
    }
    auto y = lin.forward(x, d_active);
    assert(y.status.ok);
    // Check shape
    auto sh = y.value.shape();
    assert(sh.size() == 2);
    assert(sh[0] == 2 && sh[1] == d_out);
    // Verify against naive computation for first row
    std::vector<float> naive(d_out);
    naive_linear(lin.W, lin.b, x.data(), d_active, naive.data(), d_out);
    for (int j = 0; j < d_out; ++j) {
      float diff = std::abs(y.value.data()[j] - naive[j]);
      assert(diff < 1e-5f);
    }
  }
  std::cout << "test_dynamic_slice passed\n";
  return 0;
}