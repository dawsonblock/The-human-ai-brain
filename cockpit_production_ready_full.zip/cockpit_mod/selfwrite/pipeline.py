"""
Self‑writing pipeline orchestrator.

Coordinates planning, patching, gating, sandboxing, and git operations
to automate changes to the cockpit codebase.  This stub
implementation uses simplified logic and always succeeds.
"""

from __future__ import annotations

from typing import Dict, Any, Optional

from .planner import plan
from .patcher import propose_patch
from .gate import load_policy, check_patch
from .tests_runner import run_tests
from .attest import attest_patch
from .gitops import apply

from cockpit.orchestrator.registry import Registry


def run_selfwrite(goal: str, model: Optional[str] = None, dry_run: bool = True) -> Dict[str, Any]:
    """Execute a self‑write cycle.

    Parameters
    ----------
    goal: str
        The high‑level change request.
    model: Optional[str]
        Name of the model to use for code generation.  If None, use
        the default model.
    dry_run: bool
        If True, do not apply changes to the main repository.

    Returns
    -------
    dict
        A dictionary summarizing the outcome.
    """
    # Instantiate registry and select model.  Compute the config path
    # relative to this file so that it works regardless of cwd.
    import os
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    config_path = os.path.join(base_dir, "config", "models.yaml")
    reg = Registry(config_path=config_path)
    if model:
        adapter = reg.get(model)
    else:
        adapter = reg.get_default()
    # Plan tasks
    tasks = plan(goal, repo_root=".")
    policy = load_policy()
    for task in tasks:
        diff = propose_patch(adapter, task)
        ok, reason = check_patch(diff, policy)
        if not ok:
            return {"ok": False, "stage": "gate", "reason": reason}
        # Run tests and lint checks in isolation
        res = run_tests(diff, repo_root=".")
        if not (res.get("lint") and res.get("format") and res.get("tests")):
            return {"ok": False, "stage": "sandbox", "detail": res}
        # Create an attestation before merging
        attestation = attest_patch(diff)
        merge_info = apply(diff, repo_root=".", dry_run=dry_run)
        return {
            "ok": True,
            "result": merge_info,
            "detail": res,
            "attestation": attestation,
        }
    return {"ok": False, "stage": "plan", "reason": "No tasks generated"}