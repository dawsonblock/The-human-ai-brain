"""
Cost/SLA‑aware routing logic for model selection.

This module defines a function that selects a model adapter based on
the estimated number of tokens in the input and configurable cost
and latency budgets.  The goal is to minimise resource usage while
still meeting service level objectives (SLOs).
"""

from __future__ import annotations

from typing import Any

from .registry import Registry


def estimate_tokens(text: str) -> int:
    """Rudimentary token estimator.

    Assumes roughly one token per 4 characters.  This is not
    accurate for all languages or models but suffices for routing
    heuristics.
    """
    return max(1, len(text) // 4)


def choose_model_by_cost(
    text: str,
    registry: Registry,
    max_latency: float = 1.0,
    max_cost: float = 0.05,
) -> Any:
    """Select a model based on cost and latency budgets.

    Parameters
    ----------
    text: str
        The user prompt.
    registry: Registry
        Registry of loaded model adapters.
    max_latency: float
        Maximum allowed latency in seconds (unused in this simple heuristic).
    max_cost: float
        Maximum allowed cost per request (unused in this simple heuristic).

    Returns
    -------
    ModelAdapter
        The selected model adapter.
    """
    tokens = estimate_tokens(text)
    # Heuristic: if the prompt is short, prefer a model whose name
    # contains "small", if such a model exists.  Otherwise use the default.
    if tokens < 200:
        for name, adapter in registry._models.items():
            if "small" in name:
                return adapter
    return registry.get_default()
