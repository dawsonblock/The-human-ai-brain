"""
Python bridge for interacting with the C++ ElasticRecall memory DLL.

This class attempts to load the C DLL exposing the functions
`elastic_init_memory`, `elastic_recall`, `elastic_put_memory` and
`elastic_compress`.  If the DLL cannot be loaded, it falls back to
an in-memory implementation that simply stores vectors and texts in
Python data structures.  This ensures the code runs even in
development environments without the compiled DLL.
"""

from __future__ import annotations

import ctypes
from ctypes import c_float, c_int, c_char_p, c_ulonglong, POINTER
import numpy as np
import os
import logging


class ElasticMemory:
    def __init__(self, lib_path: str, db_path: str) -> None:
        self.lib_path = lib_path
        self.db_path = db_path
        self._dll = None
        self._init_stub()
        self._init_dll()

    def _init_dll(self) -> None:
        """Attempt to load the DLL and initialise memory."""
        if not os.path.exists(self.lib_path):
            logging.warning(f"Elastic memory DLL not found at {self.lib_path}; using stub memory implementation.")
            return
        try:
            self._dll = ctypes.CDLL(self.lib_path)
            # Bind signatures
            self._dll.elastic_init_memory.argtypes = [c_char_p]
            self._dll.elastic_init_memory.restype = c_int
            self._dll.elastic_recall.argtypes = [POINTER(c_float), c_int, c_int, c_int, POINTER(c_float), c_int]
            self._dll.elastic_recall.restype = c_int
            self._dll.elastic_put_memory.argtypes = [POINTER(c_float), c_int, c_char_p, c_float, c_ulonglong]
            self._dll.elastic_put_memory.restype = c_int
            self._dll.elastic_compress.argtypes = []
            self._dll.elastic_compress.restype = c_int
            # Initialise the memory service
            rc = self._dll.elastic_init_memory(self.db_path.encode("utf-8"))
            if rc != 0:
                logging.warning(f"elastic_init_memory returned {rc}; fallback to stub.")
                self._dll = None
        except Exception as exc:
            logging.warning(f"Failed to load ElasticRecall DLL: {exc}")
            self._dll = None

    def _init_stub(self) -> None:
        """Initialise the stub storage for fallback mode."""
        self._episodic: list[tuple[np.ndarray, str, float, int]] = []  # (vec, text, reward, ts)
        self._semantic: list[tuple[np.ndarray, str]] = []  # (mean vec, summary)

    def recall(self, query_vec: np.ndarray, k_episode: int, k_semantic: int) -> np.ndarray:
        """Recall episodic and semantic vectors based on a query.

        Returns a matrix of shape (k_episode + k_semantic, d).  If the
        underlying DLL is loaded, it delegates to the C function.
        Otherwise performs a simple nearest neighbour search over the
        stub store.
        """
        if query_vec.dtype != np.float32:
            query_vec = query_vec.astype(np.float32)
        d = query_vec.size
        total_k = k_episode + k_semantic
        out = np.zeros((total_k, d), dtype=np.float32)
        if self._dll is not None:
            rc = self._dll.elastic_recall(query_vec.ctypes.data_as(POINTER(c_float)), c_int(d), c_int(k_episode), c_int(k_semantic), out.ctypes.data_as(POINTER(c_float)), c_int(total_k))
            # ignore rc; if rc < total_k some rows will remain zero
            return out
        # stub implementation: naive nearest neighbour on episodic memory only
        if not self._episodic:
            return out
        # Compute cosine similarity for ranking (higher is better)
        sims = []
        for idx, (vec, text, reward, ts) in enumerate(self._episodic):
            if vec.size != d:
                continue
            # normalise
            if np.linalg.norm(vec) == 0 or np.linalg.norm(query_vec) == 0:
                sim = 0.0
            else:
                sim = float(np.dot(vec, query_vec) / (np.linalg.norm(vec) * np.linalg.norm(query_vec)))
            sims.append((sim, idx))
        sims.sort(reverse=True)
        # Top episodic
        for i in range(min(k_episode, len(sims))):
            _, idx = sims[i]
            out[i] = self._episodic[idx][0]
        # Top semantic: simple reuse of episodic means
        sem_start = k_episode
        for j in range(min(k_semantic, len(self._semantic))):
            out[sem_start + j] = self._semantic[j][0]
        return out

    def put_memory(self, embedding: np.ndarray, text: str, reward: float = 0.0, ts: int = 0) -> None:
        """Store a new episodic memory entry.

        If the DLL is loaded, delegate to the C API.  Otherwise append
        to the stub store.
        """
        if embedding.dtype != np.float32:
            embedding = embedding.astype(np.float32)
        d = embedding.size
        if self._dll is not None:
            rc = self._dll.elastic_put_memory(embedding.ctypes.data_as(POINTER(c_float)), c_int(d), text.encode("utf-8"), c_float(reward), c_ulonglong(ts))
            if rc != 0:
                logging.warning(f"elastic_put_memory returned {rc}")
            return
        # stub
        self._episodic.append((embedding.copy(), text, reward, ts))

    def compress(self) -> None:
        """Trigger semantic compression.

        If the DLL is loaded, call the C API.  Otherwise perform a
        simple mean aggregation over every 10 episodic entries.
        """
        if self._dll is not None:
            rc = self._dll.elastic_compress()
            if rc != 0:
                logging.warning(f"elastic_compress returned {rc}")
            return
        # stub semantic compression: group by 10 episodes
        group_size = 10
        while len(self._episodic) >= group_size:
            group = self._episodic[:group_size]
            self._episodic = self._episodic[group_size:]
            # mean vector
            vecs = np.stack([item[0] for item in group], axis=0)
            mean_vec = vecs.mean(axis=0)
            summary = "\n".join([item[1] for item in group])[:256]
            self._semantic.append((mean_vec, summary))