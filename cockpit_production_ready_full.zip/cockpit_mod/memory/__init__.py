"""
Memory package exposing the ElasticMemory bridge.
"""

from .elastic_memory import ElasticMemory