"""
Application configuration using pydantic settings.

This module defines a `Settings` class that reads configuration from
environment variables prefixed with `COCKPIT_`.  These values are
loaded once when the settings instance is created and can be
referenced throughout the application.  See README for details.
"""
from __future__ import annotations

from pydantic import BaseSettings, Field


class Settings(BaseSettings):
    """Configuration settings for the cockpit API."""

    # Comma-separated API keys for authentication
    api_keys: str = Field(..., env="API_KEYS")
    # Path to the models configuration file
    models_config: str = Field("cockpit_mod/config/models.yaml", env="MODELS_CONFIG")
    # Path to the memory database file
    memory_db: str = Field("memory.db", env="MEMORY_DB")
    # Working memory entropy threshold
    wm_threshold: float = Field(1.39, env="WM_THRESHOLD")
    # Working memory decay factor
    wm_decay: float = Field(0.1, env="WM_DECAY")
    # Qdrant host and port
    qdrant_host: str = Field("localhost", env="QDRANT_HOST")
    qdrant_port: int = Field(6333, env="QDRANT_PORT")
    # JWT secret key for token authentication
    jwt_secret_key: str = Field("change_me", env="JWT_SECRET_KEY")
    # Redis URL for rate limiting
    rate_limit_redis_url: str = Field("redis://localhost:6379", env="RATE_LIMIT_REDIS_URL")

    class Config(BaseSettings.Config):
        env_prefix = "COCKPIT_"


def get_settings() -> Settings:
    """Return a singleton settings instance."""
    # This caching ensures environment variables are read only once
    if not hasattr(get_settings, "_settings"):
        get_settings._settings = Settings()  # type: ignore[attr-defined]
    return get_settings._settings