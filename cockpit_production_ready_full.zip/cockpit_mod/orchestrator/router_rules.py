"""
Heuristic routing rules for model selection.

This module defines helper functions used by the orchestrator to
select among multiple loaded model adapters based on simple
heuristics such as prompt length, capabilities, or cost budgets.
"""
from __future__ import annotations

from typing import Any

from .registry import Registry


def choose_model_by_length(text: str, registry: Registry) -> Any:
    """Select a model based on the length of the input text.

    Short prompts use a smaller/faster model if available; longer
    prompts default to the primary model.  If no small model exists,
    the default model is returned.
    """
    # Example heuristic: if there is a model named "small" use it for
    # prompts under 100 characters.
    if len(text) < 100:
        for name, adapter in registry._models.items():
            if "small" in name:
                return adapter
    return registry.get_default()