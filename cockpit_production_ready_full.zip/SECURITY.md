# Security Policy

This document outlines our approach to securing the cockpit AI system in production.

## API Authentication

- Use JWT or HMAC‑signed requests over HTTPS. Rotate secrets regularly via a secret manager.
- API keys must not be stored in the repository. They are provided via environment variables.

## Secrets Management

- All sensitive configuration (API keys, JWT secrets, database credentials) must be injected through a secret manager (e.g. HashiCorp Vault, AWS Secrets Manager).
- Do not commit secrets to version control. Use environment variables or dedicated secrets providers in deployment manifests.

## Dependency Management

- All third‑party Python packages are pinned in `requirements.txt` and updated regularly.
- The CI pipeline runs static analysis and security scans (`bandit`) on every pull request.

## Self‑Write Policies

- Self‑writing capabilities are gated by explicit policy rules defined in `cockpit_mod/selfwrite/gate.py` and optional Rego policies under `opa/`.
- Only files under `cockpit_mod/` are permitted to change automatically.
- Forbidden patterns such as `os.system` and `subprocess` calls are blocked by the gate.

## Container Isolation

- Runtime code execution (e.g. self‑writing sandbox) occurs in isolated temporary directories.
- When fully deployed, a container sandbox (Firejail or Docker) should be used to restrict system access during code generation and testing.

## Transport Security

- All services (API, vector stores, model servers) must be exposed only over TLS when running in production.
- Reverse proxies such as NGINX or Traefik should terminate TLS and enforce strict TLS cipher suites.

## Incident Response

- If a security vulnerability is discovered, please open an issue and notify the maintainers.
- Follow the runbooks in `RUNBOOK.md` for guidance on incident handling, patching, and recovery.
