
import torch
from .model import ElasticTransformer
from .controller import WidthController

def main():
    torch.manual_seed(0)
    vocab=128; B,T=2,16
    model = ElasticTransformer(vocab=vocab, d_max=1024, d_min=256, layers=2)
    ctrl = WidthController()
    idx = torch.randint(0, vocab, (B,T))
    d = ctrl.pick(load=0.3, entropy=1.3, latency_budget_ms=25.0)
    print("Active width d:", d)
    logits = model(idx, d)
    print("Logits shape:", logits.shape)
    loss = torch.nn.functional.cross_entropy(logits.view(-1, vocab), idx.view(-1))
    loss.backward()
    print("Loss:", float(loss))

if __name__ == "__main__":
    main()
