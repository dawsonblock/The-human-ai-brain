// test_recall_pack.cpp
#include "elastic/memory_service.hpp"
#include "elastic/semantic_memory.hpp"
#include "elastic/recall.hpp"
#include "elastic/tensor.hpp"
#include <cassert>
#include <cmath>
#include <iostream>

int main() {
  elastic::MemoryService mem(":memory:");
  elastic::SemanticMemory sem(mem);
  // Insert three episodic memories in 8-D for predictable nearest neighbours
  const int D = 8;
  {
    auto t1_or = elastic::Tensor::make({D});
    auto t2_or = elastic::Tensor::make({D});
    auto t3_or = elastic::Tensor::make({D});
    auto e1 = t1_or.value;
    auto e2 = t2_or.value;
    auto e3 = t3_or.value;
    float *d1 = e1.as_span().data();
    float *d2 = e2.as_span().data();
    float *d3 = e3.as_span().data();
    // e1 = [1,0,0,...]
    // e2 = [0,1,0,...]
    // e3 = [0,0,1,0,...]
    for (int i = 0; i < D; ++i) {
      d1[i] = (i == 0) ? 1.0f : 0.0f;
      d2[i] = (i == 1) ? 1.0f : 0.0f;
      d3[i] = (i == 2) ? 1.0f : 0.0f;
    }
    assert(mem.Put(e1, "A").ok);
    assert(mem.Put(e2, "B").ok);
    assert(mem.Put(e3, "C").ok);
  }
  // Create two identical insights by compressing twice
  assert(sem.CompressAll().ok);
  assert(sem.CompressAll().ok);
  // Query equal to e1
  auto q_or = elastic::Tensor::make({D});
  auto q = q_or.value;
  float *qd = q.as_span().data();
  for (int i = 0; i < D; ++i) qd[i] = (i == 0) ? 1.0f : 0.0f;
  elastic::RecallConfig rc;
  rc.k_episode = 2;
  rc.k_semantic = 2;
  rc.d = D;
  rc.normalize = true;
  auto rp_or = elastic::recall_pack(q, mem, sem, rc);
  assert(rp_or.status.ok);
  auto pack = rp_or.value;
  // Expect 4 recall vectors
  assert(pack.vecs.shape().size() == 2);
  assert(pack.vecs.shape()[0] == 4);
  assert(pack.vecs.shape()[1] == D);
  // Row norms should be ~1
  const float *vec = pack.vecs.as_span().data();
  for (int i = 0; i < 4; ++i) {
    float norm = 0.0f;
    for (int j = 0; j < D; ++j) norm += vec[i * D + j] * vec[i * D + j];
    assert(std::fabs(norm - 1.0f) < 1e-4);
  }
  // First two rows should equal e1 and e2 (in some order) due to query closeness
  // Check that each of the first two rows has exactly one value ~1 and others ~0.
  int count_match = 0;
  for (int i = 0; i < 2; ++i) {
    int nonzero_idx = -1;
    for (int j = 0; j < D; ++j) {
      if (vec[i * D + j] > 0.9f) {
        if (nonzero_idx == -1) {
          nonzero_idx = j;
        } else {
          nonzero_idx = -2; // multiple non-zero entries
          break;
        }
      }
    }
    assert(nonzero_idx == 0 || nonzero_idx == 1);
    if (nonzero_idx == 0 || nonzero_idx == 1) ++count_match;
  }
  assert(count_match == 2);
  // Last two rows should have three roughly equal values (insight mean of e1,e2,e3)
  for (int i = 2; i < 4; ++i) {
    float a = vec[i * D + 0];
    float b = vec[i * D + 1];
    float c = vec[i * D + 2];
    // values should be approximately equal
    assert(std::fabs(a - b) < 1e-3 && std::fabs(b - c) < 1e-3);
  }
  std::cout << "RecallPack tests passed\n";
  return 0;
}