
class RaggedKVCache:
    def __init__(self):
        self.cache = {}
    def get_bucket(self, d):
        if d not in self.cache:
            self.cache[d] = {"k": None, "v": None}
        return self.cache[d]
    def clear(self):
        self.cache.clear()
