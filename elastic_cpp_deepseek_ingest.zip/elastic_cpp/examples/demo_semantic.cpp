// demo_semantic.cpp
// Demonstrates semantic memory compression and insight retrieval.  This
// program builds upon the MemoryService by inserting a handful of
// episodic memories, compressing them into a single insight and then
// retrieving that insight given a query embedding.

#include "elastic/memory_service.hpp"
#include "elastic/semantic_memory.hpp"
#include "elastic/recall.hpp"
#include "elastic/tensor.hpp"
#include <iostream>
#include <random>

int main() {
  elastic::MemoryService mem("semantic.db");
  elastic::SemanticMemory sem(mem);
  // Insert episodic memories
  std::mt19937 rng(123);
  std::uniform_real_distribution<float> dist(0.0f, 1.0f);
  const char *texts[] = {"First encounter with robot arm.",
                         "Observed failure due to motor stall.",
                         "Adjusted PID gains for smoother motion.",
                         "Successfully completed pick and place.",
                         "Documented new calibration procedure."};
  for (int i = 0; i < 5; ++i) {
    auto t_or = elastic::Tensor::make({8});
    elastic::Tensor emb = t_or.value;
    float *d = emb.as_span().data();
    for (int j = 0; j < 8; ++j) {
      d[j] = dist(rng);
    }
    auto st = mem.Put(emb, texts[i]);
    if (!st.ok) {
      std::cerr << "Insert failed: " << st.msg << std::endl;
    }
  }
  // Compress all episodic memories into one insight
  auto stc = sem.CompressAll();
  if (!stc.ok) {
    std::cerr << "Compress failed: " << stc.msg << std::endl;
    return 1;
  }
  // Build a random query as the current GW vector and perform recall
  auto q_or = elastic::Tensor::make({8});
  elastic::Tensor gw = q_or.value;
  float *qd = gw.as_span().data();
  for (int i = 0; i < 8; ++i) qd[i] = dist(rng);
  elastic::RecallConfig rc;
  rc.k_episode = 3;
  rc.k_semantic = 1;
  rc.d = 8;
  rc.normalize = true;
  auto rp_or = elastic::recall_pack(gw, mem, sem, rc);
  if (!rp_or.status.ok) {
    std::cerr << "Recall failed: " << rp_or.status.msg << std::endl;
    return 1;
  }
  elastic::RecallPack rp = rp_or.value;
  // Create a dummy working memory tensor with 5 slots (slot 0 reserved)
  auto wm_or = elastic::Tensor::make({5, 8});
  elastic::Tensor wm = wm_or.value;
  wm.fill(0);
  auto stwi = elastic::wm_integrate(wm, rp.vecs, /*slot_offset=*/1);
  if (!stwi.ok) {
    std::cerr << "WM integrate failed: " << stwi.msg << std::endl;
    return 1;
  }
  // Print recall summary
  std::cout << "RecallPack: K=" << rp.vecs.shape()[0] << ", D=" << rp.vecs.shape()[1] << "\n";
  std::cout << "Episodic hits: " << rp.episodic_meta.size() << ", Semantic hits: " << rp.semantic_meta.size() << "\n";
  for (const auto &hit : rp.episodic_meta) {
    std::cout << "Episodic id=" << hit.id << " dist=" << hit.score << " reward=" << hit.reward
              << " text=" << hit.text.substr(0, 80) << "\n";
  }
  for (const auto &hit : rp.semantic_meta) {
    std::cout << "Semantic id=" << hit.id << " dist=" << hit.score
              << " summary=" << hit.summary.substr(0, 80) << "\n";
  }
  return 0;
}