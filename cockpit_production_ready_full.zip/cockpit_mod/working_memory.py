"""
Working memory management with entropy-based collapse and continuous update.

This module defines a simple `WorkingMemory` class that maintains a
low‑dimensional state vector and decides when to reset that state
based on its information content.  The design is inspired by the
Finite‑Dimensional Quantum Consciousness (FDQC) model where a
thalamic reticular nucleus monitors the entropy of the current
working memory representation and triggers a collapse to a new state
when the entropy exceeds a threshold.  In our adaptation, the state
vector holds a small number of floating‑point values (default 4
dimensions).  On each update call a candidate vector is provided
(for example an embedding of the current user query).  The class
computes a discrete probability distribution from the absolute
values of the current state vector and measures its Shannon entropy
in bits.  If this entropy exceeds the configured threshold the
working memory collapses: the internal state is replaced with the
candidate.  Otherwise the state blends towards the candidate using
an exponential moving average.  The update method returns a
Boolean indicating whether a collapse occurred.

This mechanism can be used by higher‑level orchestrator code to
decide whether to inject recalled context into prompts.  When a
collapse occurs the previous context is considered irrelevant and
should be dropped; when no collapse occurs the existing state still
contains useful structure and the recalled context can inform the
assistant.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import math
import numpy as np


@dataclass
class WorkingMemory:
    """Simple working memory with entropy‑based collapse.

    Parameters
    ----------
    n_dim: int
        Dimensionality of the working memory vector.
    threshold: float
        Entropy threshold in bits.  When the computed Shannon
        entropy of the current state exceeds this value, the state
        will be replaced by the candidate vector on the next update.
    decay: float
        Interpolation factor used when blending the current state
        towards the candidate during continuous updates.  Must be in
        the interval [0, 1].  A smaller value results in slower
        adaptation; a value of 1 means the state is replaced
        immediately on every non‑collapse update (pure overwriting).
    """

    n_dim: int = 4
    threshold: float = 1.39  # approximately log2(4)
    decay: float = 0.1

    def __post_init__(self) -> None:
        # initialise state to zero vector
        self._state: np.ndarray = np.zeros(self.n_dim, dtype=np.float32)

    def _entropy(self) -> float:
        """Compute the Shannon entropy of the current state in bits.

        The probability distribution is derived from the absolute
        values of the state vector.  If the state is all zeros, a
        uniform distribution is assumed.

        Returns
        -------
        float
            The Shannon entropy in bits.
        """
        abs_vals = np.abs(self._state)
        total = float(abs_vals.sum())
        if total == 0.0:
            # uniform distribution yields maximal entropy log2(n_dim)
            return math.log2(self.n_dim)
        # normalise to a probability distribution
        p = abs_vals / total
        # compute entropy in bits; add small epsilon to avoid log(0)
        eps = 1e-12
        entropy = -float(np.sum(p * np.log2(p + eps)))
        return entropy

    def update(self, candidate: np.ndarray) -> bool:
        """Update the working memory with a new candidate vector.

        Parameters
        ----------
        candidate: np.ndarray
            A one‑dimensional NumPy array representing the proposed
            new working memory contents (e.g. an embedding of the
            current user query).  It will be cast to the correct
            dtype and length if necessary.

        Returns
        -------
        bool
            True if a collapse occurred (the state was replaced by
            the candidate), False if the state was smoothly updated.
        """
        # ensure candidate is a 1D float array of the correct length
        if candidate is None:
            return False
        vec = np.asarray(candidate, dtype=np.float32).flatten()
        if vec.size != self.n_dim:
            # If the candidate dimensionality differs, resize by
            # truncation or zero‑padding.
            if vec.size > self.n_dim:
                vec = vec[: self.n_dim]
            else:
                padded = np.zeros(self.n_dim, dtype=np.float32)
                padded[: vec.size] = vec
                vec = padded
        entropy = self._entropy()
        collapse = entropy > self.threshold
        if collapse:
            # replace state entirely
            self._state = vec.copy()
        else:
            # blend old state towards candidate
            self._state = (1.0 - self.decay) * self._state + self.decay * vec
        return collapse

    def get_state(self) -> np.ndarray:
        """Return a copy of the current working memory state."""
        return self._state.copy()