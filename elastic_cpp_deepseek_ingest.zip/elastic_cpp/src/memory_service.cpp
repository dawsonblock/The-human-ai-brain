// memory_service.cpp
// Implements the MemoryService defined in memory_service.hpp.  This
// implementation uses SQLite for persistence and performs a
// brute‑force L2 distance search over stored embeddings.  Because
// SQLite does not natively support vector search, we fetch all
// embeddings into memory when searching.  While this is not as
// efficient as a specialised approximate nearest neighbour index
// (e.g. FAISS), it avoids external dependencies and suffices for
// datasets on the order of tens of thousands of memories.  For more
// substantial deployments a hybrid approach could be adopted.

#include "elastic/memory_service.hpp"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <iostream>

#include <sqlite3.h>

namespace elastic {

namespace {
// Helper: flatten an arbitrary tensor into a 1D vector of floats.  If
// the tensor is not of float type an error Status is returned.
StatusOr<std::vector<float>> FlattenTensor(const Tensor &t) {
  // Only float32 tensors supported
  const float *data = reinterpret_cast<const float *>(t.data());
  if (!data) {
    return Status::Error("Null tensor data in FlattenTensor");
  }
  size_t total = 1;
  for (int d : t.shape()) total *= static_cast<size_t>(d);
  std::vector<float> out(total);
  std::memcpy(out.data(), data, total * sizeof(float));
  return StatusOr<std::vector<float>>(std::move(out));
}

// Serialize a vector<float> into a binary blob with the dimension
// prefix.  Format: [int32 dim][float values...].  This helps
// reconstruct the embedding dimension on read.
static std::vector<uint8_t> SerializeEmbedding(const std::vector<float> &vec) {
  int dim = static_cast<int>(vec.size());
  std::vector<uint8_t> blob(sizeof(int) + dim * sizeof(float));
  std::memcpy(blob.data(), &dim, sizeof(int));
  std::memcpy(blob.data() + sizeof(int), vec.data(), dim * sizeof(float));
  return blob;
}

// Deserialize a blob created by SerializeEmbedding back into a
// vector<float>.  On invalid data returns an empty vector.
static std::vector<float> DeserializeEmbedding(const void *data, int bytes) {
  if (!data || bytes < static_cast<int>(sizeof(int))) return {};
  int dim;
  std::memcpy(&dim, data, sizeof(int));
  if (bytes < static_cast<int>(sizeof(int) + dim * sizeof(float))) return {};
  const float *vals = reinterpret_cast<const float *>(static_cast<const char *>(data) + sizeof(int));
  return std::vector<float>(vals, vals + dim);
}

// Compute squared L2 distance between two vectors.  Both vectors must
// have the same length.
static float SquaredL2(const std::vector<float> &a, const std::vector<float> &b) {
  size_t n = a.size();
  if (b.size() != n) {
    // Mismatched dims; treat as very far
    return std::numeric_limits<float>::max();
  }
  float sum = 0.0f;
  for (size_t i = 0; i < n; ++i) {
    float diff = a[i] - b[i];
    sum += diff * diff;
  }
  return sum;
}
} // namespace

MemoryService::MemoryService(const std::string &db_path) {
  if (sqlite3_open(db_path.c_str(), &db_) != SQLITE_OK) {
    std::cerr << "Failed to open SQLite DB: " << sqlite3_errmsg(db_) << std::endl;
    db_ = nullptr;
    return;
  }
  const char *create_sql =
      "CREATE TABLE IF NOT EXISTS memory ("                    \
      "id INTEGER PRIMARY KEY AUTOINCREMENT,"                 \
      "dim INTEGER NOT NULL,"                                 \
      "embedding BLOB NOT NULL,"                              \
      "text TEXT NOT NULL,"                                   \
      "reward REAL DEFAULT 0.0,"                             \
      "ts INTEGER DEFAULT 0"                                 \
      ");";
  char *err = nullptr;
  if (sqlite3_exec(db_, create_sql, nullptr, nullptr, &err) != SQLITE_OK) {
    std::cerr << "Failed to create table: " << err << std::endl;
    sqlite3_free(err);
  }
  // If the table existed without reward/ts columns, attempt to add them.
  // These statements will silently fail if the columns already exist.
  char *err2 = nullptr;
  sqlite3_exec(db_, "ALTER TABLE memory ADD COLUMN reward REAL DEFAULT 0.0;", nullptr, nullptr, &err2);
  if (err2) sqlite3_free(err2);
  char *err3 = nullptr;
  sqlite3_exec(db_, "ALTER TABLE memory ADD COLUMN ts INTEGER DEFAULT 0;", nullptr, nullptr, &err3);
  if (err3) sqlite3_free(err3);
}

MemoryService::~MemoryService() {
  if (db_) sqlite3_close(db_);
}

Status MemoryService::Put(const Tensor &embedding, const std::string &text,
                          float reward, uint64_t ts_unix) {
  if (!db_) return Status::Error("DB not initialized");
  auto flat_or = FlattenTensor(embedding);
  if (!flat_or.status.ok) {
    return flat_or.status;
  }
  std::vector<float> flat = std::move(flat_or.value);
  int dim = static_cast<int>(flat.size());
  std::vector<uint8_t> blob = SerializeEmbedding(flat);
  const char *sql = "INSERT INTO memory (dim, embedding, text, reward, ts) VALUES (?1, ?2, ?3, ?4, ?5);";
  sqlite3_stmt *stmt;
  if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
    return Status::Error("Failed to prepare insert statement");
  }
  sqlite3_bind_int(stmt, 1, dim);
  sqlite3_bind_blob(stmt, 2, blob.data(), (int)blob.size(), SQLITE_STATIC);
  sqlite3_bind_text(stmt, 3, text.c_str(), -1, SQLITE_STATIC);
  sqlite3_bind_double(stmt, 4, static_cast<double>(reward));
  sqlite3_bind_int64(stmt, 5, static_cast<sqlite3_int64>(ts_unix));
  if (sqlite3_step(stmt) != SQLITE_DONE) {
    sqlite3_finalize(stmt);
    return Status::Error("Failed to execute insert");
  }
  sqlite3_finalize(stmt);
  return Status::OK();
}

StatusOr<std::vector<MemoryService::SearchResult>>
MemoryService::Search(const Tensor &query, int k) const {
  if (!db_) return StatusOr<std::vector<SearchResult>>(Status::Error("DB not initialized"));
  if (k <= 0) return StatusOr<std::vector<SearchResult>>(Status::Error("k must be positive"));
  auto flat_or = FlattenTensor(query);
  if (!flat_or.status.ok) {
    return StatusOr<std::vector<SearchResult>>(flat_or.status);
  }
  std::vector<float> qvec = std::move(flat_or.value);
  // Retrieve all rows
  const char *sql = "SELECT embedding, text FROM memory;";
  sqlite3_stmt *stmt;
  if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
    return StatusOr<std::vector<SearchResult>>(Status::Error("Failed to prepare select"));
  }
  std::vector<SearchResult> results;
  while (sqlite3_step(stmt) == SQLITE_ROW) {
    const void *blob = sqlite3_column_blob(stmt, 0);
    int bytes = sqlite3_column_bytes(stmt, 0);
    std::vector<float> vec = DeserializeEmbedding(blob, bytes);
    if (vec.empty()) continue;
    const unsigned char *text = sqlite3_column_text(stmt, 1);
    std::string s = text ? reinterpret_cast<const char *>(text) : "";
    float dist = SquaredL2(qvec, vec);
    results.emplace_back(dist, s);
  }
  sqlite3_finalize(stmt);
  // Sort by distance ascending
  std::sort(results.begin(), results.end(), [](const SearchResult &a, const SearchResult &b) {
    return a.first < b.first;
  });
  if ((int)results.size() > k) results.resize(k);
  return StatusOr<std::vector<SearchResult>>(std::move(results));
}

// Return rich hit records for episodic memories.  This function
// mirrors the behaviour of Search but returns additional metadata
// including the row id, reward and timestamp.  If
// with_embeddings=false the returned emb vectors will be empty.
StatusOr<std::vector<MemoryService::EpisodicHit>>
MemoryService::SearchHits(const Tensor &query, int k, bool with_embeddings) const {
  if (!db_) return StatusOr<std::vector<EpisodicHit>>(Status::Error("DB not initialized"));
  if (k <= 0) return StatusOr<std::vector<EpisodicHit>>(Status::Error("k must be positive"));
  auto flat_or = FlattenTensor(query);
  if (!flat_or.status.ok) {
    return StatusOr<std::vector<EpisodicHit>>(flat_or.status);
  }
  std::vector<float> qvec = std::move(flat_or.value);
  const char *sql = "SELECT id, dim, embedding, text, reward, ts FROM memory;";
  sqlite3_stmt *stmt;
  if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
    return StatusOr<std::vector<EpisodicHit>>(Status::Error("Failed to prepare select"));
  }
  std::vector<EpisodicHit> hits;
  while (sqlite3_step(stmt) == SQLITE_ROW) {
    sqlite3_int64 rid = sqlite3_column_int64(stmt, 0);
    int dim = sqlite3_column_int(stmt, 1);
    const void *blob = sqlite3_column_blob(stmt, 2);
    int bytes = sqlite3_column_bytes(stmt, 2);
    const unsigned char *text = sqlite3_column_text(stmt, 3);
    double reward = sqlite3_column_double(stmt, 4);
    sqlite3_int64 ts = sqlite3_column_int64(stmt, 5);
    std::vector<float> emb;
    if (with_embeddings) {
      // Deserialize embedding vector
      if (bytes >= static_cast<int>(sizeof(int) + dim * sizeof(float))) {
        const float *vals = reinterpret_cast<const float *>(static_cast<const char *>(blob) + sizeof(int));
        emb.assign(vals, vals + dim);
      }
    }
    // Compute distance
    // Reconstruct embedding for distance
    float dist;
    if (!with_embeddings) {
      // Use embedding from DB to compute distance using on‑the‑fly reading
      // NB: we need to load vector anyway for computing distance, so we read it unconditionally
      if (bytes >= static_cast<int>(sizeof(int) + dim * sizeof(float))) {
        const float *vals = reinterpret_cast<const float *>(static_cast<const char *>(blob) + sizeof(int));
        float sum = 0.0f;
        for (int i = 0; i < dim && i < (int)qvec.size(); ++i) {
          float diff = qvec[i] - vals[i];
          sum += diff * diff;
        }
        dist = sum;
      } else {
        dist = std::numeric_limits<float>::max();
      }
    } else {
      // with_embeddings; we have emb loaded
      float sum = 0.0f;
      int n = std::min(dim, (int)qvec.size());
      for (int i = 0; i < n; ++i) {
        float diff = qvec[i] - emb[i];
        sum += diff * diff;
      }
      dist = sum;
    }
    EpisodicHit hit;
    hit.id = rid;
    hit.score = dist;
    hit.emb = std::move(emb);
    hit.text = text ? reinterpret_cast<const char *>(text) : "";
    hit.reward = static_cast<float>(reward);
    hit.ts_unix = static_cast<uint64_t>(ts);
    hits.push_back(std::move(hit));
  }
  sqlite3_finalize(stmt);
  // Sort by distance ascending
  std::sort(hits.begin(), hits.end(), [](const EpisodicHit &a, const EpisodicHit &b) {
    return a.score < b.score;
  });
  if ((int)hits.size() > k) hits.resize(k);
  return StatusOr<std::vector<EpisodicHit>>(std::move(hits));
}

Status MemoryService::Clear() {
  if (!db_) return Status::Error("DB not initialized");
  char *err = nullptr;
  if (sqlite3_exec(db_, "DELETE FROM memory;", nullptr, nullptr, &err) != SQLITE_OK) {
    std::string msg = err ? err : "unknown error";
    sqlite3_free(err);
    return Status::Error(msg.c_str());
  }
  return Status::OK();
}

} // namespace elastic
