# Operations Runbook

This runbook provides instructions for deploying, monitoring, and maintaining the cockpit AI system in production.

## Deployment

There are two supported deployment methods:

1. **Docker Compose** (suitable for local development or small‑scale deployments):

   ```bash
   # Ensure .env contains COCKPIT_API_KEYS and other secret values
   cd infra
   docker-compose up --build -d
   ```

   The compose file starts the API, Qdrant, vLLM, Redis, Prometheus, and Grafana. The API will be available on port 8000.

2. **Kubernetes** (production):

   Apply the manifests in `infra/`:

   ```bash
   kubectl apply -f infra/deploy/api-deploy.yaml
   kubectl apply -f infra/svc/api-svc.yaml
   kubectl apply -f infra/hpa/api-hpa.yaml
   kubectl apply -f infra/ingress/api-ing.yaml
   ```

   Ensure that secrets and config maps are created separately with appropriate values for API keys, JWT secrets, and database configuration.

## Configuration

All configuration parameters are provided via environment variables (see `cockpit_mod/config/settings.py`). Key settings include:

- `COCKPIT_API_KEYS`: comma‑separated list of API keys.
- `COCKPIT_MODELS_CONFIG`: path to the models configuration YAML.
- `COCKPIT_MEMORY_DB`: path or DSN for the memory database (e.g. Qdrant).
- `COCKPIT_JWT_SECRET_KEY`: secret used for JWT authentication.
- `COCKPIT_RATE_LIMIT_REDIS_URL`: Redis connection URI for rate limiting.

## Backup and Restore

### Vector Store

For Qdrant:

1. Enable snapshotting by configuring `snapshots` in the Qdrant deployment.
2. Use `qdrant-cli snapshot create` to create a snapshot.
3. Store snapshots in an offsite location.
4. To restore, deploy a new Qdrant instance and load the snapshot via the Qdrant API.

### Memory DB

If using a file‑based memory database, ensure the file is included in your backup strategy. The `docker-compose.yml` mounts `/data` from the host to persist the memory database.

## Monitoring and Alerts

- **Prometheus** scrapes metrics from the API and Qdrant services. Metrics include request latency, throughput, and working-memory statistics.
- **Grafana** provides dashboards. Login with the admin credentials set in deployment.
- Configure alert rules in Prometheus or Grafana to notify on high latency, error rates, or unusual collapse rates.

## Common Tasks

### Rotate API Keys

1. Generate a new key.
2. Update the secret in your environment (e.g. Vault secret or Kubernetes secret).
3. Redeploy the API pods.
4. Remove the old key from allowed list.

### Scale Up/Down

In Kubernetes, adjust the `maxReplicas` in `infra/hpa/api-hpa.yaml` or override via Helm/values.

### Kill Switch

To disable write operations:

1. Set an environment variable `COCKPIT_READ_ONLY=true` in the API deployment.
2. The server should check this variable and refuse any self‑write operations.
3. Redeploy the API pods to apply the change.

## Troubleshooting

### The API returns 503

- Ensure model servers (vLLM, llama.cpp) and Qdrant are reachable.
- Check the `/ready` and `/live` endpoints.
- Inspect API logs for exceptions.

### Self‑write fails with “gate” errors

- The gate blocks modifications outside `cockpit_mod`. Check the diff.
- Ensure forbidden patterns are not present.
- Review and adjust policy in `cockpit_mod/selfwrite/gate.py` or `opa/selfwrite_policy.rego`.

### Tests Runner reports syntax errors

- Open the logs attached to the runner result to see the offending files.
- Fix the syntax in your patch.

## Incident Response

1. Contain: use the kill switch to disable writes.
2. Investigate: gather logs, attestation records, and working-memory telemetry.
3. Eradicate: patch the vulnerability or bug, update policies.
4. Recover: restore service with patched code; ensure no data corruption.
