"""
UI package for the AI cockpit.

Contains interactive clients (CLI, optionally web) for interacting
with the orchestrator.
"""

__all__: list[str] = []