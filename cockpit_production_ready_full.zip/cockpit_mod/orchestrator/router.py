"""
Simple routing logic for selecting the appropriate model.

This module defines a `choose_model` function which can inspect
incoming text and decide which adapter to use.  In this initial
implementation, it always returns the default model from the
registry.  Future implementations could examine the input length,
content, or user-specified preferences to select among multiple
adapters.
"""

from __future__ import annotations

from .registry import Registry
from .router_rules import choose_model_by_length
from .router_governor import choose_model_by_cost
import os


def choose_model(text: str, registry: Registry):
    """Pick a model based on the input and configuration.

    By default this function uses the length‑based heuristic defined in
    `router_rules`.  If the environment variable
    `COCKPIT_ROUTER_GOVERNOR` is set to "cost", it will delegate to
    `router_governor.choose_model_by_cost` which takes into account
    estimated token counts and cost budgets.

    Parameters
    ----------
    text: str
        User prompt.
    registry: Registry
        Registry of loaded models.

    Returns
    -------
    ModelAdapter
        Selected adapter.
    """
    mode = os.environ.get("COCKPIT_ROUTER_GOVERNOR")
    if mode and mode.lower() == "cost":
        return choose_model_by_cost(text, registry)
    return choose_model_by_length(text, registry)