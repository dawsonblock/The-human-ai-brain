// Backend abstraction for operations.  Different backends (CPU, CUDA,
// DirectML) implement these methods.  The ops.cpp file dispatches
// through a global backend pointer to select the appropriate
// implementation at runtime.

#pragma once

#include "elastic/status.hpp"
#include "elastic/tensor.hpp"

namespace elastic {

struct Backend {
  virtual ~Backend() = default;
  virtual StatusOr<Tensor> matmul(const Tensor& a, const Tensor& b) noexcept = 0;
  virtual StatusOr<Tensor> add(const Tensor& a, const Tensor& b) noexcept = 0;
  virtual StatusOr<Tensor> gelu(const Tensor& x) noexcept = 0;
  virtual StatusOr<Tensor> layernorm(const Tensor& x, float epsilon) noexcept = 0;
  virtual StatusOr<Tensor> softmax_lastdim(const Tensor& x) noexcept = 0;
};

// Initialise the global backend pointer.  The implementation chooses
// the best available backend based on runtime detection.  Must be
// called once at application startup.
void initialize_best_backend() noexcept;

// Accessor for global backend
Backend* get_backend() noexcept;

} // namespace elastic
