package selfwrite

# Self-write policy example.

default allow = false

# Allow read operations unconditionally
allow {
    input.action == "read"
}

# Allow write operations only within a sandboxed path
allow {
    input.action == "write"
    safe_write_path
}

safe_write_path {
    # Only allow writes inside /sandbox/tmp/
    startswith(input.path, "/sandbox/tmp/")
}