# Minimal CMake find module for DirectML.
# This module attempts to locate the DirectML headers and library.  If it
# cannot find an installation on the system, the calling project should
# fall back to CPU implementations.

find_path(DirectML_INCLUDE_DIR NAMES directml.h PATHS ENV DML_PATH PATH_SUFFIXES include)
find_library(DirectML_LIBRARY NAMES DirectML PATHS ENV DML_PATH PATH_SUFFIXES lib)

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(DirectML DEFAULT_MSG DirectML_LIBRARY DirectML_INCLUDE_DIR)

if(DirectML_FOUND)
  set(DirectML_LIBRARIES ${DirectML_LIBRARY})
  set(DirectML_INCLUDE_DIRS ${DirectML_INCLUDE_DIR})
endif()