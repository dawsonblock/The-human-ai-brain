// Platform abstraction for aligned memory and timing on Windows.

#pragma once

#include <cstddef>
#include <cstdint>

namespace elastic {

// Aligned allocation.  Uses _aligned_malloc on Windows and posix_memalign on other platforms.
inline void* aligned_malloc(std::size_t size, std::size_t alignment) {
#ifdef _WIN32
  return _aligned_malloc(size, alignment);
#else
  void* ptr = nullptr;
  if (posix_memalign(&ptr, alignment, size) != 0) {
    return nullptr;
  }
  return ptr;
#endif
}

inline void aligned_free(void* ptr) {
#ifdef _WIN32
  _aligned_free(ptr);
#else
  free(ptr);
#endif
}

// Read timestamp counter.  On MSVC this maps to __rdtsc intrinsic.
inline uint64_t rdtsc() {
#ifdef _MSC_VER
  return __rdtsc();
#elif defined(__i386__) || defined(__x86_64__)
  unsigned int hi, lo;
  __asm__ __volatile__("rdtsc" : "=a"(lo), "=d"(hi));
  return ((uint64_t)hi << 32) | lo;
#else
  return 0;
#endif
}

// Return the number of NUMA nodes on the system.  On non‑Windows
// platforms this simply returns 1.
inline int get_numa_nodes() {
#ifdef _WIN32
  ULONG highest = 0;
  if (GetNumaHighestNodeNumber(&highest)) {
    return static_cast<int>(highest) + 1;
  }
  return 1;
#else
  return 1;
#endif
}

} // namespace elastic
