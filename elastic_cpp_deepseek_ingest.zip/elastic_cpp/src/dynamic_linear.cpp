// Implementation of DynamicLinear layer.

#include "elastic/dynamic_linear.hpp"
#include "elastic/ops.hpp"
#include "elastic/rng.hpp"

#include <cassert>

namespace elastic {

Status DynamicLinear::init(int d_out_, int d_max, bool bias, uint64_t seed) noexcept {
  d_out = d_out_;
  D_MAX = d_max;
  has_bias = bias;
  // Allocate W [d_out, D_MAX]
  StatusOr<Tensor> maybe_W = Tensor::make({d_out, d_max});
  if (!maybe_W.status.ok) return maybe_W.status;
  W = std::move(maybe_W.value);
  // Allocate b [d_out] if bias
  if (has_bias) {
    StatusOr<Tensor> maybe_b = Tensor::make({d_out});
    if (!maybe_b.status.ok) return maybe_b.status;
    b = std::move(maybe_b.value);
  }
  // Initialise weights with a small normal distribution
  Rng rng;
  rng.init(seed);
  float* w_ptr = W.data();
  size_t n = static_cast<size_t>(d_out) * static_cast<size_t>(d_max);
  for (size_t i = 0; i < n; ++i) {
    // Xavier/Glorot uniform initialisation: U(-sqrt(6/(in+out)), sqrt(6/(in+out)))
    float limit = std::sqrt(6.0f / (d_max + d_out));
    float val = (rng.uniform() * 2.0f - 1.0f) * limit;
    w_ptr[i] = val;
  }
  if (has_bias) {
    float* b_ptr = b.data();
    for (int i = 0; i < d_out; ++i) {
      b_ptr[i] = 0.0f;
    }
  }
  return Status::OK();
}

StatusOr<Tensor> DynamicLinear::forward(const Tensor& x, int d_active) const noexcept {
  // Validate input dimension
  const auto& x_shape = x.shape();
  if (x_shape.empty()) {
    return StatusOr<Tensor>(Status::Error("Linear expects at least 1D input"));
  }
  int in_dim = x_shape.back();
  if (d_active > in_dim || d_active > D_MAX) {
    return StatusOr<Tensor>(Status::Error("Active dimension exceeds input or maximum"));
  }
  // Compute output shape: replace last dimension with d_out
  std::vector<int> out_shape = x_shape;
  out_shape.back() = d_out;
  StatusOr<Tensor> maybe_out = Tensor::make(out_shape);
  if (!maybe_out.status.ok) return maybe_out;
  Tensor out = std::move(maybe_out.value);
  // Determine number of outer elements (product of dims excluding last)
  size_t outer = 1;
  for (size_t i = 0; i < x_shape.size() - 1; ++i) {
    outer *= static_cast<size_t>(x_shape[i]);
  }
  const float* x_ptr = x.data();
  float* out_ptr = out.data();
  const float* w_ptr = W.data();
  const float* b_ptr = has_bias ? b.data() : nullptr;
  // For each outer element (row), compute matrix-vector product
  // x_row: [d_active], W_slice: [d_out, d_active] stored row major as [j,i]
  for (size_t row = 0; row < outer; ++row) {
    const float* x_row = x_ptr + row * in_dim;
    float* y_row = out_ptr + row * d_out;
    for (int j = 0; j < d_out; ++j) {
      float acc = 0.0f;
      const float* w_row = w_ptr + static_cast<size_t>(j) * D_MAX;
      for (int i = 0; i < d_active; ++i) {
        acc += x_row[i] * w_row[i];
      }
      if (has_bias) {
        acc += b_ptr[j];
      }
      y_row[j] = acc;
    }
  }
  return StatusOr<Tensor>(std::move(out));
}

} // namespace elastic
