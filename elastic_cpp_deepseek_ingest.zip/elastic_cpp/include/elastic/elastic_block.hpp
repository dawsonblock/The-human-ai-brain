// Elastic Transformer block combining attention and feed‑forward network.

#pragma once

#include "elastic/elastic_attention.hpp"
#include "elastic/dynamic_linear.hpp"
#include "elastic/status.hpp"
#include "elastic/tensor.hpp"

namespace elastic {

struct ElasticBlock {
  ElasticAttention attn;
  DynamicLinear ffn1;
  DynamicLinear ffn2;
  int d_max = 0;
  int d_min = 0;

  Status init(int d_max_ = 1024, int d_min_ = 256, uint64_t seed = 42) noexcept;
  StatusOr<Tensor> forward(const Tensor& x, int d, const Tensor* mask) const noexcept;
};

} // namespace elastic
