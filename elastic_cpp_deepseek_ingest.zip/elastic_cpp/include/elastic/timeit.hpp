// Simple timing utility based on the high resolution clock.

#pragma once

#include <chrono>
#include <cstdint>

namespace elastic {

struct TimeIt {
  using clock = std::chrono::high_resolution_clock;
  clock::time_point start;
  uint64_t* target;
  explicit TimeIt(uint64_t* out) : start(clock::now()), target(out) {}
  ~TimeIt() {
    auto end = clock::now();
    auto dur = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    if (target) {
      *target = static_cast<uint64_t>(dur.count());
    }
  }
};

} // namespace elastic
