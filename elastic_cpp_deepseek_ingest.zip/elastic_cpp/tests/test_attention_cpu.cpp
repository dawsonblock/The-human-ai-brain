#include "elastic/elastic_attention.hpp"
#include "elastic/rng.hpp"
#include <cassert>
#include <cmath>
#include <iostream>

using namespace elastic;

int main() {
  // Initialise attention with small dimensions
  ElasticAttention attn;
  int d_max = 8;
  int d_min = 4;
  assert(attn.init(d_max, d_min, 77).ok);
  // Input tensor [1, 3, d_max]
  StatusOr<Tensor> maybe_x = Tensor::make({1, 3, d_max});
  assert(maybe_x.status.ok);
  Tensor x = std::move(maybe_x.value);
  // Fill with deterministic values
  for (size_t i = 0; i < x.size(); ++i) x.data()[i] = static_cast<float>(i % d_max) * 0.1f;
  int d = 6;
  auto out = attn.forward(x, d, nullptr);
  assert(out.status.ok);
  Tensor y = std::move(out.value);
  // Check shape [1,3,d]
  auto sh = y.shape();
  assert(sh.size() == 3);
  assert(sh[0] == 1 && sh[1] == 3 && sh[2] == d);
  // Values should be finite and not NaN
  for (size_t i = 0; i < y.size(); ++i) {
    assert(std::isfinite(y.data()[i]));
  }
  std::cout << "test_attention_cpu passed\n";
  return 0;
}