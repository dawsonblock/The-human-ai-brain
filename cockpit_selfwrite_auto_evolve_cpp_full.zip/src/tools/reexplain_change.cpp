// reexplain_change.cpp
//
// Command line tool to regenerate and optionally validate an
// explanation for an existing change report.  Usage:
//   ./reexplain_change <path/to/report.json>
// The tool reads the report JSON, calls the explainer to produce a
// new explanation and writes the updated report back to disk.  The
// validation result is printed to stdout.

#include <iostream>
#include <fstream>
#include <string>

#include "nlohmann/json.hpp"
#include "change_audit.h"
#include "explainer.h"
#include "change_gate.h"

int main(int argc, char **argv) {
    if (argc != 2) {
        std::cerr << "usage: " << argv[0] << " <report.json>\n";
        return 1;
    }
    std::string path = argv[1];
    // Read the report JSON
    nlohmann::json j;
    try {
        std::ifstream ifs(path);
        if (!ifs) {
            std::cerr << "failed to open report: " << path << "\n";
            return 1;
        }
        j = nlohmann::json::parse(ifs);
    } catch (const std::exception &e) {
        std::cerr << "failed to parse report: " << e.what() << "\n";
        return 1;
    }
    // Build a Report struct from the JSON.  We only need the fields
    // used by the explainer and validator.  Missing fields are
    // tolerated.
    change_audit::Report report;
    report.ts = j.value("ts", 0L);
    report.file = j.value("file", std::string());
    report.intent = j.value("intent", std::string());
    report.old_sha256 = j.value("old_sha256", std::string());
    report.new_sha256 = j.value("new_sha256", std::string());
    report.diff_sha256 = j.value("diff_sha256", std::string());
    report.diff = j.value("diff", std::string());
    report.author = j.value("author", std::string());
    report.ast_delta = j.value("ast_delta", nlohmann::json::object());
    // Generate explanation
    auto expl = explainer::generate_explanation(report);
    // Validate explanation
    std::vector<std::string> errs;
    bool ok = change_gate::validate_explanation(expl, report.ast_delta, errs);
    // Update JSON
    j["explanation"] = expl;
    j["explanation_errors"] = errs;
    // Write back
    try {
        std::ofstream ofs(path);
        ofs << j.dump(2);
    } catch (const std::exception &e) {
        std::cerr << "failed to write report: " << e.what() << "\n";
        return 1;
    }
    std::cout << "ok: " << (ok ? "true" : "false") << "\n";
    if (!errs.empty()) {
        std::cout << "errors: ";
        for (size_t i = 0; i < errs.size(); ++i) {
            if (i > 0) std::cout << ", ";
            std::cout << errs[i];
        }
        std::cout << "\n";
    }
    return 0;
}