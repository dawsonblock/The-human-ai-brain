// Copyright (c) 2025
//
// Definitions for a simple Status and StatusOr<T> class used
// throughout the elastic‑width Transformer.  These structures
// encapsulate success or failure without relying on exceptions.

#pragma once

#include <string>
#include <utility>

namespace elastic {

// A Status object encapsulates an OK/error state.  When ok is true the
// operation succeeded; otherwise msg holds a human readable error.
struct Status {
  bool ok;
  const char* msg;

  // Construct an OK status.
  static constexpr Status OK() noexcept {
    return {true, ""};
  }

  // Construct an error status with a given message.  The caller must
  // ensure the lifetime of the string literal exceeds the use of the
  // status.  For simplicity we restrict messages to static strings.
  static constexpr Status Error(const char* m) noexcept {
    return {false, m};
  }
};

// A StatusOr<T> holds either a Status or a value of type T when the
// status indicates success.  The value is default constructed when
// initialised in error state.
template <class T>
struct StatusOr {
  Status status;
  T value;

  // Default constructor yields an error status.
  StatusOr() : status(Status::Error("Uninitialised")), value() {}

  // Construct from a Status.  The value is default constructed.
  StatusOr(const Status& s) : status(s), value() {}

  // Construct from a value.  Status is automatically OK.
  StatusOr(const T& v) : status(Status::OK()), value(v) {}
  StatusOr(T&& v) : status(Status::OK()), value(std::move(v)) {}
};

} // namespace elastic
