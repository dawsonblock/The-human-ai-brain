
from fdqc.memory import Unit, WorkingMemory, LTM

def test_effective_capacity():
    wm = WorkingMemory(capacity=4, chunk_size=4)
    assert wm.effective_capacity() == 16

def test_insertion_and_eviction():
    wm = WorkingMemory(capacity=4, chunk_size=4, decay_seconds=0.1)
    units = [Unit(value=i) for i in range(24)]
    wm.add_units(units)
    assert len(wm.slots) == 4
    assert wm.effective_capacity() == 16

def test_ltm_promotion():
    from fdqc.memory.chunking import Chunk
    ltm = LTM(promote_threshold=2)
    ch = Chunk(items=[Unit(value=i) for i in range(4)], relevance=0.9)
    ltm.observe(ch); ltm.observe(ch)
    assert ltm.is_promoted(ch)
