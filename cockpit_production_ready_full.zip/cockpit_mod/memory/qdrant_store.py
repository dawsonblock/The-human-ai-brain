"""
Qdrant-backed vector store implementation.

This module provides a simple wrapper around a Qdrant client for
storing and retrieving embeddings for episodic and semantic memory.
It requires the `qdrant-client` package to be installed.  If the
package is unavailable, the store will raise at import time.
"""
from __future__ import annotations

from typing import Any, Iterable, List, Tuple
import logging

from qdrant_client import QdrantClient  # type: ignore

logger = logging.getLogger(__name__)


class QdrantStore:
    """Simple Qdrant-backed memory store."""

    def __init__(self, host: str = "localhost", port: int = 6333, collection_name: str = "memory") -> None:
        self.client = QdrantClient(host=host, port=port)
        self.collection_name = collection_name
        # Create collection if it doesn't exist
        try:
            self.client.get_collection(collection_name)
        except Exception:
            self.client.create_collection(
                collection_name,
                vectors_config={"size": 768, "distance": "Cosine"},
            )

    def recall(self, query_vec: Iterable[float], limit: int = 8) -> List[Tuple[List[float], Any]]:
        """Return the top `limit` vectors similar to `query_vec`.

        Returns a list of (embedding, payload) tuples.
        """
        if query_vec is None:
            return []
        try:
            search_result = self.client.search(
                collection_name=self.collection_name,
                query_vector=list(query_vec),
                limit=limit,
            )
            return [(hit.vector, hit.payload) for hit in search_result]
        except Exception as exc:
            logger.error(f"Qdrant recall failed: {exc}")
            return []

    def put_memory(self, embedding: Iterable[float], payload: Any) -> None:
        """Insert a new vector with an associated payload."""
        try:
            self.client.upsert(
                collection_name=self.collection_name,
                points=[{
                    "id": self.client.get_next_id(self.collection_name),
                    "vector": list(embedding),
                    "payload": payload,
                }],
            )
        except Exception as exc:
            logger.error(f"Qdrant upsert failed: {exc}")

    def compress(self) -> None:
        """No-op for Qdrant; compaction handled by the server."""
        pass