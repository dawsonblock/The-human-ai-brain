// Stub GEMM slice kernel.  No device implementation provided.
#include "elastic/ops.hpp"

// This file exists to satisfy the build system when CUDA is enabled.