"""
Entry point for running the AI cockpit using Uvicorn.

This script provides a simple way to launch the FastAPI application
defined in `cockpit_mod.orchestrator.server` in a production
environment.  Configuration such as host, port, and logging level can
be controlled via environment variables or by modifying this file.

Usage:

    python -m cockpit_mod.run_server

or

    uvicorn cockpit_mod.orchestrator.server:app --host 0.0.0.0 --port 8000

The script will look up the `PORT` environment variable to
determine which port to bind; if unset, it defaults to 8000.
"""

import os
import uvicorn

def main() -> None:
    port = int(os.environ.get("PORT", "8000"))
    host = os.environ.get("HOST", "0.0.0.0")
    log_level = os.environ.get("LOG_LEVEL", "info")
    # We import here to avoid side effects if this module is imported as a library
    from cockpit_mod.orchestrator.server import app  # noqa: WPS433
    uvicorn.run(app, host=host, port=port, log_level=log_level)


if __name__ == "__main__":
    main()