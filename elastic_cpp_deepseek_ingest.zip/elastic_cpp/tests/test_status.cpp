#include "elastic/status.hpp"
#include <cassert>
#include <iostream>

int main() {
  using elastic::Status;
  Status ok = Status::OK();
  assert(ok.ok);
  assert(std::string(ok.msg).empty());
  Status err = Status::Error("bad");
  assert(!err.ok);
  assert(std::string(err.msg) == "bad");
  std::cout << "test_status passed\n";
  return 0;
}