
from dataclasses import dataclass, field
from typing import List, Any, Callable
import time

@dataclass
class Unit:
    value: Any
    ts: float = field(default_factory=lambda: time.time())
    importance: float = 0.5
    vec: list[float] | None = None

@dataclass
class Chunk:
    items: List[Unit]
    ts: float = field(default_factory=lambda: time.time())
    relevance: float = 0.0
    label: str | None = None

class Chunker:
    def __init__(self, max_items:int=4, relevance_fn:Callable[[List[Unit]], float] | None=None):
        self.max_items = max_items
        self.relevance_fn = relevance_fn or self.default_relevance

    def default_relevance(self, items: List[Unit]) -> float:
        if not items:
            return 0.0
        imp = sum(u.importance for u in items)/len(items)
        age = max(0.001, sum(time.time()-u.ts for u in items)/len(items))
        freshness = 1.0/(1.0+age)
        val = 0.7*imp + 0.3*freshness
        return max(0.0, min(1.0, val))

    def make_chunks(self, units: List[Unit]) -> List[Chunk]:
        chunks: List[Chunk] = []
        buf: List[Unit] = []
        for u in units:
            buf.append(u)
            if len(buf) == self.max_items:
                chunks.append(self._finalize(buf))
                buf = []
        if buf:
            chunks.append(self._finalize(buf))
        return chunks

    def _finalize(self, items: List[Unit]) -> Chunk:
        rel = self.relevance_fn(items)
        return Chunk(items=list(items), relevance=rel)
