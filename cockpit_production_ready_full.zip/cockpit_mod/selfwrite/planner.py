"""
Planner for self‑writing tasks.

Given a high‑level goal (e.g. "add health endpoint"), the planner
produces a list of atomic tasks with target files and acceptance
criteria.  This stub implementation returns a single dummy task.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Any


@dataclass
class Task:
    title: str
    targets: List[str]
    checks: List[str]


def plan(goal: str, repo_root: str) -> List[Task]:
    """Plan a high‑level goal into concrete tasks.

    Parameters
    ----------
    goal: str
        The requested change (e.g. "add /health endpoint").
    repo_root: str
        Path to the repository root (unused in stub).

    Returns
    -------
    list of Task
        A list of tasks to be executed.
    """
    # This stub returns a single task that edits nothing.  In a real
    # implementation this would analyze the repository and produce
    # actionable changes.
    return [Task(title=f"No‑op task for '{goal}'", targets=[], checks=[])]