// Stub CUDA attention kernels.  A full device implementation is beyond
// the scope of this reference.  When CUDA is enabled this file is
// compiled by NVCC.  The functions below simply forward to the CPU
// implementations defined in ops.cpp.

#include "elastic/ops.hpp"

using namespace elastic;

// No exported functions are provided in this stub.  Real kernels
// should be defined here when adding GPU support.
