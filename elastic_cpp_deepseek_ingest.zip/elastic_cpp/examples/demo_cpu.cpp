#include "elastic/transformer.hpp"
#include "elastic/controller.hpp"
#include "elastic/ops.hpp"

#include <cassert>
#include <cmath>
#include <iostream>

using namespace elastic;

int main() {
  // Build a small Transformer
  TransformerConfig cfg;
  cfg.vocab = 32;
  cfg.layers = 2;
  cfg.d_max = 16;
  cfg.d_min = 8;
  Transformer model;
  auto s = model.init(cfg, 12345);
  if (!s.ok) {
    std::cerr << "Model init failed: " << s.msg << "\n";
    return 1;
  }
  // Create dummy input indices [B,T]
  int B = 2;
  int T = 5;
  StatusOr<Tensor> maybe_idx = Tensor::make({B, T});
  assert(maybe_idx.status.ok);
  Tensor idx = std::move(maybe_idx.value);
  // Fill with a simple pattern
  for (int b = 0; b < B; ++b) {
    for (int t = 0; t < T; ++t) {
      idx.data()[b * T + t] = static_cast<float>((b + t) % cfg.vocab);
    }
  }
  // Use controller to pick a width
  WidthController ctrl;
  float load = 0.4f;
  float entropy = 0.5f;
  float latency = 5.0f;
  int d = ctrl.pick(load, entropy, latency);
  std::cout << "Selected width: " << d << "\n";
  // Run forward pass
  auto out = model.forward(idx, d, nullptr);
  if (!out.status.ok) {
    std::cerr << "Forward failed: " << out.status.msg << "\n";
    return 1;
  }
  Tensor logits = std::move(out.value);
  // Compute per‑token negative log likelihood for next token (shifted)
  // For each sequence and position t>0: target is idx[b,t]
  auto maybe_probs = softmax_lastdim(logits);
  if (!maybe_probs.status.ok) {
    std::cerr << "Softmax failed: " << maybe_probs.status.msg << "\n";
    return 1;
  }
  Tensor probs = std::move(maybe_probs.value);
  float nll = 0.0f;
  int count = 0;
  for (int b = 0; b < B; ++b) {
    for (int t = 1; t < T; ++t) {
      int target = static_cast<int>(idx.data()[b * T + t]);
      // Probability of target at previous timestep
      float* row = probs.data() + ((b * T + (t - 1)) * cfg.vocab);
      float p = row[target];
      p = std::max(p, 1e-9f);
      nll -= std::log(p);
      ++count;
    }
  }
  float avg_nll = nll / count;
  std::cout << "Output shape: [" << logits.shape()[0] << "," << logits.shape()[1] << "," << logits.shape()[2] << "]\n";
  std::cout << "Average negative log likelihood: " << avg_nll << "\n";
  return 0;
}