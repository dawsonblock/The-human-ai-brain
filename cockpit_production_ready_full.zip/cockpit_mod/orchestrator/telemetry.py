"""
OpenTelemetry integration helpers.

This module configures OpenTelemetry instrumentation for FastAPI and
provides helper functions for initializing tracing and metrics.  To
enable tracing and metrics, call `setup_telemetry(app)` from your
application startup.
"""
from __future__ import annotations

import logging
from opentelemetry import trace  # type: ignore
from opentelemetry.sdk.resources import SERVICE_NAME, Resource  # type: ignore
from opentelemetry.sdk.trace import TracerProvider  # type: ignore
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter  # type: ignore
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor  # type: ignore

logger = logging.getLogger(__name__)


def setup_telemetry(app) -> None:
    """Initialize OpenTelemetry tracing for a FastAPI app."""
    try:
        resource = Resource.create({SERVICE_NAME: "cockpit-api"})
        provider = TracerProvider(resource=resource)
        processor = BatchSpanProcessor(ConsoleSpanExporter())
        provider.add_span_processor(processor)
        trace.set_tracer_provider(provider)
        FastAPIInstrumentor().instrument_app(app)
        logger.info("OpenTelemetry tracing configured")
    except Exception as exc:
        logger.warning(f"Failed to initialise telemetry: {exc}")