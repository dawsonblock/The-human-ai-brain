# Building the Elastic‑width Transformer on Windows

This repository is designed to build cleanly on Windows 11 using
Microsoft Visual Studio 2022 and CMake ≥ 3.29.  The following
instructions assume you are using the x64 Native Tools Command Prompt
for VS 2022 and have cloned the repository to `elastic_cpp`.

## CPU‑only build

To build the CPU reference implementation only, open PowerShell and run:

```powershell
cmake -B build -G "Ninja" -DCMAKE_BUILD_TYPE=Release -A x64 -DELASTIC_USE_CUDA=OFF -DELASTIC_USE_DIRECTML=OFF
cmake --build build --config Release
```

This will produce the static library `elastic_core` along with the
`demo_cpu` executable and unit tests.

## CUDA build

If you have CUDA 12.x installed and a compatible GPU you can enable
CUDA support by adding `-DELASTIC_USE_CUDA=ON` during configuration:

```powershell
cmake -B build_cuda -G "Ninja" -DCMAKE_BUILD_TYPE=Release -A x64 -DELASTIC_USE_CUDA=ON
cmake --build build_cuda --config Release
```

## DirectML build

To build with DirectML acceleration, ensure the DirectML SDK is
available and enable it via CMake:

```powershell
cmake -B build_dml -G "Ninja" -DCMAKE_BUILD_TYPE=Release -A x64 -DELASTIC_USE_DIRECTML=ON
cmake --build build_dml --config Release
```

If the optional accelerators cannot be found the build will fall back
to the CPU reference path.  The CPU implementation is deterministic
and bit‑stable with a fixed seed.
