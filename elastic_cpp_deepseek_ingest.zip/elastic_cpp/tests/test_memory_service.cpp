// test_memory_service.cpp
#include "elastic/memory_service.hpp"
#include "elastic/tensor.hpp"
#include <cassert>
#include <iostream>
#include <vector>

int main() {
  // Use an in‑memory SQLite database for testing ("": open an
  // in‑memory DB) to avoid file I/O.
  elastic::MemoryService mem(":memory:");
  // Insert two distinct embeddings.
  {
    auto t1_or = elastic::Tensor::make({4});
    auto t2_or = elastic::Tensor::make({4});
    auto t1 = t1_or.value;
    auto t2 = t2_or.value;
    float *d1 = t1.as_span().data();
    float *d2 = t2.as_span().data();
    for (int i = 0; i < 4; ++i) {
      d1[i] = static_cast<float>(i);
      d2[i] = static_cast<float>(4 - i);
    }
    assert(mem.Put(t1, "first").ok);
    assert(mem.Put(t2, "second").ok);
  }
  // Query near the first embedding
  auto q_or = elastic::Tensor::make({4});
  auto q = q_or.value;
  float *qd = q.as_span().data();
  for (int i = 0; i < 4; ++i) qd[i] = static_cast<float>(i) + 0.1f;
  auto res_or = mem.Search(q, 2);
  assert(res_or.status.ok);
  auto results = res_or.value;
  // Expect two results
  assert(results.size() == 2);
  // The nearest neighbour should be "first"
  assert(results[0].second == "first");
  // Now clear the DB and ensure search returns empty
  assert(mem.Clear().ok);
  auto empty_or = mem.Search(q, 5);
  assert(empty_or.status.ok);
  assert(empty_or.value.empty());
  // Test SearchHits ordering and distances on a fixed seed
  {
    // Reinsert memories with known vectors
    auto t1_or2 = elastic::Tensor::make({4});
    auto t2_or2 = elastic::Tensor::make({4});
    auto t1b = t1_or2.value;
    auto t2b = t2_or2.value;
    float *d1b = t1b.as_span().data();
    float *d2b = t2b.as_span().data();
    for (int i = 0; i < 4; ++i) {
      d1b[i] = static_cast<float>(i);
      d2b[i] = static_cast<float>(i + 1);
    }
    // Insert with rewards and timestamps for test
    assert(mem.Put(t1b, "alpha", 0.5f, 1).ok);
    assert(mem.Put(t2b, "beta", 1.0f, 2).ok);
    auto qh_or = elastic::Tensor::make({4});
    auto qh = qh_or.value;
    float *qdata = qh.as_span().data();
    for (int i = 0; i < 4; ++i) qdata[i] = static_cast<float>(i) + 0.2f;
    auto hits_or = mem.SearchHits(qh, 2, /*with_embeddings=*/true);
    assert(hits_or.status.ok);
    auto hits = hits_or.value;
    assert(hits.size() == 2);
    // The nearest should be alpha then beta
    assert(hits[0].text == "alpha");
    assert(hits[1].text == "beta");
    // Distances should be non-negative and ascending
    assert(hits[0].score <= hits[1].score);
    // Embeddings present when requested
    assert(!hits[0].emb.empty());
    // Now call without embeddings and ensure emb vectors are empty
    auto hits_noemb_or = mem.SearchHits(qh, 2, /*with_embeddings=*/false);
    assert(hits_noemb_or.status.ok);
    auto hits_ne = hits_noemb_or.value;
    assert(hits_ne[0].emb.empty() && hits_ne[1].emb.empty());
  }
  std::cout << "MemoryService tests passed\n";
  return 0;
}