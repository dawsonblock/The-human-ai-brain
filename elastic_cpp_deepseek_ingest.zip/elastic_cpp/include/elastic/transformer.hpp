// Top level elastic Transformer containing embeddings, multiple blocks and language modelling head.

#pragma once

#include "elastic/elastic_block.hpp"
#include "elastic/dynamic_linear.hpp"
#include "elastic/status.hpp"
#include "elastic/tensor.hpp"

#include <cstdint>
#include <vector>

namespace elastic {

struct TransformerConfig {
  int vocab;
  int layers = 4;
  int d_max = 1024;
  int d_min = 256;
};

struct Transformer {
  TransformerConfig cfg;
  Tensor embed;                // [vocab, D_MAX]
  std::vector<ElasticBlock> blocks;
  DynamicLinear lm_head;       // [vocab, D_MAX]

  Status init(const TransformerConfig& config, uint64_t seed = 42) noexcept;
  StatusOr<Tensor> forward(const Tensor& idx, int d, const Tensor* mask) const noexcept;
};

} // namespace elastic
